---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local PAY_CHANNEL_CODE_YUN_QQPAY_XD = "yun_qqpay_xd"

---@param v any
---@return table
local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

---@param body string
---@return table|nil
local function decodeBody(body)
    if not body or body == "" then
        return nil
    end
    local ok, data = pcall(json.decode, body)
    if ok and type(data) == "table" then
        return data
    end
    return nil
end

-- @class types.plugin
local plugin = {}

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        channels = {
            ["qqpay"] = { {
                label = "QQ云端-XD",
                value = PAY_CHANNEL_CODE_YUN_QQPAY_XD,
                options = {
                    use_add_amount = 1,
                    use_qrcode_login = 1
                }
            } }
        },
        options = {
            crontab_list = { {
                crontab = "*/6 * * * * *",
                fun = "cron",
                args = "",
                name = "检查账号状态",
                scope = "account",
                options = {
                    has_wait_pay_order = 0
                }
            } }
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = "gateway",
                label = "选择网关",
                type = types.InputTypes.SELECT,
                default = "",
                options = {
                    tip = "",
                    chose_gateway = 1
                },
                placeholder = "请选址网关",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择"
                } }
            },
            {
                name = "qrcode",
                label = "收款码地址",
                type = types.InputTypes.INPUT,
                default = "",
                options = {
                    tip = "",
                    append_deqrocde = 1
                },
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.type == 'qrcode'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "qrcode_file",
                label = "收款码图片",
                type = types.InputTypes.IMAGE,
                default = "",
                options = {
                    tip = ""
                },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.type == 'image'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "type",
                label = "收款码类型",
                type = types.InputTypes.SELECT,
                default = "qrcode",
                options = {
                    tip = ""
                },
                placeholder = "请选择收款码类型",
                values = { {
                    label = "二维码",
                    value = "qrcode"
                }, {
                    label = "图片",
                    value = "image"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "bind_token",
                label = "绑定的用户信息",
                type = types.InputTypes.INPUT,
                default = "",
                hidden = 1
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local options = ctx.account_options or {}

    if options.type == "image" then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = options.qrcode_file
            }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = options.qrcode,
            url = "",
            content = "",
            out_trade_no = ""
        }
    }
end

-- 定时任务
---@param ctx types.CronAccountParams
---@return table
function plugin.cron(ctx)
    local vAccountInfo = toTable(ctx.account_info)
    local vParams = toTable(ctx.account_options)
    local vAccountOptions = toTable(vAccountInfo.options)

    local bindTokenRaw = vParams.bind_token
    if bindTokenRaw == nil or bindTokenRaw == "" then
        bindTokenRaw = vAccountOptions.bind_token
    end

    if bindTokenRaw == nil or bindTokenRaw == "" then
        return {
            code = 500,
            message = "未登录",
            data = {}
        }
    end

    local bindTokenInfo = toTable(bindTokenRaw)
    local gateway = vParams.gateway
    if gateway == nil or gateway == "" then
        gateway = vAccountOptions.gateway
    end

    local serverAddress = helper.channel_gateway_addr(gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    local apiUri = string.format("%s/QQPAY_Pc/IsLoginStatus", serverAddress)
    local response, error_message = http.request("POST", apiUri, {
        query = string.format("uid=%s", bindTokenInfo.uid or ""),
        timeout = "30s",
    })
    if error_message ~= nil then
        helper.channel_account_offline(vAccountInfo.id)
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code == nil then
        helper.channel_account_offline(vAccountInfo.id)
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    if returnInfo.code ~= "1" then
        helper.channel_account_offline(vAccountInfo.id)
        helper.channel_account_set_option(vAccountInfo.id, "bind_token", "")

        if returnInfo.code == "0" then
            return { code = 201, message = "请扫描二维码登录", data = {} }
        end
        if returnInfo.code == "-1" then
            return { code = 500, message = "uid参数错误", data = {} }
        end
        if returnInfo.code == "-2" then
            return { code = 500, message = "没有找到Uid", data = {} }
        end

        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    if vAccountInfo.online ~= 1 then
        helper.channel_account_online(vAccountInfo.id)
    end

    return {
        code = 200,
        message = "在线",
        data = {}
    }
end

-- 二维码登录
---@param ctx table
---@return table
function plugin.login_qrcode(ctx)
    local vParams = toTable(ctx.params)
    local vUserInfo = toTable(ctx.user_info)
    local vAccountInfo = toTable(ctx.account_info)
    local vAccountOption = toTable(vAccountInfo.options)

    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    local site = ""
    if ctx.device then
        site = ctx.device.base_url or ctx.device.domain or ctx.device.host or ""
    end
    if site == "" then
        site = vParams.domain_url or ""
    end

    local apiUri = string.format("%s/QQPAY_Pc/CreateID", serverAddress)
    local req = {
        data = helper.base64_encode(json.encode({
            site = site,
            pid = vUserInfo.id,
            key = vUserInfo.app_secret
        }))
    }

    local response, error_message = http.request("POST", apiUri, {
        query = funcs.table_http_query(req),
        timeout = "30s",
    })
    if error_message ~= nil then
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code == nil then
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or ""),
            data = {}
        }
    end
    if returnInfo.code ~= "1" then
        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    local uid = returnInfo.uid
    helper.channel_account_set_option(vAccountInfo.id, "uid", uid)

    apiUri = string.format("%s/QQPAY_Pc/QRCode", serverAddress)
    response, error_message = http.request("POST", apiUri, {
        query = string.format("uid=%s", uid),
        timeout = "30s",
    })
    if error_message ~= nil then
        return {
            code = 500,
            message = string.format("请求获取登录二维码错误: %s", error_message),
            data = {}
        }
    end

    returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code ~= "1" then
        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            qrcode = returnInfo.url,
            options = json.encode({
                uid = uid
            })
        }
    }
end

-- 检查二维码登录状态
---@param ctx table
---@return table
function plugin.login_qrcode_check(ctx)
    local vParams = toTable(ctx.params)
    local vAccountInfo = toTable(ctx.account_info)
    local vAccountOption = toTable(vAccountInfo.options)

    local uid = vParams.uid
    if uid == nil or uid == "" then
        local bindTokenInfo = toTable(vAccountOption.bind_token)
        uid = bindTokenInfo.uid
    end

    if uid == nil or uid == "" then
        return {
            code = 201,
            message = "请扫描二维码登录",
            data = {}
        }
    end

    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    local apiUri = string.format("%s/QQPAY_Pc/IsLoginStatus", serverAddress)
    local response, error_message = http.request("POST", apiUri, {
        query = string.format("uid=%s", uid),
        timeout = "30s",
    })
    if error_message ~= nil then
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code == nil then
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    if returnInfo.code ~= "1" then
        if returnInfo.code == "0" then
            return { code = 201, message = "请扫描二维码登录", data = {} }
        end
        if returnInfo.code == "-1" then
            return { code = 500, message = "uid参数错误", data = {} }
        end
        if returnInfo.code == "-2" then
            return { code = 500, message = "没有找到Uid", data = {} }
        end

        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    helper.channel_account_set_option(vAccountInfo.id, "bind_token", json.encode({
        uid = uid
    }))

    return {
        code = 200,
        message = "登录成功",
        data = {}
    }
end

return plugin
