---@diagnostic disable: undefined-global
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local PLUGIN = "yun_wechat_all_lz"
local YUN_WECHAT_ALL_LZ = PLUGIN
local plugin = {}

local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

local function encodeProxyCredentials(proxy)
    proxy = tostring(proxy or "")
    local prefix, userInfo, address = proxy:match("^([%w+.-]+://)([^@]+)@(.+)$")
    if not prefix then return proxy end
    local username, password = userInfo:match("^([^:]*):(.*)$")
    if not username then return proxy end
    return prefix .. helper.url_encode(username) .. ":" .. helper.url_encode(password) .. "@" .. address
end

local function getProxy(accountOptions)
    accountOptions = accountOptions or {}
    local mode = accountOptions.proxy_mode or "no_proxy"
    if mode == "custom_proxy" then return encodeProxyCredentials(accountOptions.proxy or "") end
    if mode ~= "cloud_proxy" then return "" end

    local poolId = tonumber(accountOptions.proxy_pool_id or 0) or 0
    if poolId <= 0 then return "" end
    local itemId = tonumber(accountOptions.proxy_pool_item_id or 0) or 0
    local proxyItem = helper.proxy_pool_fetch(poolId, itemId)
    if proxyItem and proxyItem.proxy_url and proxyItem.proxy_url ~= "" then
        local proxyId = tonumber(proxyItem.proxy_id or 0) or 0
        if proxyId ~= itemId then
            accountOptions.proxy_pool_item_id = proxyId
            if accountOptions.account_id then
                helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", proxyId)
            end
        end
        return encodeProxyCredentials(proxyItem.proxy_url)
    end
    if itemId > 0 then helper.proxy_pool_release(itemId) end
    accountOptions.proxy_pool_item_id = 0
    if accountOptions.account_id then
        helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", "0")
    end
    return ""
end

local function mergeOptions(ctx)
    ctx = ctx or {}
    local accountInfo = ctx.account_info or {}
    local options = { account_id = accountInfo.id }
    for k, v in pairs(toTable(accountInfo.options)) do
        options[k] = v
    end
    for k, v in pairs(toTable(ctx.plugin_option)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.plugin_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.account_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    return options
end

-- 定义网关常量
local GATEWAY = {
    BASE = "https://payapp.wechatpay.cn",
    RECEIPT_MD = "https://payapp.wechatpay.cn/receiptmdmgr",
    RECEIPT_SJT = "https://payapp.wechatpay.cn/receiptsjtmgr",
    RECEIPT_WX = "https://payapp.wechatpay.cn/receiptwxmgr",
    SMALLBOOK = "https://smallbook.wxpapp.weixin.qq.com"
}

function plugin.pluginInfo()
    return {
        channels = {
            ["wxpay"] = {{
                label = '新微信云端-靓仔',
                value = YUN_WECHAT_ALL_LZ,
                options = {
                    need_check_online = 1,
                    use_qrcode_login = 1,
                    use_add_amount = 1
                }
            } }
        },
        options = {
            detection_interval = 5,
            detection_type = "cron",
            config = {{
                title = "请输入云端的token密匙",
                key = "yun_token",
                default = "jiaowoliangzai"
            }}
        }
    }
end

-- 获取form表单
function plugin.formItems(ctx)
    return {
        inputs = {
            {
                name = "gateway",
                label = "选择网关",
                type = "select",
                default = "",
                placeholder = "请选择网关",
                options = { chose_gateway = 1 },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择网关" } }
            },
            {
                name = "login_protocol",
                label = "登录协议",
                type = "radio",
                default = "yyb",
                options = { tip = "选择后，登录、状态检查和SID获取都会访问对应协议接口；切换协议后需要重新扫码登录" },
                placeholder = "请选择登录协议",
                values = {
                    { label = "应用宝", value = "yyb" },
                    { label = "手游助手", value = "app" },
                    { label = "电脑管家", value = "pc_tool" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择登录协议" } }
            },
            {
                name = "pay_mode",
                label = "收款方式",
                type = "radio",
                default = "receipt",
                options = { tip = "收款单使用微信收款单接口，小账本使用微信小账本接口" },
                placeholder = "请选择收款方式",
                values = {
                    { label = "收款单", value = "receipt" },
                    { label = "小账本", value = "smallbook" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择收款方式" } }
            },
            {
                name = "sid",
                label = "SID",
                type = "input",
                default = "",
                options = { tip = "扫码登录后会从微信网关自动获取对应SID，也可手动填写" },
                placeholder = "请输入SID或扫码登录后自动获取"
            },
            {
                name = "account_list",
                label = "账号列表(一行一组)",
                type = "textarea",
                default = "",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                hidden_list = 1,
                placeholder = "清空后会重新获取",
                options = { tip = "清空后会点保存会重新获取,如需切换账号ID,可在此处复制到下面对应输入框替换" }
            },
            {
                name = "aid",
                label = "账号ID",
                type = "input",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                default = "",
                placeholder = "请输入账号ID",
                options = { tip = "请从账号列表选一组账号信息的账号ID填入此处" }
            },
            {
                name = "account_type",
                label = "账号类型",
                type = "input",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                default = "",
                placeholder = "请输入账号类型[1-3],不行就换下一个",
                options = { tip = "请从账号列表选一组账号信息的账号类型填入此处" }
            },
            {
                name = "shop_id",
                label = "店铺ID",
                type = "input",
                default = "",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                options = { tip = "店铺ID保存/定时刷新，如果shop_id为空，就不要填写，否则会报错" },
                placeholder = "请输入商户ID"
            },
            {
                name = "scan_type",
                label = "订单检查方式",
                type = "radio",
                default = "order_or_amount",
                options = { tip = "" },
                placeholder = "请选择订单检查方式",
                values = {
                    { label = "订单号匹配不到则使用金额", value = "order_or_amount" },
                    { label = "订单号", value = "order" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = "order_temp_amount",
                label = "取消订单递增金额",
                type = "radio",
                default = "0",
                options = { tip = "<b>注意:</b>订单检查方式为订单号的时候才能选择[是]" },
                placeholder = "请选择订单检查方式",
                values = {
                    { label = "否", value = "0" },
                    { label = "是", value = "1" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = "proxy_mode",
                label = "代理模式",
                type = "select",
                default = "no_proxy",
                options = { tip = "选择代理使用模式" },
                placeholder = "请选择代理模式",
                values = {
                    { label = "不使用代理", value = "no_proxy" },
                    { label = "使用自定义代理", value = "custom_proxy" },
                    { label = "使用本站代理池", value = "cloud_proxy" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择代理模式" } }
            },
            {
                name = "proxy",
                label = "Socks5代理地址",
                type = "input",
                default = "",
                when = "this.formModel.options.proxy_mode == 'custom_proxy'",
                options = { tip = "格式：socks5://IP:端口，或 socks5://用户名:密码@IP:端口" },
                placeholder = "例如：socks5://127.0.0.1:1080"
            },
            {
                name = "proxy_pool_id",
                label = "绑定代理池",
                type = "chose_proxy_pool",
                default = "-1",
                when = "this.formModel.options.proxy_mode == 'cloud_proxy'",
                options = { tip = "请选择绑定的代理池" },
                placeholder = "请选择代理池",
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择代理池" } }
            },
            {
                name = "proxy_pool_item_id",
                label = "绑定代理",
                type = "input",
                default = "0",
                hidden = 1
            },
            {
                name = "bind_token",
                label = "绑定的用户信息",
                type = "input",
                hidden = 1
            },
            {
                name = "bound_login_protocol",
                label = "当前登录协议",
                type = "input",
                hidden = 1
            }
        }
    }
end

-- 统一的错误响应处理
plugin._error_response = function(err_code, err_message)
    return {
        code = err_code,
        message = err_message,
        data = {}
    }
end

-- 统一的HTTP响应检查
plugin._check_http_response = function(resp, account_id, operation)
    if resp == nil then
        log.warning(string.format("[%s] (%s) %s请求失败", PLUGIN, account_id, operation))
        return false
    end

    if resp.status_code ~= 200 then
        log.warning(string.format("[%s] (%s) %s失败,状态码:%d", PLUGIN, account_id, operation,
            resp.status_code))
        return false
    end

    if resp.body == "" then
        log.warning(string.format("[%s] (%s) %s失败,返回数据为空", PLUGIN, account_id, operation))
        return false
    end

    local data = json.decode(resp.body)
    if not data or data.errcode ~= 0 then
        log.warning(string.format("[%s] (%s) %s失败,错误码:%d", PLUGIN, account_id, operation,
            data and data.errcode or -1))
        return false
    end

    return true, data
end

-- 获取云端网关地址
plugin._get_cloud_gateway = function(options)
    if not options or not options.gateway or options.gateway == "" then
        return nil, "暂未配置支付网关"
    end

    local serverAddress = helper.channel_gateway_addr(options.gateway)
    if serverAddress == "" then
        return nil, "暂未配置支付网关"
    end
    return serverAddress, nil
end

-- 请求当前GO项目微信网关
plugin._request_wechat_gateway = function(method, serverAddress, path, query, timeout)
    local apiUri = string.format('%s%s', serverAddress, path)
    local response, error_message = http.request(method or "POST", apiUri, {
        query = query or "",
        timeout = timeout or "30s"
    })
    if error_message ~= nil then
        return nil, string.format('请求错误: %s', error_message)
    end
    if not response or not response.body or response.body == "" then
        return nil, "请求响应为空"
    end

    local data = json.decode(response.body)
    if not data then
        return nil, string.format('请求响应解析失败,响应内容: %s', response.body)
    end
    return data, nil
end

plugin._get_bound_uid = function(options)
    if not options then
        return nil
    end
    if options.bind_token and options.bind_token ~= "" then
        local bindInfo = json.decode(options.bind_token)
        if bindInfo and bindInfo.uid and bindInfo.uid ~= "" then
            return bindInfo.uid
        end
    end
    if options.uid and options.uid ~= "" then
        return options.uid
    end
    return nil
end

plugin._get_pay_mode = function(options)
    if options and options.pay_mode == "smallbook" then
        return "smallbook"
    end
    return "receipt"
end

plugin._get_protocol_prefix = function(options)
    local protocol = options and options.login_protocol or "yyb"
    if protocol == "app" then
        return "/WeChat_APP"
    end
    if protocol == "pc_tool" then
        return "/WeChat_Pc_Tool"
    end
    return "/WeChat_YYB"
end

plugin._extract_receipt_sid = function(data)
    if not data then
        return nil
    end
    local payload = data.data or data
    if type(payload) ~= "table" then
        return nil
    end
    return payload.sid or payload.Sid or payload.receipt_sid or payload.receiptSid
end

plugin._sync_sid_from_gateway = function(accountInfo, options)
    local uid = plugin._get_bound_uid(options)
    if not uid then
        return false, "请先扫码登录微信网关"
    end

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return false, gatewayErr
    end

    local protocolPrefix = plugin._get_protocol_prefix(options)
    local path = protocolPrefix .. "/GetReceiptSid"
    local sidName = "收款单SID"
    if plugin._get_pay_mode(options) == "smallbook" then
        path = protocolPrefix .. "/GetSmallBookSid"
        sidName = "小账本SID"
    end

    local data, requestErr = plugin._request_wechat_gateway("POST", serverAddress, path, string.format("uid=%s", uid), "60s")
    if requestErr then
        return false, requestErr
    end
    if data.code ~= "1" and data.code ~= 200 then
        return false, data.msg or "获取微信" .. sidName .. "失败"
    end

    local sid = plugin._extract_receipt_sid(data)
    if not sid or sid == "" then
        return false, "微信网关未返回" .. sidName
    end

    helper.channel_account_set_option(accountInfo.id, "sid", sid)
    options.sid = sid
    return true, ""
end

plugin._sync_receipt_sid_from_gateway = function(accountInfo, options)
    return plugin._sync_sid_from_gateway(accountInfo, options)
end

plugin._is_sid_invalid_response = function(response)
    if type(response) == "string" then
        return string.find(response, "登录态", 1, true) ~= nil
    end
    if type(response) ~= "table" then
        return false
    end
    return plugin._is_sid_invalid_response(response.msg) or plugin._is_sid_invalid_response(response.data)
end

plugin._refresh_sid_for_retry = function(accountInfo, options, scene)
    log.warning(string.format("(%s) %s SID可能已失效，尝试从微信网关刷新SID", PLUGIN, scene or "创建订单"))
    local ok, sidErr = plugin._sync_sid_from_gateway(accountInfo, options)
    if not ok then
        return false, sidErr
    end
    if plugin._get_pay_mode(options) ~= "smallbook" then
        local initOk, initErr = plugin._sync_receipt_account_options(accountInfo, options)
        if not initOk then
            return false, initErr
        end
    end
    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
        accountInfo.online = 1
    end
    return true, ""
end

plugin._is_sid_invalid_http_result = function(result)
    if not result or not result.body or result.body == "" then
        return false
    end
    local data = json.decode(result.body)
    return plugin._is_sid_invalid_response(data)
end

plugin._check_sid_invalid_by_probe = function(options)
    if not options or not options.sid or options.sid == "" then
        return false
    end

    local result
    if plugin._get_pay_mode(options) == "smallbook" then
        local url = "https://payapp.weixin.qq.com/qrappzd/user/incomelistflexible?sid=" .. options.sid
        result = http.get(url, {
            headers = {
                ["xweb_xhr"] = "1",
                ["Content-Type"] = "application/json",
                ["Accept"] = "*/*",
                ["Referer"] = "https://servicewechat.com/wx28be8489b7a36aaa/1061/page-frame.html"
            }
        })
    else
        local url = "https://payapp.wechatpay.cn/receiptwxmgr/account/list?miniprogram_version&sid=" .. options.sid
        result = http.get(url, {
            headers = {
                ["xweb_xhr"] = "1",
                ["Content-Type"] = "application/json",
                ["Accept"] = "*/*",
                ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html"
            }
        })
    end

    return plugin._is_sid_invalid_http_result(result)
end

-- 参数验证
plugin._validate_params = function(params, required_fields)
    for _, field in ipairs(required_fields) do
        if not params[field] or params[field] == "" then
            return false, string.format("缺少必要参数: %s", field)
        end
    end
    return true
end

-- 账号类型判断
plugin._get_gateway_by_account_type = function(account_type)
    account_type = tonumber(account_type) or account_type
    if account_type == 1 or account_type == "1" then
        return GATEWAY.RECEIPT_MD
    elseif account_type == 2 or account_type == "2" then
        return GATEWAY.RECEIPT_WX
    elseif account_type == 3 or account_type == "3" then
        return GATEWAY.RECEIPT_SJT
    end
    return nil
end

-- 创建订单
function plugin.create(ctx)
    local orderInfo = ctx.order_info
    local vAccountInfo = ctx.account_info or {}
    local options = ctx.account_options or json.decode(vAccountInfo.options or "{}") or {}
    local result

    if plugin._get_pay_mode(options) == "smallbook" then
        result = plugin._create_smallbook_order(orderInfo, options, vAccountInfo)
    else
        result = plugin._create_receipt_order(orderInfo, options, vAccountInfo)
    end

    if result.code then
        return result
    end
    return {
        code = 200,
        message = "success",
        data = result
    }
end

plugin._create_receipt_order = function(orderInfo, options, vAccountInfo, retried)
    -- 验证必要参数
    local valid, err_message = plugin._validate_params(options, {"sid", "aid"})
    if not valid then
        return plugin._error_response(500, err_message)
    end

    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(options.account_type)
    if not gateway then
        return plugin._error_response(500, "不支持的账号类型")
    end

    -- 构建请求URL和参数。账号类型1/2使用URL query创建，账号类型3使用JSON body创建。
    local url = gateway .. "/receipt/create"
    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }
    local result

    if options.account_type == "1" or options.account_type == "2" or options.account_type == 1 or options.account_type == 2 then
        url = url .. "?miniprogram_version=3.15.9"
        url = url .. "&remark_pic_urls="
        url = url .. "&option_list=%5B%5D"
        url = url .. "&account_type=" .. options.account_type
        if options.shop_id and options.shop_id ~= "" then
            url = url .. "&shop_id=" .. options.shop_id
        end
        url = url .. "&remark=" .. orderInfo.order_id
        url = url .. "&account_id=" .. options.aid
        url = url .. "&sid=" .. options.sid
        url = url .. "&fee=" .. orderInfo.trade_amount

        log.info(string.format("(%s) %s(%s) 创建订单,url:%s", PLUGIN, vAccountInfo.name, vAccountInfo.id, url))

        result = http.get(url, {
            headers = headers
        })
    else
        url = url .. "?miniprogram_version=3.15.9"
        url = url .. "&account_id=" .. options.aid
        url = url .. "&account_type=" .. options.account_type
        url = url .. "&sid=" .. options.sid

        log.info(string.format("(%s) %s(%s) 创建订单,url:%s", PLUGIN, vAccountInfo.name, vAccountInfo.id, url))

        local body = {
            miniprogram_version = "3.15.9",
            fee = orderInfo.trade_amount,
            remark = orderInfo.order_id,
            remark_pic_urls = "",
            option_list = {},
            receipt_item_list = {},
            sid = options.sid
        }
        if options.shop_id and options.shop_id ~= "" then
            body.shop_id = tonumber(options.shop_id)
        end

        result = http.post(url, {
            headers = headers,
            body = json.encode(body)
        })
    end

    log.debug(string.format("[插件] (%s) 创建订单 GET %s", PLUGIN, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        if not retried and (plugin._is_sid_invalid_http_result(result) or plugin._check_sid_invalid_by_probe(options)) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "创建收款单")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return plugin._error_response(500, string.format("请求失败,状态码:%d", result.status_code))
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return plugin._error_response(500, "解析返回数据失败")
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        if not retried and (plugin._is_sid_invalid_response(response) or plugin._check_sid_invalid_by_probe(options)) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "创建收款单")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return plugin._error_response(500, response.msg or "创建订单失败")
    end

    -- 提取receipt_id
    local receipt_id
    if response.data then
        if response.data.receipt then
            receipt_id = response.data.receipt.receipt_id
        end
    end
    if not receipt_id then
        return plugin._error_response(500, "未获取到receipt_id")
    end

    -- 构建获取二维码URL
    url = gateway .. "/receipt/getwxacode"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&wxacode_path_type=1"
    url = url .. "&receipt_id=" .. receipt_id
    url = url .. "&account_id=" .. options.aid
    url = url .. "&account_type=" .. options.account_type
    url = url .. "&sid=" .. options.sid

    log.debug(string.format("[插件] (%s) 获取二维码 URL: %s", PLUGIN, url))

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    -- log.debug(string.format("[插件] (%s) 获取二维码 GET %s", PLUGIN, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        if not retried and (plugin._is_sid_invalid_http_result(result) or plugin._check_sid_invalid_by_probe(options)) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "获取收款单二维码")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return plugin._error_response(500, string.format("请求失败,状态码:%d", result.status_code))
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return plugin._error_response(500, "解析返回数据失败")
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        if not retried and (plugin._is_sid_invalid_response(response) or plugin._check_sid_invalid_by_probe(options)) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "获取收款单二维码")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return plugin._error_response(500, response.msg or "获取二维码失败")
    end

    -- 提取二维码
    if not response.data then
        return plugin._error_response(500, "返回数据格式错误,缺少data字段")
    end

    local qrcode = response.data.qrcode
    if not qrcode then
        return plugin._error_response(500, "未获取到二维码")
    end

    if qrcode == "" then
        return plugin._error_response(500, "二维码内容为空")
    end

    -- 将base64转为图片文件
    local write, filePath = helper.save_image_cache_base64(qrcode)
    if not write then
        return plugin._error_response(500, "二维码保存失败")
    end

    log.info(string.format("(%s) %s(%s) 创建订单[%s] 二维码保存成功", PLUGIN, vAccountInfo.name,
        vAccountInfo.id, orderInfo.order_id))
    return { type = "qrcode", qrcode_file = filePath, url = "", content = "", out_trade_no = tostring(receipt_id) }
end

plugin._create_smallbook_order = function(orderInfo, options, vAccountInfo, retried)
    local valid, err_message = plugin._validate_params(options, {"sid"})
    if not valid then
        return plugin._error_response(500, err_message)
    end

    local url = GATEWAY.SMALLBOOK .. "/qrappsl/profile/getpayqrcode"
    url = url .. "?sid=" .. options.sid
    url = url .. "&v=6.23.1"

    log.info(string.format("(%s) %s(%s) 创建小账本订单,url:%s", PLUGIN, vAccountInfo.name,
        vAccountInfo.id, url))

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx28be8489b7a36aaa/1061/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    if result.status_code ~= 200 then
        if not retried and plugin._check_sid_invalid_by_probe(options) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "创建小账本订单")
            if ok then
                return plugin._create_smallbook_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return plugin._error_response(500, string.format("请求失败,状态码:%d", result.status_code))
    end

    local response = json.decode(result.body)
    if not response then
        return plugin._error_response(500, "解析返回数据失败")
    end

    if not response.errcode or response.errcode ~= 0 then
        if not retried and plugin._check_sid_invalid_by_probe(options) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "创建小账本订单")
            if ok then
                return plugin._create_smallbook_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return plugin._error_response(500, response.msg or "获取小账本二维码失败")
    end

    if not response.data then
        return plugin._error_response(500, "返回数据格式错误,缺少data字段")
    end

    local qrcode = response.data.qrcode_content or response.data.qrcode
    if not qrcode or qrcode == "" then
        return plugin._error_response(500, "未获取到小账本二维码")
    end

    local write, filePath = helper.save_image_cache_base64(qrcode)
    if not write then
        return plugin._error_response(500, "二维码保存失败")
    end

    log.info(string.format("(%s) %s(%s) 小账本订单[%s] 二维码保存成功", PLUGIN, vAccountInfo.name,
        vAccountInfo.id, orderInfo.order_id))

    return { type = "qrcode", qrcode_file = filePath, url = "", content = "", out_trade_no = "" }
end

-- 支付回调
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = {
            response = ""
        }
    }
end

-- 获取账号列表
function plugin.getAccountList(sid)
    local url = GATEWAY.RECEIPT_WX .. "/account/list"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&sid=" .. sid

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    -- 判断返回状态
    if result.status_code ~= 200 then
        return nil, string.format("请求账号列表失败,状态码:%d", result.status_code)
    end

    print(result.body)

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return nil, "解析账号列表数据失败"
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return nil, response.msg or "获取账号列表失败"
    end

    -- 返回账号列表数据
    if response.data and response.data.account_list then
        return response.data.account_list, nil
    end

    return nil, "账号列表为空"
end

plugin._get_shop_id_from_account_list = function(account_list, aid, account_type)
    if not account_list or account_list == "" or not aid or aid == "" then
        return nil
    end

    for line in string.gmatch(account_list, "[^\r\n]+") do
        local lineAid = string.match(line, "账号ID:([^|]+)")
        local lineType = string.match(line, "账号类型:([^|]+)")
        local shopId = string.match(line, "shop_id:([^|]+)")
        if lineAid == tostring(aid) and (not account_type or account_type == "" or lineType == tostring(account_type)) then
            if shopId and shopId ~= "" then
                return shopId
            end
        end
    end

    return nil
end

-- 心跳处理
function plugin.heartbeat(ctx)
    return {
        code = 200,
        message = "无需上报",
        data = {}
    }
end

plugin._sync_receipt_account_options = function(accountInfo, options)
    local accountList, err = plugin.getAccountList(options.sid)
    if err then
        return false, err
    end

    local lines = {}
    local activatedAccounts = {}
    for _, account in ipairs(accountList or {}) do
        if account.account_status == "ACTIVATED" then
            local shop_id = plugin._get_shop_id(options.sid, account.account_id, account.account_type) or ""
            account.shop_id = shop_id
            local line = string.format("账号ID:%s|账号类型:%s|商户名称:%s|shop_id:%s", account.account_id or "",
                account.account_type or "", account.account_name or "", shop_id)
            table.insert(lines, line)
            table.insert(activatedAccounts, account)
        end
    end

    helper.channel_account_set_option(accountInfo.id, "account_list", table.concat(lines, "\n"))

    if #activatedAccounts > 0 then
        local selected = activatedAccounts[1]
        for _, account in ipairs(activatedAccounts) do
            if tostring(account.account_id) == tostring(options.aid) and tostring(account.account_type) == tostring(options.account_type) then
                selected = account
                break
            end
        end
        helper.channel_account_set_option(accountInfo.id, "aid", selected.account_id)
        helper.channel_account_set_option(accountInfo.id, "account_type", selected.account_type)
        helper.channel_account_set_option(accountInfo.id, "shop_id", selected.shop_id or "")
        options.aid = selected.account_id
        options.account_type = tostring(selected.account_type)
        options.shop_id = selected.shop_id or ""
    end

    return true, ""
end

-- 验证账号并初始化
plugin._verify_and_init_account = function(accountInfo, options)
    -- 判断是否有SID，没有则通过当前GO项目微信网关按收款方式获取SID
    if not options.sid or options.sid == "" then
        local ok, sidErr = plugin._sync_sid_from_gateway(accountInfo, options)
        if not ok then
            return false, sidErr
        end
    elseif plugin._check_sid_invalid_by_probe(options) then
        local ok, sidErr = plugin._refresh_sid_for_retry(accountInfo, options, "定时任务")
        if not ok then
            return false, sidErr
        end
    end

    if plugin._get_pay_mode(options) == "smallbook" then
        return true, ""
    end

    -- 判断是否需要获取账号列表
    if options.account_list == "" or not string.find(options.account_list or "", "shop_id:", 1, true) then
        local ok, err = plugin._sync_receipt_account_options(accountInfo, options)
        if not ok then
            return false, err
        end
    end

    -- 判断用户是否选择了aid
    if options.aid == "" then
        return false, "请选择一个账号"
    end

    -- 判断account_type
    if options.account_type == "" then
        return false, "请选择一个账号类型"
    end

    local list_shop_id = plugin._get_shop_id_from_account_list(options.account_list, options.aid, options.account_type)
    if list_shop_id and list_shop_id ~= options.shop_id then
        helper.channel_account_set_option(accountInfo.id, "shop_id", list_shop_id)
        options.shop_id = list_shop_id
    end

    if not options.shop_id or options.shop_id == "" then
        local shop_id = plugin._get_shop_id(options.sid, options.aid, options.account_type)
        if shop_id then
            helper.channel_account_set_option(accountInfo.id, "shop_id", shop_id)
            options.shop_id = shop_id
        end
    end

    return true, ""
end

-- 二维码登录
function plugin.login_qrcode(ctx)
    local vParams = toTable(ctx.params)
    if next(vParams) == nil then vParams = toTable(ctx.plugin_option) end
    if next(vParams) == nil then vParams = toTable(ctx.plugin_options) end
    local userInfo = ctx.user_info or {}
    local accountInfo = ctx.account_info or {}
    local options = mergeOptions(ctx)

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return plugin._error_response(500, gatewayErr)
    end

    local cloudToken = helper.get_plugin_option(PLUGIN, "yun_token", "jiaowoliangzai")
    local configuredSite = vParams.domain_url or ''
    local deviceSite = (ctx.device and ctx.device.base_url) or ''
    local site = configuredSite:lower():match('^https://') and configuredSite
        or (deviceSite:lower():match('^https://') and deviceSite)
        or (configuredSite ~= '' and configuredSite)
        or deviceSite
    site = site:gsub('/+$', '')
    local req = {
        data = helper.base64_encode(json.encode({
            site = site,
            pid = tonumber(userInfo.id) or 0,
            key = userInfo.app_secret or '',
            token = cloudToken,
            proxy = getProxy(options)
        }))
    }

    local protocolPrefix = plugin._get_protocol_prefix(options)
    local data, requestErr = plugin._request_wechat_gateway("POST", serverAddress, protocolPrefix .. "/CreateID", funcs.table_http_query(req), "60s")
    if requestErr then
        return plugin._error_response(500, requestErr)
    end
    if data.code ~= "1" then
        return plugin._error_response(500, data.msg or "微信网关创建登录会话失败")
    end

    local uid = data.uid
    helper.channel_account_set_option(accountInfo.id, "bind_token", json.encode({uid = uid}))
    helper.channel_account_set_option(accountInfo.id, "uid", uid)
    helper.channel_account_set_option(accountInfo.id, "bound_login_protocol", options.login_protocol or "yyb")

    data, requestErr = plugin._request_wechat_gateway("POST", serverAddress, protocolPrefix .. "/QRCode", string.format("uid=%s", uid), "30s")
    if requestErr then
        return plugin._error_response(500, requestErr)
    end
    if data.code ~= "1" then
        return plugin._error_response(500, data.msg or "获取微信登录链接失败")
    end

    return {
        code = 200,
        message = "success",
        data = {
            qrcode = data.url,
            options = json.encode({ uid = uid })
        }
    }
end

-- 检查二维码登录状态
function plugin.login_qrcode_check(ctx)
    local params = toTable(ctx.params)
    if next(params) == nil then params = toTable(ctx.plugin_option) end
    if next(params) == nil then params = toTable(ctx.plugin_options) end
    local accountInfo = ctx.account_info or {}
    local options = mergeOptions(ctx)

    local uid = params.uid or plugin._get_bound_uid(options)
    if not uid or uid == "" then
        return plugin._error_response(500, "缺少微信登录UID")
    end

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return plugin._error_response(500, gatewayErr)
    end

    local protocolPrefix = plugin._get_protocol_prefix(options)
    local data, requestErr = plugin._request_wechat_gateway("POST", serverAddress, protocolPrefix .. "/IsLoginStatus", string.format("uid=%s", uid), "60s")
    if requestErr then
        return plugin._error_response(500, requestErr)
    end
    if data.code ~= "1" then
        if data.code == "0" then
            return plugin._error_response(201, data.msg or "请扫描二维码登录")
        end
        return plugin._error_response(500, data.msg or "微信登录状态检查失败")
    end

    helper.channel_account_set_option(accountInfo.id, "bind_token", json.encode({
        uid = uid,
        pid = data.pid
    }))
    helper.channel_account_set_option(accountInfo.id, "uid", uid)

    options.bind_token = json.encode({uid = uid, pid = data.pid})
    local ok, sidErr = plugin._sync_sid_from_gateway(accountInfo, options)
    if not ok then
        return plugin._error_response(500, sidErr)
    end

    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
    end

    return {
        code = 200,
        message = "登录成功",
        data = {}
    }
end

plugin._check_gateway_login_status = function(accountInfo, options)
    local uid = plugin._get_bound_uid(options)
    if not uid then
        return false, "请先扫码登录微信网关"
    end

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return false, gatewayErr
    end

    local protocolPrefix = plugin._get_protocol_prefix(options)
    local data, requestErr = plugin._request_wechat_gateway("POST", serverAddress, protocolPrefix .. "/IsLoginStatus", string.format("uid=%s", uid), "30s")
    if requestErr then
        return false, requestErr
    end
    if data.code ~= "1" then
        return false, data.msg or "微信网关登录状态异常"
    end
    return true, ""
end

-- 通道新增或修改
function plugin.onAccountChanged(ctx)
    local accountInfo, options
    if type(ctx) == "table" and ctx.account_info then
        accountInfo = ctx.account_info
        options = mergeOptions(ctx)
    else
        accountInfo = toTable(ctx)
        options = toTable(accountInfo.options)
    end

    local selectedProtocol = options.login_protocol or "yyb"
    local boundProtocol = options.bound_login_protocol
    if (not boundProtocol or boundProtocol == "") and plugin._get_bound_uid(options) then
        boundProtocol = "yyb"
    end
    if boundProtocol and boundProtocol ~= "" and boundProtocol ~= selectedProtocol then
        helper.channel_account_offline(accountInfo.id)
        for _, key in ipairs({"bind_token", "uid", "sid", "account_list", "aid", "account_type", "shop_id", "bound_login_protocol"}) do
            helper.channel_account_set_option(accountInfo.id, key, "")
            options[key] = ""
        end
        return { code = 200, message = "登录协议已切换，通道已离线，请重新扫码登录", data = {} }
    end

    local list_shop_id = plugin._get_shop_id_from_account_list(options.account_list, options.aid, options.account_type)
    if list_shop_id and list_shop_id ~= options.shop_id then
        helper.channel_account_set_option(accountInfo.id, "shop_id", list_shop_id)
        options.shop_id = list_shop_id
    end

    if options.account_list == "" then
        helper.channel_account_set_option(accountInfo.id, "aid", "")
        helper.channel_account_set_option(accountInfo.id, "account_type", "")
        helper.channel_account_set_option(accountInfo.id, "shop_id", "")
        options.aid = ""
        options.account_type = ""
        options.shop_id = ""
    end

    local _, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return { code = 500, message = gatewayErr, data = {} }
    end

    return { code = 200, message = "账号保存成功，请扫码登录微信网关", data = {} }
end

-- 定时任务
function plugin.cron(ctx)
    local accountInfo = ctx.account_info
    local options = ctx.account_options or ctx.plugin_options or ctx.plugin_option or {}

    local success, err_message = plugin._verify_and_init_account(accountInfo, options)
    if not success then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end
        return { code = 500, message = err_message, data = {} }
    end

    local loginOk, loginErr = plugin._check_gateway_login_status(accountInfo, options)
    if not loginOk then
        helper.channel_account_offline(accountInfo.id)
        return { code = 201, message = loginErr, data = {} }
    end

    -- 如果离线状态 则设置为在线
    if accountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(accountInfo.id)
    end

    if plugin._get_pay_mode(options) == "smallbook" then
        return plugin._handle_smallbook_orders(options, accountInfo)
    end

    -- 获取订单列表
    local orderList = plugin._get_order_list(options.account_type, options.aid, options.sid)
    if orderList == nil then
        return { code = 500, message = "获取订单列表失败", data = {} }
    end

    if not orderList or #orderList == 0 then
        return { code = 200, message = "暂无订单", data = {} }
    end

    -- 遍历订单列表处理
    for _, order in ipairs(orderList) do
        plugin._handle_order(order, options, accountInfo)
    end

    return { code = 200, message = "处理完成", data = {} }
end

-- 处理小账本订单
plugin._handle_smallbook_orders = function(options, accountInfo)
    local orderList = plugin._get_smallbook_order_list(options.sid)
    if orderList == nil then
        return { code = 500, message = "获取小账本订单列表失败", data = {} }
    end

    if not orderList or #orderList == 0 then
        return { code = 200, message = "暂无小账本订单", data = {} }
    end

    for _, order in ipairs(orderList) do
        plugin._handle_smallbook_success_order(order, options, accountInfo)
    end

    return { code = 200, message = "小账本订单处理完成", data = {} }
end

plugin._handle_smallbook_success_order = function(order, options, accountInfo)
    if not plugin._is_order_exists(order, options, accountInfo) then
        plugin._insert_and_report_order(order, plugin._extract_order_id(order.payer_remark), options, accountInfo)
    end
end

-- 处理单个订单
plugin._handle_order = function(order, options, accountInfo)
    if order.state == "close" then
        plugin._handle_closed_order(order, options)
    elseif order.state == "receiving" then
        plugin._handle_receiving_order(order, options)
    elseif order.state == "success" then
        plugin._handle_success_order(order, options, accountInfo)
    end
end

-- 处理已关闭订单
plugin._handle_closed_order = function(order, options)
    local create_time = tonumber(order.create_time)
    local now = os.time()
    -- 超过一天则删除
    if now - create_time > 86400 then -- 一天 = 86400秒
        plugin._delete_receipt(options.account_type, options.aid, options.sid, order.receipt_id)
    end
end

-- 处理接收中订单
plugin._handle_receiving_order = function(order, options)
    local create_time = tonumber(order.create_time)
    local now = os.time()
    -- 超过10分钟则关闭
    if now - create_time > 600 then -- 10分钟 = 600秒
        plugin._close_order(options.account_type, options.aid, options.sid, order.receipt_id)
    end
end

-- 处理成功订单
plugin._handle_success_order = function(order, options, accountInfo)
        -- 提取外部订单号
        local out_order_id = plugin._extract_order_id(order.remark)
        -- 如果订单不存在则录入
        if not plugin._is_order_exists(order, options, accountInfo) then
            plugin._insert_and_report_order(order, out_order_id, options, accountInfo)
        end

    -- 关闭订单
    plugin._close_order(options.account_type, options.aid, options.sid, order.receipt_id)
end

-- 从备注中提取订单号
plugin._extract_order_id = function(remark)
    local out_order_id = ""
    if remark then
        remark = string.gsub(remark, "请勿添加备注-", "")
        local matched, matchGroups = helper.regexp_match_group(remark, "^(?<order_id>\\d{20})$")
        if matched then
            if type(matchGroups) == "string" then
                matchGroups = json.decode(matchGroups)
            end
            if matchGroups["order_id"] then
                out_order_id = matchGroups["order_id"][1]
                log.info(string.format("正则匹配订单号: %s", out_order_id))
            end
        end
    end
    return out_order_id
end

plugin._get_third_order_id = function(order)
    return order.receipt_id or order.trans_id or order.id_v3
end

plugin._get_third_account = function(options)
    if plugin._get_pay_mode(options) == "smallbook" then
        return options.sid
    end
    return options.aid
end

plugin._get_order_amount = function(order)
    return order.fee or order.money or 0
end

plugin._get_order_remark = function(order)
    return order.remark or order.payer_remark or ""
end

plugin._get_order_time = function(order)
    return tonumber(order.create_time or order.timestamp or os.time())
end

plugin._get_order_type_name = function(options)
    if plugin._get_pay_mode(options) == "smallbook" then
        return "小账本收款"
    end
    return "收款单收款"
end

-- 检查订单是否存在
plugin._is_order_exists = function(order, options, accountInfo)
    return orderPayHelper.third_order_exist({
        pay_type = "wxpay",
        channel_code = YUN_WECHAT_ALL_LZ,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        third_account = plugin._get_third_account(options),
        third_order_id = plugin._get_third_order_id(order)
    })
end

-- 插入并上报订单
plugin._insert_and_report_order = function(order, out_order_id, options, accountInfo)
    local thirdOrderId = plugin._get_third_order_id(order)
    local amount = plugin._get_order_amount(order)

    -- 录入数据
    local insertId = orderPayHelper.third_order_insert({
        pay_type = "wxpay",
        channel_code = YUN_WECHAT_ALL_LZ,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        buyer_id = "",
        buyer_name = order.payer_nick_name or "",
        third_order_id = thirdOrderId,
        third_account = plugin._get_third_account(options),
        amount = amount,
        remark = plugin._get_order_remark(order),
        trans_time = plugin._get_order_time(order),
        type = plugin._get_order_type_name(options),
        out_order_id = out_order_id
    })

    -- 流水录入成功后统一上报，由系统按订单号或金额匹配
    if insertId > 0 then
        local err_code, err_message = orderPayHelper.third_order_report(insertId)
        if err_code == 200 then
            log.info(string.format("订单上报成功: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
                err_message, thirdOrderId, out_order_id, amount))
        else
            log.warning(string.format("订单上报失败: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
                err_message, thirdOrderId, out_order_id, amount))
        end
    else
        log.warning(string.format("订单录入失败, 模式: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
            plugin._get_pay_mode(options), thirdOrderId, out_order_id, amount))
    end
end

-- 获取小账本订单列表
plugin._get_smallbook_order_list = function(sid)
    local url = "https://payapp.weixin.qq.com/qrappzd/user/incomelistflexible"
    url = url .. "?sid=" .. sid
    url = url .. "&v=5.132.6"

    local now = os.time()
    local startTime = now - (now % 3600)
    local body = {
        v = "5.132.6",
        sid = sid,
        start_time = startTime,
        end_time = now,
        page_size = 10,
        sort = "desc",
        is_first = true,
        last_create_time = 0,
        last_id = ""
    }

    local resp = http.post(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Referer"] = "https://servicewechat.com/wx28be8489b7a36aaa/1061/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        },
        body = json.encode(body)
    })

    if resp.status_code ~= 200 then
        log.warning(string.format("[%s] 获取小账本订单列表失败,状态码:%d", PLUGIN, resp.status_code))
        return nil
    end

    if resp.body == "" then
        log.warning(string.format("[%s] 获取小账本订单列表失败,返回数据为空", PLUGIN))
        return nil
    end

    local data = json.decode(resp.body)
    if not data or (data.errcode ~= 0 and data.retcode ~= 0) then
        log.warning(string.format("[%s] 获取小账本订单列表失败,错误码:%d,错误信息:%s", PLUGIN,
            data and (data.errcode or data.retcode) or -1, data and (data.msg or data.errmsg or "") or ""))
        return nil
    end

    local list = {}
    if data.data and data.data.data_list then
        for _, item in ipairs(data.data.data_list) do
            local fee = tonumber(item.fee or 0)
            table.insert(list, {
                receipt_id = item.trans_id or item.id_v3,
                trans_id = item.trans_id,
                id_v3 = item.id_v3,
                fee = fee,
                money = fee,
                create_time = item.timestamp,
                timestamp = item.timestamp,
                remark = item.payer_remark or "",
                payer_remark = item.payer_remark or "",
                payer_nick_name = item.payer_user_name or ""
            })
        end
    end

    return list
end

-- 获取商户ID
plugin._get_shop_id = function(sid, account_id, account_type)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        return nil
    end

    local url = string.format(
        gateway .. "/account/get?miniprogram_version=3.15.10&account_id=%s&account_type=%s&sid=%s", account_id,
        account_type, sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }

    local resp = http.get(url, {
        headers = headers
    })

    local success, data = plugin._check_http_response(resp, account_id, "获取商户ID")
    if not success then
        return nil
    end

    if data.data and data.data.auth_shop_list and #data.data.auth_shop_list > 0 then
        return data.data.auth_shop_list[1].shop_id
    end

    return nil
end

-- 获取订单列表
plugin._get_order_list = function(account_type, account_id, sid)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 获取订单列表 不支持的账号类型:%s", PLUGIN,
            account_id, account_type))
        return nil
    end

    local url = string.format(gateway .. "/receipt/list?account_type=%s&account_id=%s&sid=%s", account_type, account_id,
        sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }

    local body = {
        miniprogram_version = "3.15.10",
        start_time = 0,
        end_time = 0,
        page_size = 10,
        state = {},
        shop_id_list = {},
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success, data = plugin._check_http_response(resp, account_id, "获取订单列表")
    if not success then
        return nil
    end

    if data.data and data.data.receipt then
        -- 过滤掉 fee > 0 的数据
        local filtered = {}
        for _, receipt in ipairs(data.data.receipt) do
            if not receipt.fee or receipt.fee > 0 then
                table.insert(filtered, receipt)
            end
        end
        return filtered
    end

    return nil
end

-- 关闭订单
plugin._close_order = function(account_type, account_id, sid, receipt_id)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 关闭订单 不支持的账号类型:%s", PLUGIN, account_id,
            account_type))
        return false
    end

    local url = string.format(gateway .. "/receipt/close?account_type=%s&account_id=%s&sid=%s", account_type,
        account_id, sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Mac MacWechat/WMPF MacWechat/3.8.7(0x13080712) UnifiedPCMacWechat(0xf2640006) XWEB/11500",
        ["Content-Type"] = "application/json",
        ["Accept"] = "*/*",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html"
    }

    local body = {
        miniprogram_version = "3.15.10",
        receipt_id = receipt_id,
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success = plugin._check_http_response(resp, account_id, "关闭订单")
    return success
end

-- 删除订单
plugin._delete_receipt = function(account_type, account_id, sid, receipt_id)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 删除订单 不支持的账号类型:%s", PLUGIN, account_id,
            account_type))
        return false
    end

    local url = string.format(gateway .. "/receipt/del?account_type=%s&account_id=%s&sid=%s", account_type, account_id,
        sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Mac MacWechat/WMPF MacWechat/3.8.7(0x13080712) UnifiedPCMacWechat(0xf2640006) XWEB/11500",
        ["Content-Type"] = "application/json",
        ["Accept"] = "*/*",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html"
    }

    local body = {
        miniprogram_version = "3.15.10",
        receipt_id = receipt_id,
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success = plugin._check_http_response(resp, account_id, "删除订单")
    return success
end

-- 统一处理订单关闭和删除
plugin._handle_order_close_and_delete = function(account_type, account_id, sid, receipt_id)
    -- 先关闭订单
    if plugin._close_order(account_type, account_id, sid, receipt_id) then
        -- 关闭成功后删除
        plugin._delete_receipt(account_type, account_id, sid, receipt_id)
        return true
    end
    return false
end

return plugin

