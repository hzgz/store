---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 V免签
-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["alipay"] = { {
                label = 'V免签',
                value = 'alipay_vmq'
            } },
            ["wxpay"] = { {
                label = 'V免签',
                value = 'wxpay_vmq'
            } },
            ["qqpay"] = { {
                label = 'V免签',
                value = 'qqpay_vmq'
            } }
        },
        options = {
            callback = 1,
            detection_interval = 0,
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'host',
                label = '通讯地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入通讯地址",
                options = {
                    tip = '如: https://xxx.com/'
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'pid',
                label = '商户ID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入商户ID",
                options = {
                    tip = "如果不需要商户ID，随便填写即可"
                }
            },
            {
                name = 'key',
                label = '通讯密钥',
                type = types.InputTypes.PASSWORD,
                default = "",
                placeholder = "请输入通讯密钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'method',
                label = '请求方式',
                type = types.InputTypes.SELECT,
                default = "POST",
                options = {
                    tip = ''
                },
                placeholder = "请选择请求方式",
                values = {
                    {
                        label = "GET",
                        value = "GET"
                    },
                    {
                        label = "POST",
                        value = "POST"
                    }
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local host = vAccountOptions['host'] .. "createOrder"
    local pid = vAccountOptions['pid']
    local key = vAccountOptions['key']
    local method = vAccountOptions['method']

    local payType = ""
    if vOrderInfo['pay_type'] == "alipay" then
        payType = "2"
    elseif vOrderInfo['pay_type'] == "qqpay" then
        payType = "4"
    elseif vOrderInfo['pay_type'] == "wxpay" then
        payType = "1"
    elseif vOrderInfo['pay_type'] == "bank" then
        payType = "3"
    end

    -- 组装提交请求
    local req = {
        mchId = pid,
        payId = vOrderInfo['order_id'],
        type = payType,
        price = vOrderInfo['trade_amount_str'],
        isHtml = "1",
        notifyUrl = vOrderInfo['notify_url'],
        returnUrl = vOrderInfo['return_url']
    }
    req.sign = helper.md5(req.payId .. req.type .. req.price .. key)

    -- 处理发送内容
    if method == "POST" then
        local content = plugin._pagePay(req, host, "正在跳转中,未跳转点击我")
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.HTML,
                qrcode = "",
                url = "",
                content = content
            }
        }
    else
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.JUMP,
                qrcode = '',
                url = host .. "?" .. funcs.table_http_query(req),
                content = "",
                out_trade_no = ""
            }
        }
    end
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    local vRequest = ctx.request
    local vParams = ctx.params
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    -- 判断请求方式
    local reqData = ""
    if vRequest['method'] == 'POST' then
        reqData = (vRequest['body'])
    else
        reqData = (vRequest['query'])
    end

    -- 获取签名内容
    local sign = plugin._getSign(reqData, vAccountOptions['key'])
    if sign == reqData['sign'] then
        -- 商户订单号
        local out_trade_no = reqData['payId']

        -- 避免精度有问题
        local price = math.floor((reqData['price'] + 0.000005) * 100)
        local reallyPrice = math.floor((reqData['reallyPrice'] + 0.000005) * 100)

        if price == reallyPrice then
            -- 通知订单处理完成
            local err_code, err_message, response = orderHelper.notify_process(json.encode({
                out_trade_no = "",
                trade_no = out_trade_no,
                amount = price
            }), json.encode(vParams), json.encode(vAccountOptions))

            return {
                code = err_code,
                message = err_message,
                data = { response = response }
            }
        end

        return {
            code = 500,
            message = "订单支付异常",
            data = { response = "" }
        }
    else
        return {
            code = 500,
            message = "签名校验失败",
            data = { response = "" }
        }
    end
end

-- 发起支付（页面跳转）
---@param param table
---@param submit_url string
---@param button string
---@return string
function plugin._pagePay(param, submit_url, button)
    local html = '<form id="dopay" action="' .. submit_url .. '" method="post">'

    for k, v in pairs(param) do
        html = html .. '<input type="hidden" name="' .. k .. '" value="' .. v .. '"/>'
    end

    html = html .. '<input type="submit" value="' .. button .. '"></form><script>document.getElementById("dopay").submit();</script>'

    return html
end

-- 签名
---@param param table
---@param key string
---@return string
function plugin._getSign(param, key)
    local payId = param['payId'] -- 商户订单号
    local type = param['type'] -- 支付方式 ：微信支付为1 支付宝支付为2 中国银联（云闪付）传入3 QQ钱包传入4
    local price = param['price'] -- 订单金额
    local reallyPrice = param['reallyPrice'] -- 实际支付金额
    return helper.md5(payId .. type .. price .. reallyPrice .. key)
end

return plugin
