# 字体资源说明

## 本地化字体文件

为了提供最佳的用户体验，建议将以下字体文件下载到此目录：

### Inter字体文件
- `Inter-Light.woff2` / `Inter-Light.woff` (300)
- `Inter-Regular.woff2` / `Inter-Regular.woff` (400)
- `Inter-Medium.woff2` / `Inter-Medium.woff` (500)
- `Inter-SemiBold.woff2` / `Inter-SemiBold.woff` (600)
- `Inter-Bold.woff2` / `Inter-Bold.woff` (700)

### Poppins字体文件
- `Poppins-Light.woff2` / `Poppins-Light.woff` (300)
- `Poppins-Regular.woff2` / `Poppins-Regular.woff` (400)
- `Poppins-SemiBold.woff2` / `Poppins-SemiBold.woff` (600)
- `Poppins-Bold.woff2` / `Poppins-Bold.woff` (700)

## 下载来源

- **Inter**: https://fonts.google.com/specimen/Inter
- **Poppins**: https://fonts.google.com/specimen/Poppins

或者从 Google Fonts Helper 下载：
- https://google-webfonts-helper.herokuapp.com/fonts/inter
- https://google-webfonts-helper.herokuapp.com/fonts/poppins

## 使用说明

1. 将字体文件放置在此目录（`templates/pay/pay13/assets/fonts/`）
2. 编辑 `../css/fonts/inter-poppins.css` 文件
3. 取消注释 `@font-face` 声明

## 字体回退

即使没有本地字体文件，模板也会自动使用系统字体：
- macOS: `-apple-system`
- Windows: `Segoe UI`, `Microsoft YaHei`
- Linux: `sans-serif`

## 性能优化

- 推荐使用 `.woff2` 格式（更小的文件大小）
- 设置了 `font-display: swap` 以避免字体加载阻塞
