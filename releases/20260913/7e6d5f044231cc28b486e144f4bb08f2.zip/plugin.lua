---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 支付宝-商家账单
local PAY_ALIPAY_BILL = "alipay_bill"


-- @class types.plugin
local plugin = {}
local buildMod11Html

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["alipay"] = { {
                label = '商家账单',
                value = PAY_ALIPAY_BILL,
                options = {
                    use_add_amount = 1,
                    use_pay_codes = 1
                }
            } }
        },
        options = {
            -- 配置项
            config = { {
                title = "应用ID",
                key = "pid",
                default = "",
                tip = "支付宝授权使用的应用ID"
            }, {
                title = "授权回调地址",
                key = "domain",
                default = "",
                tip = "支付宝授权成功后跳转地址,一般为主域名,需要在支付宝进行配置 如: https://aa.bb.com"
            } },
            -- 定时任务
            crontab_list = { {
                crontab = "*/5 * * * * *", -- 定时任务结构
                fun = "cron", -- 具体func名称
                args = "", -- 执行时传入对应的func
                name = "检查账号状态", -- 本插件内唯一
                scope = "account", -- 目标范围 order 订单(只查询订单未支付状态) account 账号 (只查询账号在线状态) system 全局
                options = {
                    has_wait_pay_order = 0 -- 账号筛选有未支付订单的
                }
            } }
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'qrcode',
                label = '收款码地址',
                type = types.InputTypes.INPUT,
                default = "",
                options = {
                    tip = '',
                    append_deqrocde = 1 -- 增加解析二维码功能
                },
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.type == 'qrcode'",
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    },
                }
            },
            {
                name = 'qrcode_file',
                label = '收款码图片',
                type = types.InputTypes.IMAGE,
                default = "",
                options = {
                    tip = ''
                },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.type == 'image'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            }, {
            name = 'pid',
            label = 'PID',
            type = types.InputTypes.INPUT,
            default = "",
            options = {
                tip = ''
            },
            placeholder = "请输入PID",
            when = "this.formModel.options.type == 'pid'",
            rules = { {
                required = true,
                trigger = { "input", "blur" },
                message = "请输入"
            } }
        }, {
            name = 'qrcode_mod',
            label = '二维码模式',
            type = types.InputTypes.SELECT,
            default = "9",
            options = {
                tip = ''
            },
            placeholder = "请选择二维码模式",
            when = "this.formModel.options.type == 'pid'",
            values = {
                {
                    label = "转账模式",
                    value = "9"
                },
                {
                    label = "模式10",
                    value = "10"
                },
                {
                    label = "模式11",
                    value = "11"
                },
                {
                    label = "转账确认单模式",
                    value = "12"
                },
            },
            rules = { {
                required = true,
                trigger = { "input", "blur" },
                message = "请输入"
            } }
        }, {
            name = 'type',
            label = '收款码类型',
            type = types.InputTypes.SELECT,
            default = "qrcode",
            options = {
                tip = ''
            },
            placeholder = "请选择收款码类型",
            values = { {
                label = "二维码",
                value = "qrcode"
            }, {
                label = "二维码图片",
                value = "image"
            }, {
                label = "PID",
                value = "pid"
            } },
            rules = { {
                required = true,
                trigger = { "input", "blur" },
                message = "请输入"
            } }
        }, {
            name = 'app_id',
            label = '应用ID',
            type = types.InputTypes.INPUT,
            default = "",
            placeholder = "请输入应用ID",
            options = {
                tip = ''
            },
            rules = { {
                required = true,
                trigger = { "input", "blur" },
                message = "请输入"
            } }
        }, {
            name = 'app_secret',
            label = '应用私钥',
            type = types.InputTypes.TEXTAREA,
            default = "",
            hidden_list = 1,
            placeholder = "请输入应用私钥",
            options = {
                tip = ''
            },
            rules = { {
                required = true,
                trigger = { "input", "blur" },
                message = "请输入"
            } }
        }, {
            name = 'scan_type',
            label = '订单检查方式',
            type = types.InputTypes.RADIO,
            default = "order_or_amount",
            options = {
                tip = ''
            },
            placeholder = "请选择订单检查方式",
            values = { {
                label = "订单号匹配不到则使用金额",
                value = "order_or_amount"
            }, {
                label = "订单号",
                value = "order"
            } },
            rules = { {
                required = true,
                trigger = { "input", "blur" },
                message = "请输入"
            } }
        }, {
            name = 'order_temp_amount',
            label = '取消订单递增金额',
            type = types.InputTypes.RADIO,
            default = "0",
            options = {
                tip = '<b>注意:</b>订单检查方式为订单号的时候才能选择[是]'
            },
            placeholder = "请选择订单检查方式",
            values = { {
                label = "否",
                value = "0"
            }, {
                label = "是",
                value = "1"
            } },
            rules = { {
                required = true,
                trigger = { "input", "blur" },
                message = "请输入"
            } }
        } }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)

    -- 全动态渲染,不存放数据库
    ---@type types.OrderCreateResp
    local ret = {
        code = 200,
        message = "success",
        data = {
            type = "render"
        }
    }
    return ret
end

-- 定时任务
---@param ctx types.CronAccountParams
---@return table JSON编码的执行结果
function plugin.cron(ctx)
    local accountInfo = ctx.account_info
    local options = ctx.account_options

    ---- 获取支付宝订单列表
    log.debug("开始查询支付宝订单")
    local code, message, list = orderPayHelper.alipay_bill_list(ctx.account_options)
    log.debug("支付宝账单",code,message,list)
    if code ~= 200 then
        -- 设置离线
        log.warning("支付宝账单拉取失败: " .. message)
        -- helper.channel_account_offline(accountInfo.id)
        return {
            code = code,
            message = message
        }
    end

    log.debug("支付宝账单拉取成功，订单数量: ", json.decode(list))

    local orderList = json.decode(list)
    -- 如果离线状态 则设置为在线
    if accountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(accountInfo.id)
    end

    ---- 录入数据
    for _, v in ipairs(orderList) do
        local amount = helper.amount_str2int(v.trans_amount)
        log.debug("支付宝账单", v.alipay_order_no, v.trans_amount, amount, v.trans_memo, v.direction)

        -- 经营码 type=交易 merchant_order_no!=""
        if v.direction ~= "收入" or amount <= 0 or (v.merchant_order_no and v.merchant_order_no ~= "" and v.type ~= "交易") or (v.type ~= "转账" and v.type ~= "交易") then
            goto continue
        end

        -- 判断第三方订单是否存在
        local exist = orderPayHelper.third_order_exist({
            pay_type = "alipay",
            channel_code = PAY_ALIPAY_BILL,
            uid = accountInfo.uid,
            account_id = accountInfo.id,
            third_account = options['app_id'],
            third_order_id = v.alipay_order_no
        })
        if exist then
            goto continue
        end

        if v.trans_memo then
            v.trans_memo = string.gsub(v.trans_memo, "请勿添加备注-", "")
        end

        local matched, matchGroups = helper.regexp_match_group(v.trans_memo, "^(?<order_id>\\d{20})$")
        local out_order_id = ""
        if matched then
            if matchGroups["order_id"] then
                log.info(matchGroups["order_id"][1], "正则数据4")

                out_order_id = matchGroups["order_id"][1]
            end
        end

        log.info("支付宝账单自动识别外部订单号,准备插入", v.alipay_order_no, out_order_id)

        -- 录入数据
        local insertId = orderPayHelper.third_order_insert({
            pay_type = "alipay",
            channel_code = PAY_ALIPAY_BILL,
            uid = accountInfo.uid,
            account_id = accountInfo.id,

            buyer_id = "",
            buyer_name = v.other_account,
            third_order_id = v.alipay_order_no,
            third_account = options['app_id'],
            amount = helper.amount_str2int(v.trans_amount),
            remark = v.trans_memo,
            trans_time = helper.datetime_to_timestamp(v.trans_dt),
            type = v.type,
            out_order_id = out_order_id
        })

        -- 录入失败
        if insertId <= 0 then
            print("外部订单插入失败", v.alipay_order_no, out_order_id)
            goto continue
        end

        -- 录入成功
        code, message = orderPayHelper.third_order_report(insertId)
        if code == 200 then
            print("订单上报成功:" .. message, v.alipay_order_no, out_order_id, v.trans_amount)
        else
            print("订单上报失败:" .. message, v.alipay_order_no, out_order_id, v.trans_amount)
        end

        -- 尾部
        ::continue::
    end

    return {
        code = 200,
        message = "处理完成"
    }
end

-- 支付数据渲染
---@param ctx types.OrderRenderParams
---@return types.OrderRenderResp
function plugin.render(ctx)
    local vOrderInfo      = ctx.order_info
    local vDeviceInfo     = ctx.device
    local vReqData        = ctx.request_data
    local vAccountOptions = ctx.account_options
    local pluginName      = PAY_ALIPAY_BILL

    ---@type types.OrderCreateRespData
    local ret             = {
        action = "render", -- 为空不需要渲染 save 保存渲染数据 render 只渲染 不保存
    }

    if vAccountOptions['type'] == 'image' then
        -- 上传的图片进行显示
        ---@type types.OrderCreateRespResp
        ret.data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode_file = vAccountOptions['qrcode_file'],
        }
    elseif vAccountOptions['type'] == 'qrcode' then
        -- 显示二维码内容
        ---@type types.OrderCreateRespResp
        ret.data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = vAccountOptions['qrcode'],
            -- scheme = "https://ds.alipay.com/?from=mobilecodec&scheme=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FsaId%3D10000007%26clientVersion%3D3.7.0.0718%26qrcode%3D" .. helper.url_encode(options['qrcode']) .. "%3F_s%3Dweb-other",
            scheme = "alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=" ..
                helper.url_encode(vAccountOptions['qrcode']) .. "%3F_s%3Dweb-other",
        }
    end

    ------------------------------------------------------PID 模式

    -- 转账模式
    if vAccountOptions['qrcode_mod'] == '9' then
        ret.data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode =
                "https://render.alipay.com/p/s/i?scheme=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000116%26actionType%3DtoAccount%26goBack%3DNO%26amount%3D" ..
                helper.amount_int2str(vOrderInfo.trade_amount) .. "%26userId%3D" .. vAccountOptions['pid'] ..
                "%26memo%3D" .. vOrderInfo.order_id,
            url = "",
            content = "",
            scheme =
                "alipayqr://platformapi/startapp?appId=20000067&url=https%3A%2F%2Frender.alipay.com%2Fp%2Fs%2Fi%3Fscheme%3Dalipays%253A%252F%252Fplatformapi%252Fstartapp%253FappId%253D20000116%2526actionType%253DtoAccount%2526goBack%253DNO%2526amount%253D" ..
                helper.amount_int2str(vOrderInfo.trade_amount) .. "%2526userId%253D" .. vAccountOptions['pid'] ..
                "%2526memo%253D" .. vOrderInfo.order_id,
            out_trade_no = ''
        }
    elseif vAccountOptions['qrcode_mod'] == '10' then
        ret.data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_use_short_url = 1,
                qrcode =
                    "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" ..
                    vAccountOptions['pid'] .. "%2522%252C%2522a%2522%253A%2522" ..
                    helper.amount_int2str(vOrderInfo.trade_amount) .. "%2522%252C%2522m%2522%253A%2522" ..
                    vOrderInfo.order_id .. "%2522%257D",
                url = "",
                content = "",
                scheme =
                    "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" ..
                    vAccountOptions['pid'] .. "%2522%252C%2522a%2522%253A%2522" ..
                    helper.amount_int2str(vOrderInfo.trade_amount) .. "%2522%252C%2522m%2522%253A%2522" ..
                    vOrderInfo.order_id .. "%2522%257D",
                out_trade_no = ''
        }
    elseif vAccountOptions['qrcode_mod'] == '11' then
        ret.data = {
                type = types.PaymentResultTypes.HTML,
                qrcode_use_short_url = 1,
                url = "",
                content = buildMod11Html(vAccountOptions['pid'],
                    helper.amount_int2str(vOrderInfo.trade_amount), vOrderInfo.order_id),
                scheme = "alipays://platformapi/startapp?appId=20000067&url=" ..
                    helper.url_encode("https://render.alipay.com/p/s/i?scheme=" ..
                        helper.url_encode(
                            "alipays://platformapi/startapp?appId=20000180&url=" ..
                            helper.url_encode(
                                orderPayHelper.get_toapp_url(vOrderInfo.order_id, vDeviceInfo.base_url)))),
                out_trade_no = ''
        }

        -- 转账确认单模式
    elseif vAccountOptions['qrcode_mod'] == '12' then
        local pid = helper.get_plugin_option(pluginName, "pid", vAccountOptions["app_id"])
        local authRedirectAddress = helper.get_plugin_option(pluginName, "domain", vDeviceInfo.base_url)

        local authUri = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id=" .. pid ..
            "&scope=auth_base&state=" .. vOrderInfo.order_id .. "&redirect_uri=" ..
            helper.url_encode(authRedirectAddress .. "/api/pay/toapp/" .. vOrderInfo.order_id)

        -- 如果在支付宝里面就直接打开
        if vDeviceInfo.is_mobile and vDeviceInfo.is_alipay then
            if vReqData.query and string.find(vReqData.query, "auth_code") then
                local uri2 =
                    "https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%7B%0A%20%20%20%20%22productCode%22%3A%20%22TRANSFER_TO_ALIPAY_ACCOUNT%22%2C%0A%20%20%20%20%22bizScene%22%3A%20%22YUEBAO%22%2C%0A%20%20%20%20%22transAmount%22%3A%20%22" ..
                    helper.amount_int2str(vOrderInfo.trade_amount) ..
                    "%22%2C%0A%20%20%20%20%22remark%22%3A%20%22" .. vOrderInfo.order_id ..
                    "%22%2C%0A%20%20%20%20%22businessParams%22%3A%7B%0A%09%09%22returnUrl%22%3A%20%22alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D2021001167654035%26nbupdate%3Dsyncforce%22%0A%09%7D%2C%0A%20%20%20%20%22payeeInfo%22%3A%20%7B%0A%20%20%20%20%20%20%20%20%22identity%22%3A%20%22" ..
                    vAccountOptions['pid'] ..
                    "%22%2C%0A%20%20%20%20%20%20%20%20%22identityType%22%3A%20%22ALIPAY_USER_ID%22%0A%20%20%20%20%7D%0A%7D"

                -- 跳转到直播
                local uri =
                    "alipays://platformapi/startapp?appId=2021003124679502&closeAllActivityAnimation=true&startMultApp=YES&transAnimate=true&url=" ..
                    helper.url_encode(uri2)

                ret.data = {
                    type = "jump",
                    url = uri
                }
            else
                ret.data = {
                    type = "jump",
                    url = authUri
                }
            end
        else
            -- 正常模式
            ret.data = {
                type = "qrcode",
                qrcode = vDeviceInfo.base_url .. "/pay/" .. vOrderInfo.order_id,
                url = "",
                content = "",
                scheme = "alipayqr://platformapi/startapp?appId=20000067&url=" ..
                    helper.url_encode(vDeviceInfo.base_url .. "/api/pay/toapp/" .. vOrderInfo.order_id),
                out_trade_no = '',
            }
        end

    end

    return {
        code = 200,
        message = "success",
        data = ret
    }
end

-- 账号被编辑
---@param ctx table
---@return types.BaseResp 返回信息
function plugin.onAccountChanged(ctx)
    local vAccountInfo = ctx.account_info
    local vChannelInfo = ctx.channel_info

    ---- 获取支付宝订单列表
    local code, message, _ = orderPayHelper.alipay_bill_list(vAccountInfo.options)
    if code ~= 200 then
        -- 设置离线
        helper.channel_account_offline(vAccountInfo.id)
        return {
            code = code,
            message = "获取失败:" .. message
        }
    end

    -- 如果离线状态 则设置为在线
    if vAccountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(vAccountInfo.id)
    end

    return {
        code = 200,
        message = "账号验证成功"
    }
end

------------------------------------------------------------------------自定义方法定义在下面

-- 构建模式11的HTML内容
---@param pid string 支付宝PID
---@param money string 金额
---@param order_id string 订单ID
---@return string HTML内容
buildMod11Html = function(pid, money, order_id)
    return [[<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>收银台</title>
    <script src="//gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script>
</head>
<body>
<script>
    var userId = "]] .. pid .. [[";
    var money = "]] .. money .. [[";
    var remark = "]] .. order_id .. [[";

    function returnApp() {
        AlipayJSBridge.call("exitApp")
    }

    function ready(a) {
        window.AlipayJSBridge ? a && a() : document.addEventListener("AlipayJSBridgeReady", a, !1)
    }

    ready(function () {
        try {
            var a = {
                actionType: "scan",
                u: userId,
                a: money,
                m: remark,
                biz_data: {
                    s: "money",
                    u: userId,
                    a: money,
                    m: remark
                }
            }
        } catch (b) {
            returnApp()
        }
        AlipayJSBridge.call("startApp", {
            appId: "20000123",
            param: a
        }, function (a) { })
    });
    document.addEventListener("resume", function (a) {
        returnApp()
    });
</script>
</body>
</html>]]
end

-- 构建模式12的HTML内容
---@param pid string 支付宝PID
---@param money string 金额
---@param order_id string 订单ID
---@return string HTML内容
local function buildMod12Html(pid, money, order_id)
    local url = string.format("https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%s",
        helper.url_encode(json.encode({
            productCode = "TRANSFER_TO_ALIPAY_ACCOUNT",
            bizScene = "YUEBAO",
            outBizNo = "",
            transAmount = money,
            remark = order_id,
            businessParams = {
                returnUrl = "alipays://platformapi/startApp?appId=20000218&bizScenario=transoutXtrans"
            },
            payeeInfo = {
                identity = pid,
                identityType = "ALIPAY_USER_ID"
            }
        })))

    return [[<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>收银台</title>
    <script src="//gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script>
</head>
<body>
<script>
    var userId = "]] .. pid .. [[";
    var money = "]] .. money .. [[";
    var remark = "]] .. order_id .. [[";

     AlipayJSBridge.call('setTitleColor', {
        color: parseInt('1959c1', 16),
        reset: false
    });
    AlipayJSBridge.call('showTitleLoading');
    AlipayJSBridge.call('setTitle', {
        title: '请稍等..',
        subtitle: 'XArrPay正在检测支付环境..'
    });
    AlipayJSBridge.call('setOptionMenu', {
        icontype: 'filter',
        redDot: '02',
    });
    AlipayJSBridge.call('showOptionMenu');
    document.addEventListener('optionMenu', function(e) {
        AlipayJSBridge.call('showPopMenu', {
            menus: [{
                name: '查看帮助',
                tag: 'tag1',
                redDot: ''
            }, {
                name: 'XArrPay',
                tag: 'tag2',
            }],
        }, function(e) {
            console.log(e)
        })
    }, false);

    AlipayJSBridge.call("pushWindow", {
        url: ']] .. url .. [[',
        param: {
            showToolBar: "NO"
        }
    });



</script>
</body>
</html>]]
end

-- 构建模式12的URI
---@param pid string 支付宝PID
---@param money string 金额
---@param order_id string 订单ID
---@return string URI地址
local function buildMod12Uri(pid, money, order_id)
    local url = string.format("https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%s",
        helper.url_encode(json.encode({
            productCode = "TRANSFER_TO_ALIPAY_ACCOUNT",
            bizScene = "YUEBAO",
            -- outBizNo = "",
            transAmount = money,
            remark = order_id,
            -- businessParams = {
            --    returnUrl = "alipays://platformapi/startApp?appId=20000218&bizScenario=transoutXtrans"
            -- },
            payeeInfo = {
                identity = pid,
                identityType = "ALIPAY_USER_ID"
            }
        })))
    return url
end

return plugin
