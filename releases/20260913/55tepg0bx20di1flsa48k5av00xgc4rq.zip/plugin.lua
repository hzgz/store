---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

-- 渠道 汇付天下
-- @class plugin
local plugin = {}

PAY_BANK_HUIFU = "huifu"

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["bank"] = { {
                label = '汇付斗拱平台',
                value = PAY_BANK_HUIFU,
                bind_pay_type = { "alipay", "wxpay", "bank" }
            } }
        },
        options = {
            callback = 1,
            detection_interval = 0
        }
    }
end

--- 网关地址
plugin.gateway = "https://api.huifu.com"

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'sys_id',
                label = '汇付系统号',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入汇付系统号",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'product_id',
                label = '汇付产品号',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入汇付产品号",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'huifu_id',
                label = '汇付子商户号',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入汇付子商户号",
                options = {
                    tip = '当主体为渠道商时需要填写，主体为直连商户时不需要填写'
                }
            },
            {
                name = 'project_id',
                label = '半支付托管项目号',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入半支付托管项目号",
                options = {
                    tip = '仅托管支付需要填写'
                }
            },
            {
                name = 'merchant_private_key',
                label = '商户私钥',
                type = types.InputTypes.TEXTAREA,
                hidden_list = 1,
                default = "",
                placeholder = "请输入商户私钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'huifu_public_key',
                label = '汇付公钥',
                type = types.InputTypes.TEXTAREA,
                hidden_list = 1,
                default = "",
                placeholder = "请输入汇付公钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local huifuId = vAccountOptions.sys_id
    if vAccountOptions.huifu_id ~= "" then
        huifuId = vAccountOptions.huifu_id
    end

    local tradeType = ""
    if vOrderInfo.pay_type == "alipay" then
        tradeType = "A_NATIVE"
    elseif vOrderInfo.pay_type == "wxpay" then
        tradeType = "T_NATIVE"
    elseif vOrderInfo.pay_type == "bank" then
        tradeType = "U_NATIVE"
    end

    local param = {
        req_date = helper.time_now_ymd_time(),
        req_seq_id = vOrderInfo.order_id,
        huifu_id = huifuId,
        trade_type = tradeType,
        trans_amt = vOrderInfo.trade_amount_str,
        goods_desc = vOrderInfo.subject,
        notify_url = vOrderInfo.notify_url,
        risk_check_data = json.encode({ ip_addr = vOrderInfo.client_ip })
    }
    
    if tradeType == "T_NATIVE" then
        param['wx_data'] = json.encode({
            product_id = "01001"
        })
    end

    local uri = plugin.gateway .. "/v3/trade/payment/jspay"

    local body = {
        sys_id = vAccountOptions.sys_id,
        product_id = vAccountOptions.product_id,
        data = param,
        sign = ""
    }
    body.sign = plugin.makeSign(param, vAccountOptions.merchant_private_key)
    
    local params = {
        query = "",
        body = json.encode(body),
        form = "",
        timeout = "30s",
        headers = {
            ["content-type"] = "application/json; charset=utf-8"
        }
    }

    local response, error_message = http.request("POST", uri, params)

    if response.status_code ~= 200 then
        return {
            code = 500,
            message = '请求响应错误 返回内容:' .. response.body,
            data = { type = "error" }
        }
    end

    log.debug("响应结果", uri, response.body)
    
    local result = json.decode(response.body)
    if result.data == nil or result.data.resp_code == nil then
        return {
            code = 500,
            message = "汇付返回结构错误",
            data = { type = "error" }
        }
    end

    result = result.data

    local err_code = result.resp_code
    if err_code == nil then
        return {
            code = 500,
            message = '请求响应错误 返回内容:' .. response.body,
            data = { type = "error" }
        }
    end
    
    local err_message = result.resp_desc
    local bank_message = result.bank_message
    if bank_message ~= nil then
        err_message = err_message .. " " .. bank_message
    end

    if err_code ~= "00000100" then
        return {
            code = 500,
            message = err_message,
            data = { type = "error" }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = result.qr_code,
            url = "",
            qrcode_use_short_url = 0,
            content = "",
            out_trade_no = ""
        }
    }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options
    local vRequest = ctx.request
    local vParams = ctx.params
    local reqData = vRequest['body']

    local reqDataObj = json.decode(reqData['resp_data'])
    if reqDataObj == nil then
        return {
            code = 500,
            message = "异步回调数据错误",
            data = { response = "" }
        }
    end

    -- 判断签名
    local reqSign = reqData['sign']
    local sign = plugin.checkNotifySign(reqData['resp_data'], reqSign, vAccountOptions.huifu_public_key)
    if sign == false then
        return {
            code = 500,
            message = "签名错误",
            data = { response = "" }
        }
    end

    -- 判断订单状态
    if reqDataObj["trans_stat"] == "S" then
        if reqDataObj["req_seq_id"] == vOrderInfo.order_id then
            -- 商户订单号
            local out_trade_no = reqDataObj['req_seq_id']
            -- 外部系统订单号
            local trade_no = reqDataObj['hf_seq_id']
            -- 避免精度有问题
            local money = math.floor((reqDataObj['trans_amt'] + 0.000005) * 100)

            -- 通知订单处理完成
            local err_code, err_message, response = orderHelper.notify_process(json.encode({
                out_trade_no = trade_no,
                trade_no = out_trade_no,
                amount = money
            }), json.encode(vParams), json.encode(vAccountOptions))

            return {
                code = err_code,
                message = err_message,
                data = { response = response }
            }
        else
            return {
                code = 500,
                message = "订单号不匹配",
                data = { response = "" }
            }
        end
    end

    return {
        code = 500,
        message = "订单状态错误",
        data = { response = "" }
    }
end

-- 生成签名
---@param params table
---@param private_key string
---@return string
function plugin.makeSign(params, private_key)
    -- 创建一个新的表来存储非空值
    local filtered_params = {}

    -- 过滤参数
    for key, value in pairs(params) do
        if value ~= nil then
            filtered_params[key] = value
        end
    end

    -- 对表进行排序
    local sorted_params = {}
    for key in pairs(filtered_params) do
        table.insert(sorted_params, key)
    end
    table.sort(sorted_params)

    -- 根据顺序添加到对象中
    local data = {}
    for _, key in ipairs(sorted_params) do
        data[key] = filtered_params[key]
    end

    local content = json.encode(data)

    return helper.rsa_private_sign_base64(content, private_key, "SHA256")
end

-- 验证回调签名
---@param content string
---@param sign string
---@param public_key string
---@return boolean
function plugin.checkNotifySign(content, sign, public_key)
    return helper.rsa_public_verify_sign_base64(content, sign, public_key, "SHA256")
end

return plugin
