/**
 * 支付页面主逻辑 - 使用PaymentSDK简化版
 */

// 使用统一的PaymentSDK
if (typeof PaymentSDK !== 'undefined') {
    document.addEventListener('DOMContentLoaded', () => {
        console.log('使用 PaymentSDK 初始化支付页面');

        // 检查订单状态决定是否显示加载状态
        const currentTime = Math.floor(Date.now() / 1000);
        const isExpired = currentTime > orderInfo.expire_time;

        // 如果订单不是待支付状态或已过期，直接显示页面内容
        if (orderInfo.status !== PaymentSDK.STATUS.WAIT_PAY || (isExpired && orderInfo.status == PaymentSDK.STATUS.WAIT_PAY)) {
            hideLoadingAndShowContent();
            checkOrderStatusAndShowContent();
        }

        // 只需要设置几个回调函数即可
        PaymentSDK.init({
            orderInfo: orderInfo,
            // DOM元素选择器 (可选)
            elements: {
                countdown: '#order-expire-countdown',    // 倒计时显示元素
                qrcode: '#order-qrcode'     // 二维码显示元素
            },

            callbacks: {
                // 订单支付成功回调
                onSuccess: (data) => {
                    console.log('订单支付成功!', data);
                    // 检查订单状态并显示相应内容
                    checkOrderStatusAndShowContent();
                    // 如果有返回地址，显示跳转倒计时
                    if (data.return_uri) {
                        showRedirectCountdown(data.return_uri, orderInfo.payed_wait_time);
                    }
                },

                // 订单过期回调
                onExpired: (data) => {
                    console.log('订单已过期', data);
                    // 更新订单状态并重新检查显示内容
                    checkOrderStatusAndShowContent();
                },

                // 支付失败/订单取消回调
                onFailure: (data) => {
                    console.log('订单已取消', data);
                    // 更新订单状态并重新检查显示内容
                    checkOrderStatusAndShowContent();
                },

                // 二维码加载完成回调
                onQrCodeLoaded: (data) => {
                    console.log('二维码加载完成', data);

                    // 隐藏加载状态，显示页面内容
                    hideLoadingAndShowContent();

                    switch (data.type) {
                        case "qrcode":
                            // 显示二维码
                            handleQrCodeDisplay(data);
                            break;
                        case "jump":
                            // 跳转到其他地方
                            if (data.uri) {
                                window.location.href = data.uri;
                            }
                            break;
                        case "text":
                            // 二维码类型显示为纯文本,不显示二维码 将二维码内容替换为 data.content
                            handleTextDisplay(data);
                            break;
                        case "html":
                            // 重新加载页面
                            window.location.reload();
                            break;
                        default:
                            console.warn('未知的二维码类型:', data.type);
                            break;
                    }

                    if (data.scheme) {
                        window.location.href = data.scheme;
                    }
                },

                // 错误处理回调
                onError: (error) => {
                    console.error('支付过程发生错误:', error);

                }
            }
        });
    });



    // 手动检查订单状态的函数 (可选)
    window.checkOrderStatus = function () {
        PaymentSDK.checkStatus().then(res => {
            orderInfo.status = res.status
            checkOrderStatusAndShowContent();
        }).catch(error => {
            console.error('手动检查状态失败:', error);
        });
    };

} else {
    console.error('PaymentSDK 未加载，请检查script标签');
    alert('支付模块加载失败，请刷新页面重试');
}

/**
 * 检查订单状态并显示相应内容
 */
function checkOrderStatusAndShowContent() {
    const qrContainer = document.getElementById('qr-container');
    const errorState = document.getElementById('error-state');
    const errorIcon = document.getElementById('error-icon');
    const errorTitle = document.getElementById('error-title');
    const errorMessage = document.getElementById('error-message');
    const paymentStatusIndicator = document.getElementById('payment-status-indicator');
    const paymentTimer = document.querySelector('.payment-timer');
    const statusBadge = paymentStatusIndicator?.querySelector('span');

    // 订单状态定义：
    // 1 = 待支付
    // 2 = 支付成功  
    // 3 = 支付失败
    // 4 = 订单关闭/取消
    // 5 = 订单超时/过期

    const currentTime = Math.floor(Date.now() / 1000);
    const isExpired = currentTime > orderInfo.expire_time;

    // 如果订单不是待支付状态或已过期，显示错误状态
    if (orderInfo.status !== PaymentSDK.STATUS.WAIT_PAY || (isExpired && orderInfo.status == PaymentSDK.STATUS.WAIT_PAY)) {
        // 隐藏二维码容器
        qrContainer.classList.add('hide');

        // 显示错误状态
        errorState.classList.add('show');

        let iconSvg, titleText, messageText, statusClass, badgeText;

        if ((isExpired && orderInfo.status == PaymentSDK.STATUS.WAIT_PAY) || orderInfo.status === PaymentSDK.STATUS.EXPIRED) {
            // 订单超时/过期
            iconSvg = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12,6 12,12 16,14"></polyline>
                       </svg>`;
            titleText = '订单已超时';
            messageText = '订单支付时间已过期，请重新下单';
            statusClass = 'expired';
            badgeText = '已过期';

            // 更新支付计时器状态
            if (paymentTimer) {
                paymentTimer.classList.add('expired');
            }

        } else if (orderInfo.status === PaymentSDK.STATUS.CLOSE) {
            // 订单关闭/取消
            iconSvg = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="15" y1="9" x2="9" y2="15"></line>
                        <line x1="9" y1="9" x2="15" y2="15"></line>
                       </svg>`;
            titleText = '订单已关闭';
            messageText = '订单已被取消或关闭，如需支付请重新下单';
            statusClass = 'cancelled';
            badgeText = '已关闭';

        } else if (orderInfo.status === PaymentSDK.STATUS.PAYED) {
            // 支付成功
            iconSvg = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <polyline points="20,6 9,17 4,12"></polyline>
                       </svg>`;
            titleText = '支付成功';
            messageText = '订单已支付完成，感谢您的购买';
            statusClass = 'success';
            badgeText = '支付成功';

        } else if (orderInfo.status === PaymentSDK.STATUS.FAIL) {
            // 支付失败
            iconSvg = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                       </svg>`;
            titleText = '支付异常';
            messageText = '订单支付出现异常，请联系客服或重新下单';
            statusClass = 'timeout';
            badgeText = '支付异常';

        }

        // 设置错误状态的内容和样式
        if (errorIcon) {
            errorIcon.innerHTML = iconSvg;
            errorIcon.className = `status-icon ${statusClass}`;
        }
        
        if (errorTitle) {
            errorTitle.textContent = titleText;
            errorTitle.className = `status-content h3 ${statusClass}`;
        }
        
        if (errorMessage) {
            errorMessage.textContent = messageText;
        }

        // 更新状态指示器
        if (statusBadge) {
            statusBadge.textContent = badgeText;
        }
        
        if (paymentStatusIndicator) {
            paymentStatusIndicator.className = `payment-status-badge ${statusClass}`;
        }

        // 为错误状态容器添加对应的类名
        if (errorState) {
            errorState.className = `payment-status-container show ${statusClass}`;
        }

        console.log(`订单状态异常: 状态=${orderInfo.status}, 是否过期=${isExpired}`);
    } else {
        // 正常待支付状态
        if (statusBadge) {
            statusBadge.textContent = '待支付';
        }
        
        if (paymentStatusIndicator) {
            paymentStatusIndicator.className = 'payment-status-badge';
        }
        
        console.log('订单状态正常，显示支付二维码');
    }
}

// 全局变量用于控制跳转倒计时
let redirectTimer = null;
let countdownInterval = null;

/**
 * 显示跳转倒计时界面
 */
function showRedirectCountdown(redirectUrl, waitTime = 3) {
    console.log(`支付成功，${waitTime}秒后自动跳转...`);

    const redirectCountdown = document.getElementById('redirect-countdown');
    const redirectSeconds = document.getElementById('redirect-seconds');

    // 隐藏二维码容器，显示跳转倒计时界面
    const qrContainer = document.getElementById('qr-container');
    if (qrContainer) {
        qrContainer.classList.add('hide');
    }
    
    redirectCountdown.classList.add('show');

    let remainingTime = waitTime;
    redirectSeconds.textContent = remainingTime;

    // 每秒更新倒计时
    countdownInterval = setInterval(() => {
        remainingTime--;
        redirectSeconds.textContent = remainingTime;

        if (remainingTime <= 0) {
            clearInterval(countdownInterval);
            // 执行跳转
            window.location.href = redirectUrl;
        }
    }, 1000);

    // 设置跳转定时器（备用，确保即使倒计时出问题也能跳转）
    redirectTimer = setTimeout(() => {
        window.location.href = redirectUrl;
    }, waitTime * 1000);
}

/**
 * 取消跳转
 */
function cancelRedirect() {
    console.log('用户取消自动跳转');

    // 清除定时器和倒计时
    if (redirectTimer) {
        clearTimeout(redirectTimer);
        redirectTimer = null;
    }

    if (countdownInterval) {
        clearInterval(countdownInterval);
        countdownInterval = null;
    }

    // 隐藏跳转倒计时界面
    const redirectCountdown = document.getElementById('redirect-countdown');
    redirectCountdown.classList.remove('show');
    
    // 重新显示二维码容器（如果订单仍然有效）
    const qrContainer = document.getElementById('qr-container');
    if (qrContainer && orderInfo.status === PaymentSDK.STATUS.PAYED) {
        // 支付成功状态下不需要重新显示二维码，保持成功状态显示
        checkOrderStatusAndShowContent();
    }
}

/**
 * 隐藏加载状态并显示主要内容
 */
function hideLoadingAndShowContent() {
    const body = document.body;
    const loadingOverlay = document.getElementById('loading-overlay');
    const mainContent = document.getElementById('main-content');

    // 移除loading类
    body.classList.remove('loading');

    // 可选：添加淡出效果
    if (loadingOverlay) {
        loadingOverlay.style.opacity = '0';
        setTimeout(() => {
            loadingOverlay.style.display = 'none';
        }, 300);
    }

    // 显示主要内容
    if (mainContent) {
        mainContent.style.width = '100%';
    }
}

/**
 * 处理二维码显示 - 根据Vue代码逻辑改写
 */
function handleQrCodeDisplay(data) {
    const qrCodeImg = document.getElementById('order-qrcode');

    if (!qrCodeImg) {
        console.error('找不到二维码图片元素');
        return;
    }

    if (data.qrcode_data) {
        // 直接使用base64或完整的图片数据
        qrCodeImg.src = data.qrcode_data;
        console.log('使用qrcode_data显示二维码');
    } else if (data.qrcode) {
        // 使用API生成二维码
        qrCodeImg.src = "/api/qrcode?text=" + encodeURIComponent(data.qrcode);
        console.log('使用qrcode文本生成二维码');
    } else if (data.content) {
        // 使用content生成二维码
        qrCodeImg.src = "/api/qrcode?text=" + encodeURIComponent(data.content);
        console.log('使用content生成二维码');
    } else {
        console.error('未找到有效的二维码数据', data);
    }
}

/**
 * 处理文本显示 - 将二维码区域替换为文本内容
 */
function handleTextDisplay(data) {
    const qrContainer = document.getElementById('qr-container');

    if (!qrContainer) {
        console.error('找不到二维码容器元素');
        return;
    }

    // 创建文本显示元素
    const textContent = document.createElement('div');
    textContent.className = 'qr-text-content';

    // 设置文本内容
    if (data.content) {
        textContent.textContent = data.content;
    } else if (data.text) {
        textContent.textContent = data.text;
    } else {
        textContent.textContent = '支付信息加载中...';
    }

    // 替换二维码内容
    qrContainer.innerHTML = '';
    qrContainer.appendChild(textContent);

    console.log('显示文本内容:', data.content || data.text);
}


