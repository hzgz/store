---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

local JK_QQPAY = "jk_qqpay"

local function decodeJsonObject(value)
    if type(value) == "table" then
        return value
    end
    if type(value) ~= "string" or value == "" then
        return nil
    end

    local ok, decoded = pcall(json.decode, value)
    if ok and type(decoded) == "table" then
        return decoded
    end
    return nil
end

local function normalizeHeartbeatStatus(value)
    if type(value) ~= "string" then
        return nil
    end
    local status = string.lower(string.match(value, "^%s*(.-)%s*$"))
    if status == "online" or status == "offline" then
        return status
    end
    return nil
end

local function accountOnlineState(account)
    local value = type(account) == "table" and account.online or nil
    if value == true or value == 1 or value == "1" then
        return true
    end
    if value == false or value == 0 or value == "0" then
        return false
    end
    return nil
end

local function tableKeys(value)
    local keys = {}
    if type(value) == "table" then
        for key in pairs(value) do
            keys[#keys + 1] = tostring(key)
        end
        table.sort(keys)
    end
    return table.concat(keys, ",")
end

local accountContainerKeys = {
    "account_info",
    "channel_account",
    "account",
    "accountInfo",
    "channelAccount"
}

local function accountFrom(value)
    if type(value) ~= "table" then
        return nil, nil
    end

    local function match(candidate)
        if type(candidate) ~= "table" then
            return nil, nil
        end
        local accountId = tonumber(candidate.id or candidate.account_id or candidate.channel_account_id or candidate.channel_id)
        if accountId ~= nil and accountId > 0 and accountId % 1 == 0 then
            return candidate, accountId
        end
        return nil, nil
    end

    local account, accountId = match(value)
    if account ~= nil then
        return account, accountId
    end

    for _, key in ipairs(accountContainerKeys) do
        account, accountId = match(decodeJsonObject(value[key]))
        if account ~= nil then
            return account, accountId
        end
    end

    local data = decodeJsonObject(value.data)
    if data ~= nil then
        account, accountId = match(data)
        if account ~= nil then
            return account, accountId
        end
        for _, key in ipairs(accountContainerKeys) do
            account, accountId = match(decodeJsonObject(data[key]))
            if account ~= nil then
                return account, accountId
            end
        end
    end

    return nil, nil
end

local heartbeatContainerKeys = {
    "heartbeat",
    "heartbeat_request",
    "request_data",
    "request",
    "body",
    "params",
    "request_info",
    "data"
}

local function extDataFrom(value, depth)
    if type(value) ~= "table" or depth < 0 then
        return nil
    end

    if value.ext_data ~= nil then
        return decodeJsonObject(value.ext_data)
    end

    for _, key in ipairs(heartbeatContainerKeys) do
        local nested = decodeJsonObject(value[key])
        local extData = extDataFrom(nested, depth - 1)
        if extData ~= nil then
            return extData
        end
    end
    return nil
end

local function heartbeatExtDataFrom(firstData, secondData)
    return extDataFrom(secondData, 2) or extDataFrom(firstData, 3)
end

-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["qqpay"] = { {
                label = 'PC自挂-QQ监控端',
                value = JK_QQPAY,
                report = 1,
                parse_msg = 1,
                options = {
                    use_add_amount = 1
                }
            } }
        },
        options = {
            callback = 0,
            detection_interval = 0,
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'qrcode',
                label = '收款码地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.type == 'url'",
                options = {
                    append_deqrocde = 1,
                    tip = ''
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = 'qrcode_file',
                label = '收款码图片',
                type = types.InputTypes.IMAGE,
                default = "",
                options = {
                    tip = ''
                },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.type == 'image'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = 'type',
                label = '收款码类型',
                type = types.InputTypes.SELECT,
                default = "url",
                options = {
                    tip = '...'
                },
                placeholder = "请选择收款码类型",
                values = {
                    {
                        label = "地址",
                        value = "url"
                    },
                    {
                        label = "图片",
                        value = "image"
                    }
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local options = ctx.account_options

    if options['type'] == 'image' then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = options['qrcode_file'],
                url = "",
                content = "",
                out_trade_no = ''
            }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = " " .. (options['qrcode'] or "") .. " ",
            url = "",
            content = "",
            out_trade_no = ''
        }
    }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = {
            response = ""
        }
    }
end

-- 客户端通过 ext_data 显式控制账号在线状态。
---@param pChannelAccount string|table
---@param pHeartbeatRequest string|table|nil
---@return table
function plugin.heartbeat(pChannelAccount, pHeartbeatRequest)
    local firstData = decodeJsonObject(pChannelAccount)
    local secondData = decodeJsonObject(pHeartbeatRequest)
    local channelAccount, accountId = accountFrom(firstData)
    if channelAccount == nil then
        channelAccount, accountId = accountFrom(secondData)
    end

    if channelAccount == nil then
        local firstLength = type(pChannelAccount) == "string" and #pChannelAccount or 0
        local secondLength = type(pHeartbeatRequest) == "string" and #pHeartbeatRequest or 0
        log.warning(string.format(
            "(jk_qqpay) 心跳账号结构无效 arg1=%s/%s keys=[%s] arg2=%s/%s keys=[%s]",
            type(pChannelAccount), firstLength, tableKeys(firstData),
            type(pHeartbeatRequest), secondLength, tableKeys(secondData)))
        return {
            code = 500,
            message = "心跳账号信息无效，请提供channel_id",
            data = {}
        }
    end

    local extData = heartbeatExtDataFrom(firstData, secondData)
    if extData == nil then
        log.warning(string.format(
            "(jk_qqpay) 心跳数据结构无效 arg1 keys=[%s] arg2 keys=[%s]",
            tableKeys(firstData), tableKeys(secondData)))
        return {
            code = 500,
            message = "心跳数据解析失败",
            data = {
                arg1_type = type(pChannelAccount),
                arg1_length = type(pChannelAccount) == "string" and #pChannelAccount or 0,
                arg1_keys = tableKeys(firstData),
                arg2_type = type(pHeartbeatRequest),
                arg2_length = type(pHeartbeatRequest) == "string" and #pHeartbeatRequest or 0,
                arg2_keys = tableKeys(secondData)
            }
        }
    end

    local status = normalizeHeartbeatStatus(extData.status)
    local currentOnline = accountOnlineState(channelAccount)
    local stateChanged = false
    local message

    if status == "online" then
        if currentOnline ~= true then
            helper.channel_account_online(accountId)
            stateChanged = true
        end
        message = stateChanged and "账号已上线" or "账号已在线，无需更新"
    elseif status == "offline" then
        if currentOnline ~= false then
            helper.channel_account_offline(accountId)
            stateChanged = true
        end
        message = stateChanged and "账号已离线" or "账号已离线，无需更新"
    else
        return {
            code = 500,
            message = "ext_data.status仅支持online或offline",
            data = {}
        }
    end

    if stateChanged then
        log.info(string.format("(%s) 心跳状态:%s account_id:%s",
            channelAccount.plugin_name or "jk_qqpay", status, tostring(accountId)))
    end
    return {
        code = 200,
        message = message,
        data = {}
    }
end

return plugin
