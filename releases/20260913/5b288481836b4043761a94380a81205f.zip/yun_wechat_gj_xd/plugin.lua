---@diagnostic disable: undefined-global
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local PLUGIN = "yun_wechat_gj_xd"
local YUN_WECHAT_GUANJIA_XD = PLUGIN
local plugin = {}

local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

---URL 解码
---@param s string
---@return string
local function urlDecode(s)
    s = tostring(s or "")
    s = s:gsub("%+", " ")
    s = s:gsub("%%(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end)
    return s
end

---@param proxy string
---@return string
local function encodeProxyCredentials(proxy)
    proxy = tostring(proxy or "")
    local prefix, userInfo, address = proxy:match("^([%w+.-]+://)([^@]+)@(.+)$")
    if not prefix then
        return proxy
    end
    local username, password = userInfo:match("^([^:]*):(.*)$")
    if not username then
        return proxy
    end
    return prefix .. helper.url_encode(username) .. ":" .. helper.url_encode(password) .. "@" .. address
end

---解析账号代理配置：不使用/自定义/本站代理池
---@param accountOptions table
---@return string
local function getProxy(accountOptions)
    accountOptions = accountOptions or {}
    local mode = accountOptions.proxy_mode or "no_proxy"
    if mode == "custom_proxy" then
        return encodeProxyCredentials(accountOptions.proxy or "")
    end
    if mode ~= "cloud_proxy" then
        return ""
    end

    local poolId = tonumber(accountOptions.proxy_pool_id or 0) or 0
    if poolId <= 0 then
        return ""
    end
    local itemId = tonumber(accountOptions.proxy_pool_item_id or 0) or 0
    local proxyItem = helper.proxy_pool_fetch(poolId, itemId)
    if proxyItem and proxyItem.proxy_url and proxyItem.proxy_url ~= "" then
        local proxyId = tonumber(proxyItem.proxy_id or 0) or 0
        if proxyId ~= itemId then
            accountOptions.proxy_pool_item_id = proxyId
            if accountOptions.account_id then
                helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", proxyId)
            end
        end
        return encodeProxyCredentials(proxyItem.proxy_url)
    end
    if itemId > 0 then
        helper.proxy_pool_release(itemId)
    end
    accountOptions.proxy_pool_item_id = 0
    if accountOptions.account_id then
        helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", "0")
    end
    return ""
end

---把代理配置转换为云端约定的代理请求头（X-Proxy-Cluster-*）
---@param accountOptions table
---@return table|nil
local function getProxyHeaders(accountOptions)
    if not accountOptions then
        return nil
    end
    local proxy = getProxy(accountOptions)
    if proxy == "" then
        return nil
    end
    local rest = proxy
    local scheme = rest:match("^([%w+.-]+)://")
    if scheme then
        rest = rest:sub(#scheme + 4)
    end
    local userInfo, address = rest:match("^([^@/]+)@(.+)$")
    if not userInfo then
        address = rest
    end
    if not address or address == "" then
        return nil
    end
    local username, password = "", ""
    if userInfo then
        username, password = userInfo:match("^([^:]*):(.*)$")
        username = urlDecode(username or "")
        password = urlDecode(password or "")
    end
    return {
        ["X-Proxy-Cluster-URL"] = address,
        ["X-Proxy-Cluster-Type"] = scheme or "socks5",
        ["X-Proxy-Cluster-User"] = username,
        ["X-Proxy-Cluster-Pass"] = password
    }
end

local function mergeOptions(ctx)
    ctx = ctx or {}
    local accountInfo = ctx.account_info or {}
    local options = {}
    for k, v in pairs(toTable(accountInfo.options)) do
        options[k] = v
    end
    for k, v in pairs(toTable(ctx.plugin_option)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.plugin_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.account_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    return options
end

-- 定义网关常量
local GATEWAY = {
    BASE = "https://payapp.wechatpay.cn",
    RECEIPT_MD = "https://payapp.wechatpay.cn/receiptmdmgr",
    RECEIPT_SJT = "https://payapp.wechatpay.cn/receiptsjtmgr",
    RECEIPT_WX = "https://payapp.wechatpay.cn/receiptwxmgr",
    SMALLBOOK = "https://smallbook.wxpapp.weixin.qq.com"
}

local WXAPP = {
    RECEIPT = {
        app_id = "wx264e9b6d4d484f51",
        login_url = "https://payapp.wechatpay.cn/receiptwxmgr/account/list?miniprogram_version=3.15.9&js_code=",
        referer = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html"
    },
    SMALLBOOK = {
        app_id = "wx28be8489b7a36aaa",
        login_url = "https://smallbook.wxpapp.weixin.qq.com/qrapp/user/login?js_code=",
        referer = "https://servicewechat.com/wx28be8489b7a36aaa/1181/page-frame.html"
    }
}

function plugin.pluginInfo()
    return {
        channels = {
            ["wxpay"] = {{
                label = '微信云端-电脑管家-XD',
                value = YUN_WECHAT_GUANJIA_XD,
                options = {
                    need_check_online = 1,
                    use_qrcode_login = 1,
                    use_add_amount = 1
                }
            } }
        },
        options = {
            detection_interval = 5,
            detection_type = "cron"
        }
    }
end

-- 获取form表单
function plugin.formItems(ctx)
    return {
        inputs = {
            {
                name = "gateway",
                label = "选择网关",
                type = "select",
                default = "",
                placeholder = "请选择网关",
                options = { chose_gateway = 1 },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择网关" } }
            },
            {
                name = "pay_mode",
                label = "收款方式",
                type = "radio",
                default = "receipt",
                options = { tip = "微信收款单支持免输入，微信小账本免挂模式" },
                placeholder = "请选择收款方式",
                values = {
                    { label = "收款单", value = "receipt" },
                    { label = "小账本", value = "smallbook" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择收款方式" } }
            },
            {
                name = "sid",
                label = "SID",
                type = "input",
                default = "",
                options = { tip = "扫码登录电脑管家后自动获取对应SID，也可手动填写" },
                placeholder = "请输入SID或扫码登录后自动获取"
            },
            {
                name = "account_list",
                label = "账号列表(一行一组)",
                type = "textarea",
                default = "",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                hidden_list = 1,
                placeholder = "清空后会重新获取",
                options = { tip = "清空后会点保存会重新获取,如需切换账号ID,可在此处复制到下面对应输入框替换" }
            },
            {
                name = "aid",
                label = "账号ID",
                type = "input",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                default = "",
                placeholder = "请输入账号ID",
                options = { tip = "请从账号列表选一组账号信息的账号ID填入此处" }
            },
            {
                name = "account_type",
                label = "账号类型",
                type = "input",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                default = "",
                placeholder = "请输入账号类型[1-3],不行就换下一个",
                options = { tip = "请从账号列表选一组账号信息的账号类型填入此处" }
            },
            {
                name = "shop_id",
                label = "店铺ID",
                type = "input",
                default = "",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                options = { tip = "店铺ID保存/定时刷新，如果shop_id为空，就不要填写，否则会报错" },
                placeholder = "请输入商户ID"
            },
            {
                name = "proxy_mode",
                label = "代理模式",
                type = "select",
                default = "no_proxy",
                options = { tip = "选择代理使用模式" },
                placeholder = "请选择代理模式",
                values = {
                    { label = "不使用代理", value = "no_proxy" },
                    { label = "使用自定义代理", value = "custom_proxy" },
                    { label = "使用本站代理池", value = "cloud_proxy" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择代理模式" } }
            },
            {
                name = "proxy",
                label = "Socks5代理地址",
                type = "input",
                default = "",
                when = "this.formModel.options.proxy_mode == 'custom_proxy'",
                options = { tip = "格式：socks5://IP:端口，或 socks5://用户名:密码@IP:端口" },
                placeholder = "例如：socks5://127.0.0.1:1080"
            },
            {
                name = "proxy_pool_id",
                label = "绑定代理池",
                type = "chose_proxy_pool",
                default = "-1",
                when = "this.formModel.options.proxy_mode == 'cloud_proxy'",
                options = { tip = "请选择绑定的代理池" },
                placeholder = "请选择代理池",
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择代理池" } }
            },
            {
                name = "proxy_pool_item_id",
                label = "绑定代理",
                type = "input",
                default = "0",
                hidden = 1
            },
            {
                name = "bind_token",
                label = "绑定的用户信息",
                type = "input",
                hidden = 1
            },
            {
                name = "guanjia_ref",
                label = "电脑管家账号",
                type = "input",
                hidden = 1
            }
        }
    }
end

-- 统一的错误响应处理
plugin._error_response = function(err_code, err_message)
    return {
        code = err_code,
        message = err_message,
        data = {}
    }
end

-- 统一的HTTP响应检查
plugin._check_http_response = function(resp, account_id, operation)
    if resp == nil then
        log.warning(string.format("[%s] (%s) %s请求失败", PLUGIN, account_id, operation))
        return false
    end

    if resp.status_code ~= 200 then
        log.warning(string.format("[%s] (%s) %s失败,状态码:%d", PLUGIN, account_id, operation,
            resp.status_code))
        return false
    end

    if resp.body == "" then
        log.warning(string.format("[%s] (%s) %s失败,返回数据为空", PLUGIN, account_id, operation))
        return false
    end

    local data = json.decode(resp.body)
    if not data or data.errcode ~= 0 then
        log.warning(string.format("[%s] (%s) %s失败,错误码:%d", PLUGIN, account_id, operation,
            data and data.errcode or -1))
        return false
    end

    return true, data
end

-- 获取云端网关地址
plugin._get_cloud_gateway = function(options)
    if not options or not options.gateway or options.gateway == "" then
        return nil, "暂未配置支付网关"
    end

    local serverAddress = helper.channel_gateway_addr(options.gateway)
    if serverAddress == "" then
        return nil, "暂未配置支付网关"
    end
    return serverAddress, nil
end

plugin._request_guanjia_api = function(method, serverAddress, path, body, timeout, accountOptions)
    local headers = {
        ["Content-Type"] = "application/json",
        ["Accept"] = "application/json"
    }
    local proxyHeaders = getProxyHeaders(accountOptions)
    if proxyHeaders then
        for key, value in pairs(proxyHeaders) do
            headers[key] = value
        end
    end
    local requestOptions = {
        timeout = timeout or "60s",
        headers = headers
    }
    if method ~= "GET" then
        requestOptions.body = json.encode(body or {})
    end

    local response, requestErr
    if method == "GET" then
        response, requestErr = http.get(serverAddress .. path, requestOptions)
    else
        response, requestErr = http.post(serverAddress .. path, requestOptions)
    end
    if requestErr ~= nil then
        return nil, "请求电脑管家接口失败: " .. tostring(requestErr)
    end
    if not response or not response.body or response.body == "" then
        return nil, "电脑管家接口响应为空"
    end

    local envelope = json.decode(response.body)
    if not envelope then
        return nil, "电脑管家接口响应解析失败"
    end
    if response.status_code ~= 200 or envelope.ok == false or
        (envelope.code ~= nil and tonumber(envelope.code) ~= 0) then
        return nil, envelope.msg or envelope.message or envelope.error or
            string.format("电脑管家接口 HTTP %s", tostring(response.status_code))
    end
    if envelope.data ~= nil then
        return envelope.data, nil
    end
    return envelope, nil
end

plugin._get_pay_mode = function(options)
    if options and options.pay_mode == "smallbook" then
        return "smallbook"
    end
    return "receipt"
end

plugin._extract_receipt_sid = function(data)
    if type(data) == "string" then
        local ok, decoded = pcall(json.decode, data)
        if ok then
            return plugin._extract_receipt_sid(decoded)
        end
        return nil
    end
    if type(data) ~= "table" then
        return nil
    end
    local sid = data.sid or data.Sid or data.receipt_sid or data.receiptSid
    if sid ~= nil and tostring(sid) ~= "" then
        return tostring(sid)
    end
    return plugin._extract_receipt_sid(data.data) or plugin._extract_receipt_sid(data.result)
end

plugin._save_sid_from_code = function(accountInfo, options, code)
    local app = WXAPP.RECEIPT
    local sidName = "收款单SID"
    if plugin._get_pay_mode(options) == "smallbook" then
        app = WXAPP.SMALLBOOK
        sidName = "小账本SID"
    end

    if not code or code == "" then
        return false, "电脑管家未返回" .. sidName .. "登录 code"
    end

    local loginResp = http.get(app.login_url .. tostring(code), {
        timeout = "30s",
        headers = {
            ["xweb_xhr"] = "1",
            ["Accept"] = "application/json",
            ["Referer"] = app.referer
        }
    })
    if not loginResp or loginResp.status_code ~= 200 or not loginResp.body or loginResp.body == "" then
        return false, "使用电脑管家 code 获取" .. sidName .. "失败"
    end

    local loginData = json.decode(loginResp.body)
    local sid = plugin._extract_receipt_sid(loginData)
    if not sid or sid == "" then
        return false, (loginData and (loginData.msg or loginData.errmsg)) or "小程序接口未返回" .. sidName
    end

    helper.channel_account_set_option(accountInfo.id, "sid", sid)
    options.sid = sid
    return true, ""
end

plugin._get_bound_ref = function(options)
    if not options then
        return nil
    end
    if options.guanjia_ref and options.guanjia_ref ~= "" then
        return tostring(options.guanjia_ref)
    end
    local bindInfo = toTable(options.bind_token)
    local ref = bindInfo.ref or bindInfo.bind_account
    if ref and ref ~= "" then
        return tostring(ref)
    end
    return nil
end

plugin._sync_sid_from_gateway = function(accountInfo, options)
    if accountInfo and accountInfo.id then
        options.account_id = options.account_id or accountInfo.id
    end
    local ref = plugin._get_bound_ref(options)
    if not ref then
        return false, "请先扫码登录电脑管家"
    end
    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return false, gatewayErr
    end
    local app = plugin._get_pay_mode(options) == "smallbook" and WXAPP.SMALLBOOK or WXAPP.RECEIPT
    local data, requestErr = plugin._request_guanjia_api("POST", serverAddress,
        "/guanjia/api/get-code", { ref = ref, appid = app.app_id }, "120s", options)
    if requestErr then
        return false, requestErr
    end
    local code = data and (data.code or data.Code) or nil
    return plugin._save_sid_from_code(accountInfo, options, code)
end

plugin._sync_receipt_sid_from_gateway = function(accountInfo, options)
    return plugin._sync_sid_from_gateway(accountInfo, options)
end

plugin._is_sid_invalid_response = function(response)
    if type(response) == "string" then
        return string.find(response, "登录态", 1, true) ~= nil
    end
    if type(response) ~= "table" then
        return false
    end
    return plugin._is_sid_invalid_response(response.msg) or plugin._is_sid_invalid_response(response.data)
end

plugin._refresh_sid_for_retry = function(accountInfo, options, scene)
    log.warning(string.format("(%s) %s SID可能已失效，尝试从电脑管家持久账号刷新SID", PLUGIN, scene or "创建订单"))
    local ok, sidErr = plugin._sync_sid_from_gateway(accountInfo, options)
    if not ok then
        return false, sidErr
    end
    if plugin._get_pay_mode(options) ~= "smallbook" then
        local initOk, initErr = plugin._sync_receipt_account_options(accountInfo, options)
        if not initOk then
            return false, initErr
        end
    end
    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
        accountInfo.online = 1
    end
    return true, ""
end

plugin._is_sid_invalid_http_result = function(result)
    if not result or not result.body or result.body == "" then
        return false
    end
    local data = json.decode(result.body)
    return plugin._is_sid_invalid_response(data)
end

plugin._check_sid_invalid_by_probe = function(options)
    if not options or not options.sid or options.sid == "" then
        return false
    end

    local result
    if plugin._get_pay_mode(options) == "smallbook" then
        local url = "https://payapp.weixin.qq.com/qrappzd/user/incomelistflexible?sid=" .. options.sid
        result = http.get(url, {
            headers = {
                ["xweb_xhr"] = "1",
                ["Content-Type"] = "application/json",
                ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx28be8489b7a36aaa/1181/page-frame.html"
            }
        })
    else
        local url = "https://payapp.wechatpay.cn/receiptwxmgr/account/list?miniprogram_version&sid=" .. options.sid
        result = http.get(url, {
            headers = {
                ["xweb_xhr"] = "1",
                ["Content-Type"] = "application/json",
                ["Accept"] = "*/*",
                ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html"
            }
        })
    end

    return plugin._is_sid_invalid_http_result(result)
end

-- 参数验证
plugin._validate_params = function(params, required_fields)
    for _, field in ipairs(required_fields) do
        if not params[field] or params[field] == "" then
            return false, string.format("缺少必要参数: %s", field)
        end
    end
    return true
end

-- 账号类型判断
plugin._get_gateway_by_account_type = function(account_type)
    account_type = tonumber(account_type) or account_type
    if account_type == 1 or account_type == "1" then
        return GATEWAY.RECEIPT_MD
    elseif account_type == 2 or account_type == "2" then
        return GATEWAY.RECEIPT_WX
    elseif account_type == 3 or account_type == "3" then
        return GATEWAY.RECEIPT_SJT
    end
    return nil
end

-- 创建订单
function plugin.create(ctx)
    local orderInfo = ctx.order_info
    local vAccountInfo = ctx.account_info or {}
    local options = ctx.account_options or json.decode(vAccountInfo.options or "{}") or {}
    local result

    if plugin._get_pay_mode(options) == "smallbook" then
        result = plugin._create_smallbook_order(orderInfo, options, vAccountInfo)
    else
        result = plugin._create_receipt_order(orderInfo, options, vAccountInfo)
    end

    if result.code then
        return result
    end
    if result.err_code and result.err_code ~= 200 then
        return {
            code = result.err_code,
            message = result.err_message or "创建订单失败",
            data = {}
        }
    end
    return {
        code = 200,
        message = "success",
        data = result
    }
end

plugin._create_receipt_order = function(orderInfo, options, vAccountInfo, retried)
    -- 验证必要参数
    local valid, err_message = plugin._validate_params(options, {"sid", "aid"})
    if not valid then
        return plugin._error_response(500, err_message)
    end

    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(options.account_type)
    if not gateway then
        return plugin._error_response(500, "不支持的账号类型")
    end

    -- 构建请求URL和参数。账号类型1/2使用URL query创建，账号类型3使用JSON body创建。
    local url = gateway .. "/receipt/create"
    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }
    local result

    if options.account_type == "1" or options.account_type == "2" or options.account_type == 1 or options.account_type == 2 then
        url = url .. "?miniprogram_version=3.15.9"
        url = url .. "&remark_pic_urls="
        url = url .. "&option_list=%5B%5D"
        url = url .. "&account_type=" .. options.account_type
        if options.shop_id and options.shop_id ~= "" then
            url = url .. "&shop_id=" .. options.shop_id
        end
        url = url .. "&remark=" .. orderInfo.order_id
        url = url .. "&account_id=" .. options.aid
        url = url .. "&sid=" .. options.sid
        url = url .. "&fee=" .. orderInfo.trade_amount

        log.info(string.format("(%s) %s(%s) 创建订单,url:%s", PLUGIN, vAccountInfo.name, vAccountInfo.id, url))

        result = http.get(url, {
            headers = headers
        })
    else
        url = url .. "?miniprogram_version=3.15.9"
        url = url .. "&account_id=" .. options.aid
        url = url .. "&account_type=" .. options.account_type
        url = url .. "&sid=" .. options.sid

        log.info(string.format("(%s) %s(%s) 创建订单,url:%s", PLUGIN, vAccountInfo.name, vAccountInfo.id, url))

        local body = {
            miniprogram_version = "3.15.9",
            fee = orderInfo.trade_amount,
            remark = orderInfo.order_id,
            remark_pic_urls = "",
            option_list = {},
            receipt_item_list = {},
            sid = options.sid
        }
        if options.shop_id and options.shop_id ~= "" then
            body.shop_id = tonumber(options.shop_id)
        end

        result = http.post(url, {
            headers = headers,
            body = json.encode(body)
        })
    end

    log.debug(string.format("[插件] (%s) 创建订单 GET %s", PLUGIN, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        if not retried and (plugin._is_sid_invalid_http_result(result) or plugin._check_sid_invalid_by_probe(options)) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "创建收款单")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return { err_code = 500, err_message = string.format("请求失败,状态码:%d", result.status_code) }
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return { err_code = 500, err_message = "解析返回数据失败" }
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        if not retried and (plugin._is_sid_invalid_response(response) or plugin._check_sid_invalid_by_probe(options)) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "创建收款单")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return { err_code = 500, err_message = response.msg or "创建订单失败" }
    end

    -- 提取receipt_id
    local receipt_id
    if response.data then
        if response.data.receipt then
            receipt_id = response.data.receipt.receipt_id
        end
    end
    if not receipt_id then
        return { err_code = 500, err_message = "未获取到receipt_id" }
    end

    -- 构建获取二维码URL
    url = gateway .. "/receipt/getwxacode"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&wxacode_path_type=1"
    url = url .. "&receipt_id=" .. receipt_id
    url = url .. "&account_id=" .. options.aid
    url = url .. "&account_type=" .. options.account_type
    url = url .. "&sid=" .. options.sid

    log.debug(string.format("[插件] (%s) 获取二维码 URL: %s", PLUGIN, url))

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    -- log.debug(string.format("[插件] (%s) 获取二维码 GET %s", PLUGIN, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        if not retried and (plugin._is_sid_invalid_http_result(result) or plugin._check_sid_invalid_by_probe(options)) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "获取收款单二维码")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return { err_code = 500, err_message = string.format("请求失败,状态码:%d", result.status_code) }
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return { err_code = 500, err_message = "解析返回数据失败" }
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        if not retried and (plugin._is_sid_invalid_response(response) or plugin._check_sid_invalid_by_probe(options)) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "获取收款单二维码")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return { err_code = 500, err_message = response.msg or "获取二维码失败" }
    end

    -- 提取二维码
    if not response.data then
        return { err_code = 500, err_message = "返回数据格式错误,缺少data字段" }
    end

    local qrcode = response.data.qrcode
    if not qrcode then
        return { err_code = 500, err_message = "未获取到二维码" }
    end

    if qrcode == "" then
        return { err_code = 500, err_message = "二维码内容为空" }
    end

    -- 将base64转为图片文件
    local write, filePath = helper.save_image_cache_base64(qrcode)
    if not write then
        return { err_code = 500, err_message = "二维码保存失败" }
    end

    log.info(string.format("(%s) %s(%s) 创建订单[%s] 二维码保存成功", PLUGIN, vAccountInfo.name,
        vAccountInfo.id, orderInfo.order_id))
    return { type = "qrcode", qrcode_file = filePath, qrcode = "", url = "", content = "", out_trade_no = tostring(receipt_id), err_code = 200, err_message = "" }
end

plugin._create_smallbook_order = function(orderInfo, options, vAccountInfo, retried)
    local valid, err_message = plugin._validate_params(options, {"sid"})
    if not valid then
        return plugin._error_response(500, err_message)
    end

    local url = GATEWAY.SMALLBOOK .. "/qrappsl/profile/getpayqrcode"
    url = url .. "?sid=" .. options.sid
    url = url .. "&v=6.23.1"

    log.info(string.format("(%s) %s(%s) 创建小账本订单,url:%s", PLUGIN, vAccountInfo.name,
        vAccountInfo.id, url))

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx28be8489b7a36aaa/1181/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    if result.status_code ~= 200 then
        if not retried and plugin._check_sid_invalid_by_probe(options) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "创建小账本订单")
            if ok then
                return plugin._create_smallbook_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return plugin._error_response(500, string.format("请求失败,状态码:%d", result.status_code))
    end

    local response = json.decode(result.body)
    if not response then
        return plugin._error_response(500, "解析返回数据失败")
    end

    if not response.errcode or response.errcode ~= 0 then
        if not retried and plugin._check_sid_invalid_by_probe(options) then
            local ok, sidErr = plugin._refresh_sid_for_retry(vAccountInfo, options, "创建小账本订单")
            if ok then
                return plugin._create_smallbook_order(orderInfo, options, vAccountInfo, true)
            end
            return plugin._error_response(500, sidErr)
        end
        return plugin._error_response(500, response.msg or "获取小账本二维码失败")
    end

    if not response.data then
        return plugin._error_response(500, "返回数据格式错误,缺少data字段")
    end

    local qrcode = response.data.qrcode_content or response.data.qrcode
    if not qrcode or qrcode == "" then
        return plugin._error_response(500, "未获取到小账本二维码")
    end

    local write, filePath = helper.save_image_cache_base64(qrcode)
    if not write then
        return plugin._error_response(500, "二维码保存失败")
    end

    log.info(string.format("(%s) %s(%s) 小账本订单[%s] 二维码保存成功", PLUGIN, vAccountInfo.name,
        vAccountInfo.id, orderInfo.order_id))

    return { type = "qrcode", qrcode_file = filePath, qrcode = "", url = "", content = "", out_trade_no = tostring(orderInfo.order_id), err_code = 200, err_message = "" }
end

-- 支付回调
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = {
            response = ""
        }
    }
end

-- 获取账号列表
function plugin.getAccountList(sid)
    local url = GATEWAY.RECEIPT_WX .. "/account/list"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&sid=" .. sid

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    -- 判断返回状态
    if result.status_code ~= 200 then
        return nil, string.format("请求账号列表失败,状态码:%d", result.status_code)
    end

    print(result.body)

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return nil, "解析账号列表数据失败"
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return nil, response.msg or "获取账号列表失败"
    end

    -- 返回账号列表数据
    if response.data and response.data.account_list then
        return response.data.account_list, nil
    end

    return nil, "账号列表为空"
end

plugin._get_shop_id_from_account_list = function(account_list, aid, account_type)
    if not account_list or account_list == "" or not aid or aid == "" then
        return nil
    end

    for line in string.gmatch(account_list, "[^\r\n]+") do
        local lineAid = string.match(line, "账号ID:([^|]+)")
        local lineType = string.match(line, "账号类型:([^|]+)")
        local shopId = string.match(line, "shop_id:([^|]+)")
        if lineAid == tostring(aid) and (not account_type or account_type == "" or lineType == tostring(account_type)) then
            if shopId and shopId ~= "" then
                return shopId
            end
        end
    end

    return nil
end

-- 心跳处理
function plugin.heartbeat(ctx)
    return {
        code = 200,
        message = "无需上报"
    }
end

plugin._sync_receipt_account_options = function(accountInfo, options)
    local accountList, err = plugin.getAccountList(options.sid)
    if err then
        return false, err
    end

    local lines = {}
    local activatedAccounts = {}
    for _, account in ipairs(accountList or {}) do
        if account.account_status == "ACTIVATED" then
            local shop_id = plugin._get_shop_id(options.sid, account.account_id, account.account_type) or ""
            account.shop_id = shop_id
            local line = string.format("账号ID:%s|账号类型:%s|商户名称:%s|shop_id:%s", account.account_id or "",
                account.account_type or "", account.account_name or "", shop_id)
            table.insert(lines, line)
            table.insert(activatedAccounts, account)
        end
    end

    helper.channel_account_set_option(accountInfo.id, "account_list", table.concat(lines, "\n"))

    if #activatedAccounts > 0 then
        local selected = activatedAccounts[1]
        for _, account in ipairs(activatedAccounts) do
            if tostring(account.account_id) == tostring(options.aid) and tostring(account.account_type) == tostring(options.account_type) then
                selected = account
                break
            end
        end
        helper.channel_account_set_option(accountInfo.id, "aid", selected.account_id)
        helper.channel_account_set_option(accountInfo.id, "account_type", selected.account_type)
        helper.channel_account_set_option(accountInfo.id, "shop_id", selected.shop_id or "")
        options.aid = selected.account_id
        options.account_type = tostring(selected.account_type)
        options.shop_id = selected.shop_id or ""
    end

    return true, ""
end

-- 验证账号并初始化
plugin._verify_and_init_account = function(accountInfo, options)
    -- 没有SID时，通过持久化的电脑管家账号重新获取目标小程序 code。
    if not options.sid or options.sid == "" then
        local ok, sidErr = plugin._sync_sid_from_gateway(accountInfo, options)
        if not ok then
            return false, sidErr
        end
    elseif plugin._check_sid_invalid_by_probe(options) then
        return plugin._refresh_sid_for_retry(accountInfo, options, "定时任务")
    end

    if plugin._get_pay_mode(options) == "smallbook" then
        return true, ""
    end

    -- 判断是否需要获取账号列表
    if options.account_list == "" or not string.find(options.account_list or "", "shop_id:", 1, true) then
        local ok, err = plugin._sync_receipt_account_options(accountInfo, options)
        if not ok then
            return false, err
        end
    end

    -- 判断用户是否选择了aid
    if options.aid == "" then
        return false, "请选择一个账号"
    end

    -- 判断account_type
    if options.account_type == "" then
        return false, "请选择一个账号类型"
    end

    local list_shop_id = plugin._get_shop_id_from_account_list(options.account_list, options.aid, options.account_type)
    if list_shop_id and list_shop_id ~= options.shop_id then
        helper.channel_account_set_option(accountInfo.id, "shop_id", list_shop_id)
        options.shop_id = list_shop_id
    end

    if not options.shop_id or options.shop_id == "" then
        local shop_id = plugin._get_shop_id(options.sid, options.aid, options.account_type)
        if shop_id then
            helper.channel_account_set_option(accountInfo.id, "shop_id", shop_id)
            options.shop_id = shop_id
        end
    end

    return true, ""
end

-- 二维码登录
function plugin.login_qrcode(ctx)
    local accountInfo = toTable(ctx.account_info)
    local options = mergeOptions(ctx)
    options.account_id = options.account_id or accountInfo.id

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return plugin._error_response(500, gatewayErr)
    end

    local app = plugin._get_pay_mode(options) == "smallbook" and WXAPP.SMALLBOOK or WXAPP.RECEIPT
    local data, requestErr = plugin._request_guanjia_api("POST", serverAddress,
        "/guanjia/api/qrcode", { appid = app.app_id }, "60s", options)
    if requestErr then
        return plugin._error_response(500, requestErr)
    end
    if not data or not data.uuid or data.uuid == "" then
        return plugin._error_response(500, "电脑管家未返回登录会话")
    end
    if not data.qrcode or data.qrcode == "" then
        return plugin._error_response(500, "电脑管家未返回登录二维码")
    end

    local sessionID = tostring(data.uuid)
    local bindToken = json.encode({session_id = sessionID, appid = app.app_id})
    helper.channel_account_set_option(accountInfo.id, "bind_token", bindToken)
    return {
        code = 200,
        message = "success",
        data = {
            qrcode = data.qrcode,
            options = json.encode({ session_id = sessionID, appid = app.app_id })
        }
    }
end

-- 检查二维码登录状态
function plugin.login_qrcode_check(ctx)
    local params, accountInfo, options
    if type(ctx) == "table" and (ctx.account_info or ctx.params) then
        params = toTable(ctx.params or ctx.plugin_option or ctx.plugin_options)
        accountInfo = toTable(ctx.account_info)
        options = mergeOptions(ctx)
    else
        params = {}
        accountInfo = toTable(ctx)
        options = toTable(accountInfo.options)
    end
    options.account_id = options.account_id or accountInfo.id

    local bindInfo = toTable(options.bind_token)
    local sessionID = params.session_id or options.session_id or bindInfo.session_id
    if not sessionID or sessionID == "" then
        return plugin._error_response(500, "缺少电脑管家登录会话")
    end

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return plugin._error_response(500, gatewayErr)
    end

    local data, requestErr = plugin._request_guanjia_api("GET", serverAddress,
        "/guanjia/api/status?uuid=" .. tostring(sessionID), nil, "30s", options)
    if requestErr then
        return plugin._error_response(500, requestErr)
    end
    if data.status == "pending" or data.status == "ready" then
        return plugin._error_response(201, "请扫描电脑管家登录二维码并在微信确认")
    end
    if data.status ~= "authorized" then
        return plugin._error_response(500, data.error or
            ("电脑管家登录状态异常: " .. tostring(data.status or "unknown")))
    end

    local result = data.result or {}
    local code = result.code or result.Code
    local ref = result.ref or result.bind_account
    if not ref or tostring(ref) == "" then
        return plugin._error_response(500, "电脑管家未返回持久账号标识")
    end
    ref = tostring(ref)
    local ok, sidErr = plugin._save_sid_from_code(accountInfo, options, code)
    if not ok then
        return plugin._error_response(500, sidErr)
    end

    local completedToken = json.encode({
        session_id = tostring(sessionID),
        appid = params.appid or bindInfo.appid,
        ref = ref,
        uin = result.uin,
        bind_account = result.bind_account
    })
    helper.channel_account_set_option(accountInfo.id, "bind_token", completedToken)
    helper.channel_account_set_option(accountInfo.id, "guanjia_ref", ref)
    options.bind_token = completedToken
    options.guanjia_ref = ref

    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
    end

    return {
        code = 200,
        message = "登录成功",
        data = {}
    }
end

plugin._check_gateway_login_status = function(accountInfo, options)
    if accountInfo and accountInfo.id then
        options.account_id = options.account_id or accountInfo.id
    end
    local ref = plugin._get_bound_ref(options)
    if not ref then
        return false, "请先扫码登录电脑管家"
    end
    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return false, gatewayErr
    end
    local accounts, requestErr = plugin._request_guanjia_api("GET", serverAddress,
        "/guanjia/api/accounts", nil, "30s", options)
    if requestErr then
        return false, requestErr
    end
    local found = false
    for _, account in ipairs(accounts or {}) do
        if tostring(account.ref or account.bind_account or "") == tostring(ref) then
            if account.status == "expired" then
                return false, "电脑管家账号已失效，请重新扫码登录"
            end
            found = true
            break
        end
    end
    if not found then
        return false, "电脑管家账号不存在，请重新扫码登录"
    end
    if not options.sid or options.sid == "" then
        return false, "电脑管家账号已绑定，正在刷新SID"
    end
    if plugin._check_sid_invalid_by_probe(options) then
        return plugin._refresh_sid_for_retry(accountInfo, options, "在线检查")
    end
    return true, ""
end

-- 通道新增或修改
function plugin.onAccountChanged(ctx)
    local accountInfo, options
    if type(ctx) == "table" and ctx.account_info then
        accountInfo = ctx.account_info
        options = mergeOptions(ctx)
    else
        accountInfo = toTable(ctx)
        options = toTable(accountInfo.options)
    end

    local list_shop_id = plugin._get_shop_id_from_account_list(options.account_list, options.aid, options.account_type)
    if list_shop_id and list_shop_id ~= options.shop_id then
        helper.channel_account_set_option(accountInfo.id, "shop_id", list_shop_id)
        options.shop_id = list_shop_id
    end

    if options.account_list == "" then
        helper.channel_account_set_option(accountInfo.id, "aid", "")
        helper.channel_account_set_option(accountInfo.id, "account_type", "")
        helper.channel_account_set_option(accountInfo.id, "shop_id", "")
        options.aid = ""
        options.account_type = ""
        options.shop_id = ""
    end

    local _, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return { code = 500, message = gatewayErr, data = {} }
    end

    return { code = 200, message = "账号保存成功，请扫码登录电脑管家", data = {} }
end

-- 定时任务
function plugin.cron(ctx)
    local accountInfo = ctx.account_info
    local options = ctx.account_options or ctx.plugin_options or ctx.plugin_option or {}

    local success, err_message = plugin._verify_and_init_account(accountInfo, options)
    if not success then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end
        return { code = 500, message = err_message, data = {} }
    end

    local loginOk, loginErr = plugin._check_gateway_login_status(accountInfo, options)
    if not loginOk then
        helper.channel_account_offline(accountInfo.id)
        return { code = 201, message = loginErr, data = {} }
    end

    -- 如果离线状态 则设置为在线
    if accountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(accountInfo.id)
    end

    if plugin._get_pay_mode(options) == "smallbook" then
        return plugin._handle_smallbook_orders(options, accountInfo)
    end

    -- 获取订单列表
    local orderList = plugin._get_order_list(options.account_type, options.aid, options.sid)
    if orderList == nil then
        return { code = 500, message = "获取订单列表失败", data = {} }
    end

    if not orderList or #orderList == 0 then
        return { code = 200, message = "暂无订单", data = {} }
    end

    -- 遍历订单列表处理
    for _, order in ipairs(orderList) do
        plugin._handle_order(order, options, accountInfo)
    end

    return { code = 200, message = "处理完成", data = {} }
end

-- 处理小账本订单
plugin._handle_smallbook_orders = function(options, accountInfo)
    local orderList = plugin._get_smallbook_order_list(options.sid)
    if orderList == nil then
        return { code = 500, message = "获取小账本订单列表失败", data = {} }
    end

    if not orderList or #orderList == 0 then
        return { code = 200, message = "暂无小账本订单", data = {} }
    end

    for _, order in ipairs(orderList) do
        plugin._handle_smallbook_success_order(order, options, accountInfo)
    end

    return { code = 200, message = "小账本订单处理完成", data = {} }
end

plugin._handle_smallbook_success_order = function(order, options, accountInfo)
    if not plugin._is_order_exists(order, options, accountInfo) then
        plugin._insert_and_report_order(order, plugin._extract_order_id(order.payer_remark), options, accountInfo)
    end
end

-- 处理单个订单
plugin._handle_order = function(order, options, accountInfo)
    if order.state == "close" then
        plugin._handle_closed_order(order, options)
    elseif order.state == "receiving" then
        plugin._handle_receiving_order(order, options)
    elseif order.state == "success" then
        plugin._handle_success_order(order, options, accountInfo)
    end
end

-- 处理已关闭订单
plugin._handle_closed_order = function(order, options)
    local create_time = tonumber(order.create_time)
    local now = os.time()
    -- 超过一天则删除
    if now - create_time > 86400 then -- 一天 = 86400秒
        plugin._delete_receipt(options.account_type, options.aid, options.sid, order.receipt_id)
    end
end

-- 处理接收中订单
plugin._handle_receiving_order = function(order, options)
    local create_time = tonumber(order.create_time)
    local now = os.time()
    -- 超过10分钟则关闭
    if now - create_time > 600 then -- 10分钟 = 600秒
        plugin._close_order(options.account_type, options.aid, options.sid, order.receipt_id)
    end
end

-- 处理成功订单
plugin._handle_success_order = function(order, options, accountInfo)
        -- 提取外部订单号
        local out_order_id = plugin._extract_order_id(order.remark)
        -- 如果订单不存在则录入
        if not plugin._is_order_exists(order, options, accountInfo) then
            plugin._insert_and_report_order(order, out_order_id, options, accountInfo)
        end

    -- 关闭订单
    plugin._close_order(options.account_type, options.aid, options.sid, order.receipt_id)
end

-- 从备注中提取订单号
plugin._extract_order_id = function(remark)
    local out_order_id = ""
    if remark then
        remark = string.gsub(remark, "请勿添加备注-", "")
        local matched, matchGroups = helper.regexp_match_group(remark, "^(?<order_id>\\d{20})$")
        if matched then
            if type(matchGroups) == "string" then
                matchGroups = json.decode(matchGroups)
            end
            if matchGroups["order_id"] then
                out_order_id = matchGroups["order_id"][1]
                log.info(string.format("正则匹配订单号: %s", out_order_id))
            end
        end
    end
    return out_order_id
end

plugin._get_third_order_id = function(order)
    return order.receipt_id or order.trans_id or order.id_v3
end

plugin._get_third_account = function(options)
    if plugin._get_pay_mode(options) == "smallbook" then
        return options.sid
    end
    return options.aid
end

plugin._get_order_amount = function(order)
    return order.fee or order.money or 0
end

plugin._get_order_remark = function(order)
    return order.remark or order.payer_remark or ""
end

plugin._get_order_time = function(order)
    return tonumber(order.create_time or order.timestamp or os.time())
end

plugin._get_order_type_name = function(options)
    if plugin._get_pay_mode(options) == "smallbook" then
        return "小账本收款"
    end
    return "收款单收款"
end

-- 检查订单是否存在
plugin._is_order_exists = function(order, options, accountInfo)
    return orderPayHelper.third_order_exist({
        pay_type = "wxpay",
        channel_code = YUN_WECHAT_GUANJIA_XD,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        third_account = plugin._get_third_account(options),
        third_order_id = plugin._get_third_order_id(order)
    })
end

-- 插入并上报订单
plugin._insert_and_report_order = function(order, out_order_id, options, accountInfo)
    local thirdOrderId = plugin._get_third_order_id(order)
    local amount = plugin._get_order_amount(order)

    -- 录入数据
    local insertId = orderPayHelper.third_order_insert({
        pay_type = "wxpay",
        channel_code = YUN_WECHAT_GUANJIA_XD,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        buyer_id = "",
        buyer_name = order.payer_nick_name or "",
        third_order_id = thirdOrderId,
        third_account = plugin._get_third_account(options),
        amount = amount,
        remark = plugin._get_order_remark(order),
        trans_time = plugin._get_order_time(order),
        type = plugin._get_order_type_name(options),
        out_order_id = out_order_id
    })

    -- 录入成功则上报
    if insertId > 0 then
        local err_code, err_message = orderPayHelper.third_order_report(insertId)
        if err_code == 200 then
            log.info(string.format("订单上报成功: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
                err_message, thirdOrderId, out_order_id, amount))
        else
            log.warning(string.format("订单上报失败: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
                err_message, thirdOrderId, out_order_id, amount))
        end
    else
        log.warning(string.format("订单录入失败, 模式: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
            plugin._get_pay_mode(options), thirdOrderId, out_order_id, amount))
    end
end

-- 获取小账本订单列表
plugin._get_smallbook_order_list = function(sid)
    local url = "https://payapp.weixin.qq.com/qrappzd/user/incomelistflexible"
    url = url .. "?sid=" .. sid
    url = url .. "&v=5.132.6"

    local now = os.time()
    local startTime = now - (now % 3600)
    local body = {
        v = "5.132.6",
        sid = sid,
        start_time = startTime,
        end_time = now,
        page_size = 10,
        sort = "desc",
        is_first = true,
        last_create_time = 0,
        last_id = ""
    }

    local resp = http.post(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Referer"] = "https://servicewechat.com/wx28be8489b7a36aaa/1181/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        },
        body = json.encode(body)
    })

    if resp.status_code ~= 200 then
        log.warning(string.format("[%s] 获取小账本订单列表失败,状态码:%d", PLUGIN, resp.status_code))
        return nil
    end

    if resp.body == "" then
        log.warning(string.format("[%s] 获取小账本订单列表失败,返回数据为空", PLUGIN))
        return nil
    end

    local data = json.decode(resp.body)
    if not data or (data.errcode ~= 0 and data.retcode ~= 0) then
        log.warning(string.format("[%s] 获取小账本订单列表失败,错误码:%d,错误信息:%s", PLUGIN,
            data and (data.errcode or data.retcode) or -1, data and (data.msg or data.errmsg or "") or ""))
        return nil
    end

    local list = {}
    if data.data and data.data.data_list then
        for _, item in ipairs(data.data.data_list) do
            local fee = tonumber(item.fee or 0)
            table.insert(list, {
                receipt_id = item.trans_id or item.id_v3,
                trans_id = item.trans_id,
                id_v3 = item.id_v3,
                fee = fee,
                money = fee,
                create_time = item.timestamp,
                timestamp = item.timestamp,
                remark = item.payer_remark or "",
                payer_remark = item.payer_remark or "",
                payer_nick_name = item.payer_user_name or ""
            })
        end
    end

    return list
end

-- 获取商户ID
plugin._get_shop_id = function(sid, account_id, account_type)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        return nil
    end

    local url = string.format(
        gateway .. "/account/get?miniprogram_version=3.15.10&account_id=%s&account_type=%s&sid=%s", account_id,
        account_type, sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }

    local resp = http.get(url, {
        headers = headers
    })

    local success, data = plugin._check_http_response(resp, account_id, "获取商户ID")
    if not success then
        return nil
    end

    if data.data and data.data.auth_shop_list and #data.data.auth_shop_list > 0 then
        return data.data.auth_shop_list[1].shop_id
    end

    return nil
end

-- 获取订单列表
plugin._get_order_list = function(account_type, account_id, sid)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 获取订单列表 不支持的账号类型:%s", PLUGIN,
            account_id, account_type))
        return nil
    end

    local url = string.format(gateway .. "/receipt/list?account_type=%s&account_id=%s&sid=%s", account_type, account_id,
        sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }

    local body = {
        miniprogram_version = "3.15.10",
        start_time = 0,
        end_time = 0,
        page_size = 10,
        state = {},
        shop_id_list = {},
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success, data = plugin._check_http_response(resp, account_id, "获取订单列表")
    if not success then
        return nil
    end

    if data.data and data.data.receipt then
        -- 过滤掉 fee > 0 的数据
        local filtered = {}
        for _, receipt in ipairs(data.data.receipt) do
            if not receipt.fee or receipt.fee > 0 then
                table.insert(filtered, receipt)
            end
        end
        return filtered
    end

    return nil
end

-- 关闭订单
plugin._close_order = function(account_type, account_id, sid, receipt_id)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 关闭订单 不支持的账号类型:%s", PLUGIN, account_id,
            account_type))
        return false
    end

    local url = string.format(gateway .. "/receipt/close?account_type=%s&account_id=%s&sid=%s", account_type,
        account_id, sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Mac MacWechat/WMPF MacWechat/3.8.7(0x13080712) UnifiedPCMacWechat(0xf2640006) XWEB/11500",
        ["Content-Type"] = "application/json",
        ["Accept"] = "*/*",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html"
    }

    local body = {
        miniprogram_version = "3.15.10",
        receipt_id = receipt_id,
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success = plugin._check_http_response(resp, account_id, "关闭订单")
    return success
end

-- 删除订单
plugin._delete_receipt = function(account_type, account_id, sid, receipt_id)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 删除订单 不支持的账号类型:%s", PLUGIN, account_id,
            account_type))
        return false
    end

    local url = string.format(gateway .. "/receipt/del?account_type=%s&account_id=%s&sid=%s", account_type, account_id,
        sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Mac MacWechat/WMPF MacWechat/3.8.7(0x13080712) UnifiedPCMacWechat(0xf2640006) XWEB/11500",
        ["Content-Type"] = "application/json",
        ["Accept"] = "*/*",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html"
    }

    local body = {
        miniprogram_version = "3.15.10",
        receipt_id = receipt_id,
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success = plugin._check_http_response(resp, account_id, "删除订单")
    return success
end

-- 统一处理订单关闭和删除
plugin._handle_order_close_and_delete = function(account_type, account_id, sid, receipt_id)
    -- 先关闭订单
    if plugin._close_order(account_type, account_id, sid, receipt_id) then
        -- 关闭成功后删除
        plugin._delete_receipt(account_type, account_id, sid, receipt_id)
        return true
    end
    return false
end

return plugin

