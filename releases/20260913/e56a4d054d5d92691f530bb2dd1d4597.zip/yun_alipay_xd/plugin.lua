---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local PAY_CHANNEL_CODE_YUN_ALIPAY_XD = "yun_alipay_xd"

---@param v any
---@return table
local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

---@param body string
---@return table|nil
local function decodeBody(body)
    if not body or body == "" then
        return nil
    end
    local ok, data = pcall(json.decode, body)
    if ok and type(data) == "table" then
        return data
    end
    return nil
end

---URL 解码
---@param s string
---@return string
local function urlDecode(s)
    s = tostring(s or "")
    s = s:gsub("%+", " ")
    s = s:gsub("%%(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end)
    return s
end

---@param proxy string
---@return string
local function encodeProxyCredentials(proxy)
    proxy = tostring(proxy or "")
    local prefix, userInfo, address = proxy:match("^([%w+.-]+://)([^@]+)@(.+)$")
    if not prefix then
        return proxy
    end
    local username, password = userInfo:match("^([^:]*):(.*)$")
    if not username then
        return proxy
    end
    return prefix .. helper.url_encode(username) .. ":" .. helper.url_encode(password) .. "@" .. address
end

---解析账号代理配置：不使用/自定义/本站代理池
---@param accountOptions table
---@return string
local function getProxy(accountOptions)
    accountOptions = accountOptions or {}
    local mode = accountOptions.proxy_mode or "no_proxy"
    if mode == "custom_proxy" then
        return encodeProxyCredentials(accountOptions.proxy or "")
    end
    if mode ~= "cloud_proxy" then
        return ""
    end

    local poolId = tonumber(accountOptions.proxy_pool_id or 0) or 0
    if poolId <= 0 then
        return ""
    end
    local itemId = tonumber(accountOptions.proxy_pool_item_id or 0) or 0
    local proxyItem = helper.proxy_pool_fetch(poolId, itemId)
    if proxyItem and proxyItem.proxy_url and proxyItem.proxy_url ~= "" then
        local proxyId = tonumber(proxyItem.proxy_id or 0) or 0
        if proxyId ~= itemId then
            accountOptions.proxy_pool_item_id = proxyId
            if accountOptions.account_id then
                helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", proxyId)
            end
        end
        return encodeProxyCredentials(proxyItem.proxy_url)
    end
    if itemId > 0 then
        helper.proxy_pool_release(itemId)
    end
    accountOptions.proxy_pool_item_id = 0
    if accountOptions.account_id then
        helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", "0")
    end
    return ""
end

---把代理配置转换为云端约定的代理请求头（X-Proxy-Cluster-*）
---@param accountOptions table
---@return table|nil
local function getProxyHeaders(accountOptions)
    local proxy = getProxy(accountOptions)
    if proxy == "" then
        return nil
    end
    local rest = proxy
    local scheme = rest:match("^([%w+.-]+)://")
    if scheme then
        rest = rest:sub(#scheme + 4)
    end
    local userInfo, address = rest:match("^([^@/]+)@(.+)$")
    if not userInfo then
        address = rest
    end
    if not address or address == "" then
        return nil
    end
    local username, password = "", ""
    if userInfo then
        username, password = userInfo:match("^([^:]*):(.*)$")
        username = urlDecode(username or "")
        password = urlDecode(password or "")
    end
    return {
        ["X-Proxy-Cluster-URL"] = address,
        ["X-Proxy-Cluster-Type"] = scheme or "socks5",
        ["X-Proxy-Cluster-User"] = username,
        ["X-Proxy-Cluster-Pass"] = password
    }
end

-- 构建模式11的HTML内容
---@param pid string
---@param money string
---@param order_id string
---@return string
local function buildMod11Html(pid, money, order_id)
    return [[<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>收银台</title>
    <script src="//gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script>
</head>
<body>
<script>
    var userId = "]] .. pid .. [[";
    var money = "]] .. money .. [[";
    var remark = "]] .. order_id .. [[";

    function returnApp() {
        AlipayJSBridge.call("exitApp")
    }

    function ready(a) {
        window.AlipayJSBridge ? a && a() : document.addEventListener("AlipayJSBridgeReady", a, !1)
    }

    ready(function () {
        try {
            var a = {
                actionType: "scan",
                u: userId,
                a: money,
                m: remark,
                biz_data: {
                    s: "money",
                    u: userId,
                    a: money,
                    m: remark
                }
            }
        } catch (b) {
            returnApp()
        }
        AlipayJSBridge.call("startApp", {
            appId: "20000123",
            param: a
        }, function (a) { })
    });
    document.addEventListener("resume", function (a) {
        returnApp()
    });
</script>
</body>
</html>]]
end

-- @class types.plugin
local plugin = {}

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        channels = {
            ["alipay"] = { {
                label = "支付宝-云端XD",
                value = PAY_CHANNEL_CODE_YUN_ALIPAY_XD,
                options = {
                    use_add_amount = 1,
                    use_qrcode_login = 1
                }
            } }
        },
        options = {
            config = { {
                title = "应用ID",
                key = "pid",
                default = "",
                tip = "支付宝授权使用的应用ID"
            }, {
                title = "授权回调地址",
                key = "domain",
                default = "",
                tip = "支付宝授权成功后跳转地址,一般为主域名,需要在支付宝进行配置 如: https://aa.bb.com"
            } },
            crontab_list = { {
                crontab = "*/15 * * * * *",
                fun = "cron",
                args = "",
                name = "检查账号状态",
                scope = "account",
                options = {
                    has_wait_pay_order = 0
                }
            } }
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = "gateway",
                label = "选择网关",
                type = types.InputTypes.SELECT,
                default = "",
                options = {
                    tip = "",
                    chose_gateway = 1
                },
                placeholder = "请选择网关",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择"
                } }
            },
            {
                name = "qrcode",
                label = "收款码地址",
                type = types.InputTypes.INPUT,
                default = "",
                options = {
                    tip = "",
                    append_deqrocde = 1
                },
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.type == 'qrcode'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "qrcode_file",
                label = "收款码图片",
                type = types.InputTypes.IMAGE,
                default = "",
                options = {
                    tip = ""
                },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.type == 'image'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "pid",
                label = "PID",
                type = types.InputTypes.INPUT,
                default = "",
                options = {
                    tip = ""
                },
                placeholder = "扫码登录自动获取，请忽视我！",
                when = "this.formModel.options.type == 'pid'",
                rules = { {
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "qrcode_mod",
                label = "二维码模式",
                type = types.InputTypes.SELECT,
                default = "9",
                options = {
                    tip = ""
                },
                placeholder = "请选择二维码模式",
                when = "this.formModel.options.type == 'pid'",
                values = {
                    {
                        label = "免输-转账模式①",
                        value = "9"
                    },
                    {
                        label = "免输-转账模式②",
                        value = "10"
                    },
                    {
                        label = "免输-二维码模式③",
                        value = "11"
                    },
                    {
                        label = "免输-转账单模式④",
                        value = "12"
                    }
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "type",
                label = "收款码类型",
                type = types.InputTypes.SELECT,
                default = "pid",
                options = {
                    tip = ""
                },
                placeholder = "请选择收款码类型",
                values = { {
                    label = "二维码",
                    value = "qrcode"
                }, {
                    label = "二维码图片",
                    value = "image"
                }, {
                    label = "PID",
                    value = "pid"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "proxy_mode",
                label = "代理模式",
                type = types.InputTypes.SELECT,
                default = "no_proxy",
                options = { tip = "选择代理使用模式" },
                placeholder = "请选择代理模式",
                values = { {
                    label = "不使用代理",
                    value = "no_proxy"
                }, {
                    label = "使用自定义代理",
                    value = "custom_proxy"
                }, {
                    label = "使用本站代理池",
                    value = "cloud_proxy"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择代理模式"
                } }
            },
            {
                name = "proxy",
                label = "Socks5代理地址",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.proxy_mode == 'custom_proxy'",
                options = { tip = "格式：socks5://IP:端口，或 socks5://用户名:密码@IP:端口" },
                placeholder = "例如：socks5://127.0.0.1:1080"
            },
            {
                name = "proxy_pool_id",
                label = "绑定代理池",
                type = "chose_proxy_pool",
                default = "-1",
                when = "this.formModel.options.proxy_mode == 'cloud_proxy'",
                options = { tip = "请选择绑定的代理池" },
                placeholder = "请选择代理池",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择代理池"
                } }
            },
            {
                name = "proxy_pool_item_id",
                label = "绑定代理",
                type = types.InputTypes.INPUT,
                default = "0",
                hidden = 1
            },
            {
                name = "bind_token",
                label = "绑定的用户信息",
                type = types.InputTypes.INPUT,
                default = "",
                hidden = 1
            },
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local options = ctx.account_options or {}

    if options.type == "pid" then
        return {
            code = 200,
            message = "success",
            data = {
                type = "render"
            }
        }
    end

    if options.type == "image" then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = options.qrcode_file,
                qrcode = ""
            }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = options.qrcode,
            scheme = "alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=" ..
                helper.url_encode(options.qrcode or "") .. "%3F_s%3Dweb-other"
        }
    }
end

-- 定时任务
---@param ctx types.CronAccountParams
---@return table
function plugin.cron(ctx)
    local vAccountInfo = toTable(ctx.account_info)
    local vParams = toTable(ctx.account_options)
    local vAccountOptions = toTable(vAccountInfo.options)

    local bindTokenRaw = vParams.bind_token
    if bindTokenRaw == nil or bindTokenRaw == "" then
        bindTokenRaw = vAccountOptions.bind_token
    end

    if bindTokenRaw == nil or bindTokenRaw == "" then
        helper.channel_account_offline(vAccountInfo.id)
        return {
            code = 500,
            message = "未登录",
            data = {}
        }
    end

    local bindTokenInfo = toTable(bindTokenRaw)
    local gateway = vParams.gateway
    if gateway == nil or gateway == "" then
        gateway = vAccountOptions.gateway
    end

    local serverAddress = helper.channel_gateway_addr(gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关"
        }
    end

    local apiUri = string.format("%s/Alipay_Frame/IsLoginStatus", serverAddress)
    if vParams.type == "pid" then
        apiUri = string.format("%s/Alipay_Frame/IsLoginStatus_V2", serverAddress)
    end

    local response, error_message = http.request("POST", apiUri, {
        query = string.format("uid=%s", bindTokenInfo.uid or ""),
        timeout = "30s",
    })
    if error_message ~= nil then
        helper.channel_account_offline(vAccountInfo.id)
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message)
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code == nil then
        helper.channel_account_offline(vAccountInfo.id)
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or "")
        }
    end

    if returnInfo.code ~= "1" then
        helper.channel_account_offline(vAccountInfo.id)
        if returnInfo.code == "0" then
            return { code = 201, message = "请扫描二维码登录" }
        end
        if returnInfo.code == "-1" then
            return { code = 500, message = "uid参数错误" }
        end
        if returnInfo.code == "-2" then
            return { code = 500, message = "没有找到Uid" }
        end
        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or "")
        }
    end

    if vParams.type == "pid" and returnInfo.pid then
        helper.channel_account_set_option(vAccountInfo.id, "pid", returnInfo.pid)
    end

    if vAccountInfo.online ~= 1 then
        helper.channel_account_online(vAccountInfo.id)
    end

    return {
        code = 200,
        message = "在线"
    }
end

-- 支付数据渲染
---@param ctx types.OrderRenderParams
---@return types.OrderRenderResp
function plugin.render(ctx)
    local vOrderInfo = ctx.order_info or {}
    local vDeviceInfo = ctx.device or {}
    local vReqData = ctx.request_data or {}
    local vAccountOptions = ctx.account_options or {}
    local pluginName = PAY_CHANNEL_CODE_YUN_ALIPAY_XD
    local baseUrl = vDeviceInfo.base_url or vDeviceInfo.domain or vDeviceInfo.host or ""

    ---@type types.OrderCreateRespData
    local ret = {
        action = "render"
    }

    if vAccountOptions.type == "image" then
        ret.data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode_file = vAccountOptions.qrcode_file,
            qrcode = ""
        }
    elseif vAccountOptions.type == "qrcode" then
        ret.data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = vAccountOptions.qrcode,
            scheme = "alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=" ..
                helper.url_encode(vAccountOptions.qrcode or "") .. "%3F_s%3Dweb-other"
        }
    end

    if vAccountOptions.qrcode_mod == "9" then
        ret.data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode =
                "https://render.alipay.com/p/s/i?scheme=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000116%26actionType%3DtoAccount%26goBack%3DNO%26amount%3D" ..
                helper.amount_int2str(vOrderInfo.trade_amount) .. "%26userId%3D" .. (vAccountOptions.pid or "") ..
                "%26memo%3D" .. (vOrderInfo.order_id or ""),
            url = "",
            content = "",
            scheme =
                "alipayqr://platformapi/startapp?appId=20000067&url=https%3A%2F%2Frender.alipay.com%2Fp%2Fs%2Fi%3Fscheme%3Dalipays%253A%252F%252Fplatformapi%252Fstartapp%253FappId%253D20000116%2526actionType%253DtoAccount%2526goBack%253DNO%2526amount%253D" ..
                helper.amount_int2str(vOrderInfo.trade_amount) .. "%2526userId%253D" .. (vAccountOptions.pid or "") ..
                "%2526memo%253D" .. (vOrderInfo.order_id or ""),
            out_trade_no = ""
        }
    elseif vAccountOptions.qrcode_mod == "10" then
        ret.data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode_use_short_url = 1,
            qrcode =
                "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" ..
                (vAccountOptions.pid or "") .. "%2522%252C%2522a%2522%253A%2522" ..
                helper.amount_int2str(vOrderInfo.trade_amount) .. "%2522%252C%2522m%2522%253A%2522" ..
                (vOrderInfo.order_id or "") .. "%2522%257D",
            url = "",
            content = "",
            scheme =
                "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" ..
                (vAccountOptions.pid or "") .. "%2522%252C%2522a%2522%253A%2522" ..
                helper.amount_int2str(vOrderInfo.trade_amount) .. "%2522%252C%2522m%2522%253A%2522" ..
                (vOrderInfo.order_id or "") .. "%2522%257D",
            out_trade_no = ""
        }
    elseif vAccountOptions.qrcode_mod == "11" then
        ret.data = {
            type = types.PaymentResultTypes.HTML,
            qrcode_use_short_url = 1,
            url = "",
            content = buildMod11Html(vAccountOptions.pid or "", helper.amount_int2str(vOrderInfo.trade_amount),
                vOrderInfo.order_id or ""),
            scheme = "alipays://platformapi/startapp?appId=20000067&url=" ..
                helper.url_encode("https://render.alipay.com/p/s/i?scheme=" ..
                    helper.url_encode("alipays://platformapi/startapp?appId=20000180&url=" ..
                        helper.url_encode(orderPayHelper.get_toapp_url(vOrderInfo.order_id, baseUrl)))),
            out_trade_no = ""
        }
    elseif vAccountOptions.qrcode_mod == "12" then
        local pid = helper.get_plugin_option(pluginName, "pid", vAccountOptions.app_id)
        local authRedirectAddress = helper.get_plugin_option(pluginName, "domain", baseUrl)

        local authUri = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id=" .. pid ..
            "&scope=auth_base&state=" .. (vOrderInfo.order_id or "") .. "&redirect_uri=" ..
            helper.url_encode((authRedirectAddress or "") .. "/api/pay/toapp/" .. (vOrderInfo.order_id or ""))

        if vDeviceInfo.is_mobile and vDeviceInfo.is_alipay then
            if vReqData.query and string.find(vReqData.query, "auth_code") then
                local uri2 =
                    "https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%7B%0A%20%20%20%20%22productCode%22%3A%20%22TRANSFER_TO_ALIPAY_ACCOUNT%22%2C%0A%20%20%20%20%22bizScene%22%3A%20%22YUEBAO%22%2C%0A%20%20%20%20%22transAmount%22%3A%20%22" ..
                    helper.amount_int2str(vOrderInfo.trade_amount) ..
                    "%22%2C%0A%20%20%20%20%22remark%22%3A%20%22" .. (vOrderInfo.order_id or "") ..
                    "%22%2C%0A%20%20%20%20%22businessParams%22%3A%7B%0A%09%09%22returnUrl%22%3A%20%22alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D2021001167654035%26nbupdate%3Dsyncforce%22%0A%09%7D%2C%0A%20%20%20%20%22payeeInfo%22%3A%20%7B%0A%20%20%20%20%20%20%20%20%22identity%22%3A%20%22" ..
                    (vAccountOptions.pid or "") ..
                    "%22%2C%0A%20%20%20%20%20%20%20%20%22identityType%22%3A%20%22ALIPAY_USER_ID%22%0A%20%20%20%20%7D%0A%7D"

                ret.data = {
                    type = "jump",
                    url = "alipays://platformapi/startapp?appId=2021003124679502&closeAllActivityAnimation=true&startMultApp=YES&transAnimate=true&url=" ..
                        helper.url_encode(uri2)
                }
            else
                ret.data = {
                    type = "jump",
                    url = authUri
                }
            end
        else
            ret.data = {
                type = "qrcode",
                qrcode = baseUrl .. "/pay/" .. (vOrderInfo.order_id or ""),
                url = "",
                content = "",
                scheme = "alipayqr://platformapi/startapp?appId=20000067&url=" ..
                    helper.url_encode(baseUrl .. "/api/pay/toapp/" .. (vOrderInfo.order_id or "")),
                out_trade_no = ""
            }
        end
    end

    return {
        code = 200,
        message = "success",
        data = ret
    }
end

-- 二维码登录
---@param ctx table
---@return table
function plugin.login_qrcode(ctx)
    local vParams = toTable(ctx.params)
    local vUserInfo = toTable(ctx.user_info)
    local vAccountInfo = toTable(ctx.account_info)
    local vAccountOption = toTable(vAccountInfo.options)

    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    vAccountOption.account_id = vAccountInfo.id

    local apiUri = string.format("%s/Alipay_Frame/CreateID", serverAddress)
    local req = {
        data = helper.base64_encode(json.encode({
            site = ctx.device.base_url,
            pid = vUserInfo.id,
            key = vUserInfo.app_secret
        }))
    }
    print("请求地址",apiUri,"请求内容",funcs.table_http_query(req))

    local response, error_message = http.request("POST", apiUri, {
        query = funcs.table_http_query(req),
        headers = getProxyHeaders(vAccountOption),
        timeout = "30s",
    })
    if error_message ~= nil then
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code == nil then
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or ""),
            data = {}
        }
    end
    if returnInfo.code ~= "1" then
        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    local uid = returnInfo.uid

    apiUri = string.format("%s/Alipay_Frame/QRCode", serverAddress)
    response, error_message = http.request("POST", apiUri, {
        query = string.format("uid=%s", uid),
        timeout = "30s",
    })
    if error_message ~= nil then
        return {
            code = 500,
            message = string.format("请求获取登录二维码错误: %s", error_message),
            data = {}
        }
    end

    returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code ~= "1" then
        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            qrcode = returnInfo.url,
            options = json.encode({
                uid = uid
            })
        }
    }
end

-- 检查二维码登录状态
---@param ctx table
---@return table
function plugin.login_qrcode_check(ctx)
    local vParams = toTable(ctx.params)
    local vAccountInfo = toTable(ctx.account_info)
    local vAccountOption = toTable(vAccountInfo.options)

    local uid = vParams.uid
    if uid == nil or uid == "" then
        local bindTokenInfo = toTable(vAccountOption.bind_token)
        uid = bindTokenInfo.uid
    end

    if uid == nil or uid == "" then
        return {
            code = 201,
            message = "请扫描二维码登录",
            data = {}
        }
    end

    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    local apiUri = string.format("%s/Alipay_Frame/IsLoginStatus", serverAddress)
    if vAccountOption.type == "pid" then
        apiUri = string.format("%s/Alipay_Frame/IsLoginStatus_V2", serverAddress)
    end

    local response, error_message = http.request("POST", apiUri, {
        query = string.format("uid=%s", uid),
        timeout = "30s",
    })
    if error_message ~= nil then
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code == nil then
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    if returnInfo.code ~= "1" then
        if returnInfo.code == "0" then
            return { code = 201, message = "请扫描二维码登录", data = {} }
        end
        if returnInfo.code == "-1" then
            return { code = 500, message = "uid参数错误", data = {} }
        end
        if returnInfo.code == "-2" then
            return { code = 500, message = "没有找到Uid", data = {} }
        end

        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    helper.channel_account_set_option(vAccountInfo.id, "bind_token", json.encode({
        uid = uid
    }))

    if vAccountOption.type == "pid" and returnInfo.pid then
        helper.channel_account_set_option(vAccountInfo.id, "pid", returnInfo.pid)
    end

    return {
        code = 200,
        message = "登录成功",
        data = {}
    }
end

return plugin
