---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

local PAY_ALIPAY_BILL = "alipay_bill_auto"
local PLUGIN = PAY_ALIPAY_BILL

-- @class plugin
local plugin = {}

local function baseResponse(code, message, data)
    return {
        code = code,
        message = message,
        data = data or {}
    }
end

local function getAccountContext(ctx)
    if type(ctx) ~= "table" then
        return {}, {}
    end

    local accountInfo = ctx.account_info or ctx.channel_account or ctx.account or ctx
    if type(accountInfo) ~= "table" then
        accountInfo = {}
    end

    local options = ctx.account_options or ctx.plugin_options or ctx.plugin_option
    if options == nil then
        options = accountInfo.options
    end
    if type(options) == "string" and options ~= "" then
        local ok, decoded = pcall(json.decode, options)
        if ok and type(decoded) == "table" then
            options = decoded
        end
    end
    if type(options) ~= "table" then
        options = {}
    end

    return accountInfo, options
end

-- 规范化应用私钥：字面\n转真实换行（Base64字符集不含反斜杠，出现即为转义符；无需PEM头尾，Go层会自动处理）
local function normalizePemKey(key)
    if type(key) ~= "string" then
        return key
    end
    if string.find(key, "\\n") then
        key = string.gsub(key, "\\n", "\n")
    end
    return key
end

local function getBaseUrl(device)
    if not device then
        return ""
    end
    return device.base_url or device.host or ""
end

local function renderResponse(data, code, message)
    return {
        code = code or 200,
        message = message or "success",
        data = {
            action = "render",
            data = data,
        }
    }
end

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["alipay"] = { {
                label = '商家账单(自动配置)',
                value = PAY_ALIPAY_BILL,
                options = {
                    use_add_amount = 1,
                    use_pay_codes = 1,
                }
            } },
        },
        options = {
            -- 配置项
            config = { {
                title = "应用ID", key = "pid", default = "", tip = "支付宝授权使用的应用ID"
            }, {
                title = "授权回调地址", key = "domain", default = "", tip = "支付宝授权成功后跳转地址,一般为主域名,需要在支付宝进行配置 如: https://aa.bb.com"
            } },
            -- 定时任务
            crontab_list = { {
                crontab = "*/5 * * * * *", -- 定时任务结构
                fun = "cron", -- 具体func名称
                args = "", -- 执行时传入对应的func
                name = "检查账号状态", -- 本插件内唯一
                scope = "account", -- 目标范围 order 订单(只查询订单未支付状态) account 账号 (只查询账号在线状态) system 全局
                options = {
                    has_wait_pay_order = 0, -- 账号筛选有未支付订单的
                }
            } },
        },
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'config_mode',
                label = '配置模式',
                type = types.InputTypes.RADIO,
                default = "auto",
                options = {
                    tip = '<b>自动同步(推荐)：</b>只需填入应用数据同步地址，保存账号时自动导入PID/应用ID/私钥。<br><b>手动配置：</b>跳过自动同步，手动填写所有参数。',
                },
                values = { { label = "自动同步（推荐）", value = "auto" }, { label = "手动配置", value = "manual" } },
            },
            {
                name = 'app_data_url',
                label = '应用数据同步地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "填入应用申请完成后返回的地址（域名+接口+UUID）",
                options = {
                    tip = '在支付宝开放平台工具中完成应用申请后，将返回的URL填入此处，保存账号时自动导入PID、应用ID和私钥（无需等待应用上线）。',
                },
                rules = { { required = false, trigger = { "blur" } } }
            },
            {
                name = 'type',
                label = '收款码类型',
                type = types.InputTypes.SELECT,
                default = "pid",
                when = "this.formModel.options.config_mode == 'manual'",
                options = { tip = '' },
                placeholder = "请选择收款码类型",
                values = { { label = "二维码", value = "qrcode" }, { label = "二维码图片", value = "image" }, { label = "PID", value = "pid" } },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = 'qrcode',
                label = '收款码地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入收款码地址",
                when = "(this.formModel.options.config_mode == 'manual') && (this.formModel.options.type == 'qrcode')",
                options = {
                    append_deqrocde = 1, -- 增加解析二维码功能
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = 'qrcode_file',
                label = '收款码图片',
                type = types.InputTypes.IMAGE,
                default = "",
                when = "(this.formModel.options.config_mode == 'manual') && (this.formModel.options.type == 'image')",
                options = { tip = '' },
                placeholder = "请上传收款码图片",
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = 'pid',
                label = 'PID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "(this.formModel.options.config_mode == 'manual') && (this.formModel.options.type == 'pid')",
                options = { tip = '' },
                placeholder = "请输入PID",
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = 'qrcode_mod',
                label = '二维码模式',
                type = types.InputTypes.SELECT,
                default = "10",
                when = "(this.formModel.options.config_mode == 'manual') && (this.formModel.options.type == 'pid')",
                options = { tip = '' },
                placeholder = "请选择二维码模式",
                values = { { label = "转账模式", value = "9" }, { label = "模式10", value = "10" }, { label = "模式11", value = "11" }, { label = "转账确认单模式", value = "12" } },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = 'app_id',
                label = '应用ID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.config_mode == 'manual'",
                placeholder = "请输入应用ID",
                options = { tip = '' },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = 'app_secret',
                label = '应用私钥',
                type = types.InputTypes.TEXTAREA,
                default = "",
                hidden_list = 1,
                when = "this.formModel.options.config_mode == 'manual'",
                placeholder = "请输入应用私钥",
                options = { tip = '' },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = 'scan_type',
                label = '订单检查方式',
                type = types.InputTypes.RADIO,
                default = "order_or_amount",
                when = "this.formModel.options.config_mode == 'manual'",
                options = { tip = '' },
                placeholder = "请选择订单检查方式",
                values = { { label = "订单号匹配不到则使用金额", value = "order_or_amount" }, { label = "订单号", value = "order" } },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = 'order_temp_amount',
                label = '取消订单递增金额',
                type = types.InputTypes.RADIO,
                default = "0",
                when = "this.formModel.options.config_mode == 'manual'",
                options = { tip = '<b>注意:</b>订单检查方式为订单号的时候才能选择[是]' },
                placeholder = "请选择订单检查方式",
                values = { { label = "否", value = "0" }, { label = "是", value = "1" } },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
        },
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    return baseResponse(200, "success", {
        type = "render"
    })
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = {
            response = ""
        }
    }
end

-- 定时任务
function plugin.cron(ctx)
    local accountInfo, options = getAccountContext(ctx)

    -- 应用ID/私钥未配置完整，跳过账号状态检查
    if not options['app_id'] or options['app_id'] == '' or not options['app_secret'] or options['app_secret'] == '' then
        log.info("[检查账号状态] 应用ID或私钥未配置，跳过账单检查, account_id=" .. tostring(accountInfo.id))
        return baseResponse(200, "应用ID或私钥未配置，跳过账单检查")
    end

    ---- 获取支付宝订单列表
    local err_code, err_message, list = orderPayHelper.alipay_bill_list(accountInfo.options)
    if err_code ~= 200 then
        -- 账单拉取失败，设置离线
        log.warning("支付宝账单拉取失败: " .. err_message)
        helper.channel_account_offline(accountInfo.id)
        return baseResponse(err_code, err_message)
    end

    log.debug("支付宝账单拉取成功，订单数量: ", #json.decode(list))

    local orderList = json.decode(list)
    -- 如果离线状态 则设置为在线
    if accountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(accountInfo.id)
    end

    ---- 录入数据
    for _, v in ipairs(orderList) do
        local amount = helper.amount_str2int(v.trans_amount)
        log.debug("支付宝账单", v.alipay_order_no, v.trans_amount, amount, v.trans_memo, v.direction)
        -- 经营码 type=交易 merchant_order_no!=""
        if v.direction ~= "收入" or amount <= 0 or (v.merchant_order_no and v.merchant_order_no ~= "" and v.type ~= "交易") or (v.type ~= "转账" and v.type ~= "交易") then
            goto continue
        end

        -- 判断第三方订单是否存在
        local exist = orderPayHelper.third_order_exist({
            pay_type = "alipay",
            channel_code = PAY_ALIPAY_BILL,
            uid = accountInfo.uid,
            account_id = accountInfo.id,
            third_account = options['app_id'],
            third_order_id = v.alipay_order_no
        })
        if exist then
            goto continue
        end

        if v.trans_memo then
            v.trans_memo = string.gsub(v.trans_memo, "请勿添加备注-", "")
        end

        local matched, matchGroups = helper.regexp_match_group(v.trans_memo, "^(?<order_id>\\d{20})$")
        local out_order_id = ""
        if matched then
            if type(matchGroups) == "string" then
                matchGroups = json.decode(matchGroups)
            end
            if matchGroups["order_id"] then
                log.info(matchGroups["order_id"][1], "正则数据4")
                out_order_id = matchGroups["order_id"][1]
            end
        end

        log.info("支付宝账单自动识别外部订单号,准备插入", v.alipay_order_no, out_order_id)

        -- 录入数据
        local insertId = orderPayHelper.third_order_insert({
            pay_type = "alipay",
            channel_code = PAY_ALIPAY_BILL,
            uid = accountInfo.uid,
            account_id = accountInfo.id,
            ["buyer_id"] = "",
            ["buyer_name"] = v.other_account,
            third_order_id = v.alipay_order_no,
            third_account = options['app_id'],
            ["amount"] = helper.amount_str2int(v.trans_amount),
            ["remark"] = v.trans_memo,
            ["trans_time"] = helper.datetime_to_timestamp(v.trans_dt),
            ["type"] = v.type,
            ["out_order_id"] = out_order_id,
        })

        -- 录入失败
        if insertId <= 0 then
            print("外部订单插入失败", v.alipay_order_no, out_order_id)
            goto continue
        end

        -- 录入成功
        err_code, err_message = orderPayHelper.third_order_report(insertId)
        if err_code == 200 then
            print("订单上报成功:" .. err_message, v.alipay_order_no, out_order_id, v.trans_amount)
        else
            print("订单上报失败:" .. err_message, v.alipay_order_no, out_order_id, v.trans_amount)
        end

        -- 尾部
        ::continue::
    end

    return baseResponse(200, "处理完成")
end

function plugin.buildMod11Html(pid, money, order_id)
    return [[<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>收银台</title>
    <script src="//gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script>
</head>
<body>
<script>
    var userId = "]] .. pid .. [[";
    var money = "]] .. money .. [[";
    var remark = "]] .. order_id .. [[";

    function returnApp() {
        AlipayJSBridge.call("exitApp")
    }

    function ready(a) {
        window.AlipayJSBridge ? a && a() : document.addEventListener("AlipayJSBridgeReady", a, !1)
    }

    ready(function () {
        try {
            var a = {
                actionType: "scan",
                u: userId,
                a: money,
                m: remark,
                biz_data: {
                    s: "money",
                    u: userId,
                    a: money,
                    m: remark
                }
            }
        } catch (b) {
            returnApp()
        }
        AlipayJSBridge.call("startApp", {
            appId: "20000123",
            param: a
        }, function (a) { })
    });
    document.addEventListener("resume", function (a) {
        returnApp()
    });
</script>
</body>
</html>]]
end

function plugin.buildMod12Html(pid, money, order_id)
    local url = string.format("https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%s", helper.url_encode(json.encode({
        productCode = "TRANSFER_TO_ALIPAY_ACCOUNT",
        bizScene = "YUEBAO",
        outBizNo = "",
        transAmount = money,
        remark = order_id,
        businessParams = {
            returnUrl = "alipays://platformapi/startApp?appId=20000218&bizScenario=transoutXtrans"
        },
        payeeInfo = {
            identity = pid,
            identityType = "ALIPAY_USER_ID"
        }
    })))

    return [[<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>收银台</title>
    <script src="//gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script>
</head>
<body>
<script>
    var userId = "]] .. pid .. [[";
    var money = "]] .. money .. [[";
    var remark = "]] .. order_id .. [[";

     AlipayJSBridge.call('setTitleColor', {
        color: parseInt('1959c1', 16),
        reset: false
    });
    AlipayJSBridge.call('showTitleLoading');
    AlipayJSBridge.call('setTitle', {
        title: '请稍等..',
        subtitle: 'XArrPay正在检测支付环境..'
    });
    AlipayJSBridge.call("pushWindow", {
        url: ']] .. url .. [[',
        param: {
            showToolBar: "NO"
        }
    });
</script>
</body>
</html>]]
end

function plugin.buildMod12Uri(pid, money, order_id)
    local url = string.format("https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%s", helper.url_encode(json.encode({
        productCode = "TRANSFER_TO_ALIPAY_ACCOUNT",
        bizScene = "YUEBAO",
        transAmount = money,
        remark = order_id,
        payeeInfo = {
            identity = pid,
            identityType = "ALIPAY_USER_ID"
        }
    })))
    return url
end

-- 支付数据渲染
function plugin.render(ctx)
    local vOrderInfo = ctx.order_info
    local vDeviceInfo = ctx.device
    local vOldPayData = ctx.pay_data
    local vReqData = ctx.request_data
    local vAccountInfo = ctx.account_info or {}
    local vAccountOptions = ctx.account_options
    vOrderInfo = vOrderInfo or {}
    vReqData = vReqData or {}
    vDeviceInfo = vDeviceInfo or {}
    vOldPayData = vOldPayData or {}
    vAccountOptions = vAccountOptions or {}
    vOrderInfo.order_id = vOrderInfo.order_id or ""
    vOrderInfo.trade_amount = vOrderInfo.trade_amount or 0
    vAccountOptions.pid = vAccountOptions.pid or ""
    vAccountOptions.qrcode_mod = vAccountOptions.qrcode_mod or "9"
    vAccountOptions.type = vAccountOptions.type or "pid"
    log.debug("渲染测试数据", vOrderInfo, vOldPayData, vAccountInfo, vDeviceInfo)

    if vOldPayData["type"] == "render" then
        local ret

        if vAccountOptions['type'] == 'image' then
            return renderResponse({
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = vAccountOptions['qrcode_file'],
                url = "",
                content = "",
                out_trade_no = ''
            })
        elseif vAccountOptions['type'] == 'qrcode' then
            return renderResponse({
                type = types.PaymentResultTypes.QRCODE,
                qrcode = vAccountOptions['qrcode'],
                url = "",
                scheme = "alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=" ..
                    helper.url_encode(vAccountOptions['qrcode']) .. "%3F_s%3Dweb-other",
                content = "",
                out_trade_no = ''
            })
        end

        print("进入render", vAccountOptions['qrcode_mod'])

        -- 转账模式
        if vAccountOptions['qrcode_mod'] == '9' then
            ret = {
                type = "qrcode",
                qrcode = "https://render.alipay.com/p/s/i?scheme=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000116%26actionType%3DtoAccount%26goBack%3DNO%26amount%3D" ..
                    helper.amount_int2str(vOrderInfo.trade_amount) .. "%26userId%3D" .. vAccountOptions['pid'] .. "%26memo%3D" .. vOrderInfo.order_id,
                url = "",
                content = "",
                scheme = "alipayqr://platformapi/startapp?appId=20000067&url=https%3A%2F%2Frender.alipay.com%2Fp%2Fs%2Fi%3Fscheme%3Dalipays%253A%252F%252Fplatformapi%252Fstartapp%253FappId%253D20000116%2526actionType%253DtoAccount%2526goBack%253DNO%2526amount%253D" ..
                    helper.amount_int2str(vOrderInfo.trade_amount) .. "%2526userId%253D" .. vAccountOptions['pid'] .. "%2526memo%253D" .. vOrderInfo.order_id,
                out_trade_no = ''
            }
        elseif vAccountOptions['qrcode_mod'] == '10' then
            ret = {
                type = "qrcode",
                qrcode_use_short_url = 1,
                qrcode = "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" .. vAccountOptions['pid'] .. "%2522%252C%2522a%2522%253A%2522" .. helper.amount_int2str(vOrderInfo.trade_amount) .. "%2522%252C%2522m%2522%253A%2522" .. vOrderInfo.order_id .. "%2522%257D",
                url = "",
                content = "",
                scheme = "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" .. vAccountOptions['pid'] .. "%2522%252C%2522a%2522%253A%2522" .. helper.amount_int2str(vOrderInfo.trade_amount) .. "%2522%252C%2522m%2522%253A%2522" .. vOrderInfo.order_id .. "%2522%257D",
                out_trade_no = ''
            }
        elseif vAccountOptions['qrcode_mod'] == '11' then
            ret = {
                type = "html",
                qrcode_use_short_url = 1,
                url = "",
                content = plugin.buildMod11Html(vAccountOptions['pid'], helper.amount_int2str(vOrderInfo.trade_amount), vOrderInfo.order_id),
                scheme = "alipays://platformapi/startapp?appId=20000067&url=" ..
                    helper.url_encode("https://render.alipay.com/p/s/i?scheme=" ..
                        helper.url_encode("alipays://platformapi/startapp?appId=20000180&url=" ..
                            helper.url_encode(orderPayHelper.get_toapp_url(vOrderInfo.order_id, getBaseUrl(vDeviceInfo))))),
                out_trade_no = ''
            }
        elseif vAccountOptions['qrcode_mod'] == '12' then
            local baseUrl = getBaseUrl(vDeviceInfo)
            local pid = helper.get_plugin_option(PLUGIN, "pid", vAccountOptions["app_id"])
            if not pid or pid == "" then
                return renderResponse({
                    type = types.PaymentResultTypes.ERROR,
                    content = "未配置支付宝应用ID(app_id)，请先完成RSA应用数据配置"
                }, 500, "未配置支付宝应用ID(app_id)，请先完成RSA应用数据配置")
            end
            local authRedirectAddress = helper.get_plugin_option(PLUGIN, "domain", baseUrl)
            authRedirectAddress = authRedirectAddress or ""
            local authUri = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id=" .. pid .. "&scope=auth_base&state=" .. vOrderInfo.order_id .. "&redirect_uri=" .. helper.url_encode(authRedirectAddress .. "/api/pay/toapp/" .. vOrderInfo.order_id)

            -- 如果在支付宝里面就直接打开
            if vDeviceInfo.is_mobile and vDeviceInfo.is_alipay then
                if vReqData.query and string.find(vReqData.query, "auth_code") then
                    local uri2 = "https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%7B%0A%20%20%20%20%22productCode%22%3A%20%22TRANSFER_TO_ALIPAY_ACCOUNT%22%2C%0A%20%20%20%20%22bizScene%22%3A%20%22YUEBAO%22%2C%0A%20%20%20%20%22transAmount%22%3A%20%22" ..
                        helper.amount_int2str(vOrderInfo.trade_amount) ..
                        "%22%2C%0A%20%20%20%20%22remark%22%3A%20%22" ..
                        vOrderInfo.order_id ..
                        "%22%2C%0A%20%20%20%20%22businessParams%22%3A%7B%0A%09%09%22returnUrl%22%3A%20%22alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D2021001167654035%26nbupdate%3Dsyncforce%22%0A%09%7D%2C%0A%20%20%20%20%22payeeInfo%22%3A%20%7B%0A%20%20%20%20%20%20%20%20%22identity%22%3A%20%22" ..
                        vAccountOptions['pid'] ..
                        "%22%2C%0A%20%20%20%20%20%20%20%20%22identityType%22%3A%20%22ALIPAY_USER_ID%22%0A%20%20%20%20%7D%0A%7D"
                    local uri = "alipays://platformapi/startapp?appId=2021003124679502&closeAllActivityAnimation=true&startMultApp=YES&transAnimate=true&url=" .. helper.url_encode(uri2)
                    return renderResponse({
                        type = "jump",
                        url = uri
                    })
                end

                return renderResponse({
                    type = "jump",
                    url = authUri
                })
            end

            return renderResponse({
                type = "qrcode",
                qrcode = baseUrl .. "/pay/" .. vOrderInfo.order_id,
                url = "",
                content = "",
                scheme = "alipayqr://platformapi/startapp?appId=20000067&url=" .. helper.url_encode("https://render.alipay.com/p/s/i?scheme=" .. helper.url_encode("alipays://platformapi/startapp?appId=20000218&url=" .. helper.url_encode(baseUrl .. "/api/pay/toapp/" .. vOrderInfo.order_id))),
                out_trade_no = ''
            })
        end

        if not ret then
            return renderResponse({
                type = types.PaymentResultTypes.ERROR,
                content = "不支持的收款配置，请检查收款码类型和二维码模式"
            }, 500, "不支持的收款配置，请检查收款码类型和二维码模式")
        end
        return renderResponse(ret)
    end

    return renderResponse(vOldPayData)
end

-- 账号被编辑
function plugin.onAccountChanged(ctx)
    local accountInfo, options = getAccountContext(ctx)

    -- 【自动同步模式】保存账号时直接从同步地址导入应用数据，不再走定时轮询
    if options['config_mode'] == 'auto' then
        local appDataUrl = options['app_data_url']

        if appDataUrl and appDataUrl ~= "" then
            log.info("[应用数据导入] 开始从同步地址导入, account_id=" .. tostring(accountInfo.id))

            -- 立即请求同步地址（不管应用是否已上线，有数据即导入）
            local body, req_err = helper.http_request("GET", appDataUrl, "", {})
            if req_err ~= 0 then
                log.warning("[应用数据导入] 请求失败, err_code=" .. tostring(req_err))
                return baseResponse(500, "请求应用数据接口失败，请检查同步地址后重新保存")
            end

            local ok, data = pcall(json.decode, body)
            if not ok or not data then
                log.warning("[应用数据导入] JSON解析失败: " .. tostring(body))
                return baseResponse(500, "解析应用数据失败，请确认同步地址有效后重新保存")
            end

            -- 接口暂未返回应用数据（申请尚未完成），提示用户稍后重新保存
            if not data.app_id or data.app_id == "" then
                log.info("[应用数据导入] 暂未返回应用数据: " .. tostring(data.message))
                return baseResponse(400, data.message or "同步地址暂未返回应用数据，请等待应用申请完成后重新保存账号")
            end

            -- 私钥换行转义修正（无需PEM头尾，Go层会自动处理）
            if data.private_key and data.private_key ~= "" then
                data.private_key = normalizePemKey(data.private_key)
            end

            -- 导入PID
            if data.pid and data.pid ~= "" then
                helper.channel_account_set_option(accountInfo.id, "pid", data.pid)
                log.info("[应用数据导入] PID已导入: " .. data.pid)
            end

            -- 导入应用ID
            helper.channel_account_set_option(accountInfo.id, "app_id", data.app_id)
            log.info("[应用数据导入] 应用ID已导入: " .. data.app_id)

            -- 导入应用私钥（XArr Go层会自动处理PEM格式，这里直接存原始值）
            if data.private_key and data.private_key ~= "" then
                helper.channel_account_set_option(accountInfo.id, "app_secret", data.private_key)
                log.info("[应用数据导入] 应用私钥已导入")
            end

            -- 填充默认配置（仅当用户未修改时）
            if not options['type'] or options['type'] == "" then
                helper.channel_account_set_option(accountInfo.id, "type", "pid")
            end
            if not options['qrcode_mod'] or options['qrcode_mod'] == "" then
                helper.channel_account_set_option(accountInfo.id, "qrcode_mod", "10")
            end
            if not options['scan_type'] or options['scan_type'] == "" then
                helper.channel_account_set_option(accountInfo.id, "scan_type", "order_or_amount")
            end
            if not options['order_temp_amount'] or options['order_temp_amount'] == "" then
                helper.channel_account_set_option(accountInfo.id, "order_temp_amount", "0")
            end

            -- 导入完成，清空URL并切换为手动模式展示已导入数据
            helper.channel_account_set_option(accountInfo.id, "app_data_url", "")
            helper.channel_account_set_option(accountInfo.id, "config_mode", "manual")
            log.info("[应用数据导入] 导入完成，已切换为手动模式")

            -- 保存时账单验证（本地缓存配置尚未更新，使用刚导入的数据验证）
            local verifyOptions = {}
            for k, v in pairs(options) do
                verifyOptions[k] = v
            end
            verifyOptions['app_id'] = data.app_id
            if data.pid and data.pid ~= "" then
                verifyOptions['pid'] = data.pid
            end
            if data.private_key and data.private_key ~= "" then
                verifyOptions['app_secret'] = data.private_key
            end

            local vcode, vmessage = orderPayHelper.alipay_bill_list(verifyOptions)
            if vcode ~= 200 then
                -- 验证失败置离线（不向外暴露错误详情），待配置修正后由定时任务自动恢复在线
                log.warning("[账号验证] 导入后账单验证失败: " .. tostring(vmessage))
                helper.channel_account_offline(accountInfo.id)
                return baseResponse(200, "应用数据导入成功，但账单验证失败，账号已置为离线")
            end

            helper.channel_account_online(accountInfo.id)
            return baseResponse(200, "应用数据导入成功，账号验证成功")
        end

        -- 无同步地址：已导入过（URL已清空）则走下方账单验证，否则提示填写
        if not options['app_id'] or options['app_id'] == '' then
            return baseResponse(400, "请填入应用数据同步地址")
        end
        log.info("[账号验证] 应用数据已导入（app_id=" .. tostring(options['app_id']) .. "），进行账单验证")
    end

    -- 手动配置模式但未填写必要信息，跳过验证
    if options['config_mode'] == 'manual' then
        if not options['app_id'] or options['app_id'] == '' then
            log.info("[账号验证] 手动配置模式，应用ID为空，跳过账单验证")
            return baseResponse(200, "请完善应用ID等信息后保存")
        end
        if not options['app_secret'] or options['app_secret'] == '' then
            log.info("[账号验证] 手动配置模式，应用私钥为空，跳过账单验证")
            return baseResponse(200, "请完善应用私钥后保存")
        end

        -- 私钥换行转义修正（字面\n转真实换行），回写修正并用于本次验证
        local pemKey = normalizePemKey(options['app_secret'])
        if pemKey ~= options['app_secret'] then
            helper.channel_account_set_option(accountInfo.id, "app_secret", pemKey)
            options['app_secret'] = pemKey
            log.info("[账号验证] 应用私钥换行符已修正, account_id=" .. tostring(accountInfo.id))
        end
    end

    ---- 获取支付宝订单列表（优先使用本次提交的表单配置，account_info.options可能是保存前的旧缓存）
    local billOptions = options
    if (not billOptions['app_id'] or billOptions['app_id'] == '') and type(accountInfo.options) == 'table' then
        billOptions = accountInfo.options
    end
    log.info("[账号验证] 保存时账单验证, account_id=" .. tostring(accountInfo.id) .. ", app_id=" .. tostring(billOptions['app_id']))

    local err_code, err_message, list = orderPayHelper.alipay_bill_list(billOptions)
    if err_code ~= 200 then
        -- 验证失败置离线（不向外暴露错误详情），待配置修正后由定时任务自动恢复在线
        log.warning("[账号验证] 账单拉取失败: " .. tostring(err_message))
        helper.channel_account_offline(accountInfo.id)
        return baseResponse(200, "配置已保存，但账单验证失败，账号已置为离线")
    end

    -- 如果离线状态 则设置为在线
    if accountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(accountInfo.id)
    end

    return baseResponse(200, "账号验证成功")
end

-- 测试应用上线按钮
function plugin.checkAppOnline(ctx)
    local accountInfo, options = getAccountContext(ctx)

    -- 获取URL（优先使用表单中的app_data_url，其次使用已保存的）
    local appDataUrl = options['app_data_url']
    if not appDataUrl or appDataUrl == "" then
        return baseResponse(400, "请先在账号配置中填入【应用数据同步地址】")
    end

    log.info("[测试应用上线] 开始测试, account_id=" .. tostring(accountInfo.id))

    -- 发起HTTP请求
    local body, err_code = helper.http_request("GET", appDataUrl, "", {})
    if err_code ~= 0 then
        return baseResponse(err_code, "请求应用数据接口失败，错误码: " .. tostring(err_code))
    end

    -- 解析返回数据
    local ok, data = pcall(json.decode, body)
    if not ok or not data then
        return baseResponse(500, "解析返回数据失败")
    end

    -- 构建返回信息
    local result = {
        is_online = data.is_online or false,
        app_id = data.app_id or "",
        app_name = data.app_name or "",
        pid = data.pid or "",
        has_private_key = data.private_key and data.private_key ~= "",
        last_status = data.last_status or "unknown",
    }

    if data.is_online then
        result.tip = "应用已上线！可以同步配置或手动填入PID/应用ID/私钥"
    elseif data.message then
        result.tip = data.message
    else
        result.tip = "应用尚未上线，请等待审核通过"
    end

    log.info("[测试应用上线] 结果: is_online=" .. tostring(data.is_online))

    return {
        code = 200,
        message = "测试完成",
        data = result
    }
end

return plugin

