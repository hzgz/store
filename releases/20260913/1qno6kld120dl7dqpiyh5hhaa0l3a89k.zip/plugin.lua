---@diagnostic disable: undefined-global
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")
PAY_DOUYIN_NATIVE = "douyinpay_hg"
local API_HOST = "https://api.douyinpay.com"
local NATIVE_PATH = "/v1/trade/transactions/native"

local plugin = {}
function plugin.pluginInfo()
    return {
        channels = {douyinpay = { { label = '抖音支付扫码', value = PAY_DOUYIN_NATIVE } }},
        options = {callback = 1, detection_interval = 0}
    }
end
function plugin.formItems(ctx) return { inputs = {
    { name = 'appid', label = '应用ID(Client Key)', type = types.InputTypes.INPUT, default = "", placeholder = "抖音开放平台网站应用Client Key", rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
    { name = 'appmchid', label = '商户号', type = types.InputTypes.INPUT, default = "", placeholder = "抖音支付商户号", rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
    { name = 'apikey', label = '接口加密密钥', type = types.InputTypes.INPUT, default = "", placeholder = "APIv3密钥", rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
    { name = 'certserial', label = '商户API证书序列号', type = types.InputTypes.INPUT, default = "", placeholder = "证书序列号", rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
    { name = 'appsecret', label = '商户API私钥(.pem内容)', type = types.InputTypes.TEXTAREA, hidden_list = 1, default = "", placeholder = "-----BEGIN PRIVATE KEY-----", rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
    { name = 'notify_domain', label = '回调通知域名兜底', type = types.InputTypes.INPUT, default = "", placeholder = "如 mzf.950621.cn(仅域名不带http), 留空则用原notify_url", rules = {} },
} } end

-- 官方直连Native签名: method\npath\ntimestamp\nnonce\nbody\n (每行以\n结尾, path不含域名)
function plugin.makeAuth(method, path, body, mchid, serial, privateKey)
    local ts = tostring(helper.time_now_timestamp())
    local nonce = helper.str_random(16)
    local signStr = method .. "\n" .. path .. "\n" .. ts .. "\n" .. nonce .. "\n" .. (body or "") .. "\n"
    local sig = helper.rsa_private_sign_base64(signStr, privateKey, "SHA256")
    return 'DouyinPay-RSA mchid="'..mchid..'",nonce_str="'..nonce..'",signature="'..sig..'",timestamp="'..ts..'",serial_no="'..serial..'"'
end

function plugin.create(ctx)
    local o = ctx.order_info; local opts = ctx.account_options
    -- 回调域名兜底: 若配置了 notify_domain(纯域名,不带协议), 则把 notify_url 的域名替换为该域名, 保持路径与订单号后缀不变
    local notify_url = o.notify_url
    local override_domain = (opts.notify_domain or ""):gsub("^https?://", ""):gsub("/+$", "")
    if override_domain ~= "" then
        local scheme, host, rest = tostring(notify_url):match("^(https?://)([^/]+)(.*)$")
        if scheme and host and rest then
            notify_url = scheme .. override_domain .. rest
        end
    end
    log.info("抖音支付发起下单 order_id=" .. tostring(o.order_id) .. " amount=" .. tostring(o.trade_amount) .. " notify_url=" .. tostring(notify_url) .. " override_domain=" .. tostring(override_domain))
    local body = {
        appid = opts.appid,
        mchid = opts.appmchid,
        description = o.subject or "",
        out_trade_no = o.order_id,
        notify_url = notify_url,
        amount = { total = o.trade_amount, currency = "CNY" },
        scene_info = { payer_client_ip = o.client_ip or "127.0.0.1" }
    }
    local bodyStr = json.encode(body)
    local path = NATIVE_PATH
    local auth = plugin.makeAuth("POST", path, bodyStr, opts.appmchid, opts.certserial, opts.appsecret)
    local hp = { query="", body=bodyStr, form="", timeout="30s",
        headers = { ["Content-Type"]="application/json", ["Authorization"]=auth, ["Accept"]="application/json" } }
    local r, _ = http.request("POST", API_HOST..path, hp)
    if r.status_code~=200 then
        local msg = (r.body or ""):gsub("%s+", " ")
        log.error("抖音支付下单失败 order_id=" .. tostring(o.order_id) .. " http=" .. tostring(r.status_code) .. " resp=" .. tostring(msg))
        return { code = 500, message = "抖音API请求失败 HTTP "..tostring(r.status_code).." "..tostring(msg), data = {} }
    end
    local res = json.decode(r.body)
    if not res or not res.code_url then
        log.error("抖音支付下单未返回二维码 order_id=" .. tostring(o.order_id) .. " resp=" .. tostring(r.body))
        return { code = 500, message = "抖音API:未返回二维码", data = {} }
    end
    return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode = res.code_url, out_trade_no = "" } }
end

-- 内部函数: 抖音回调 header 读取 (兼容单数 header 与复数 headers)
local function callback_headers(ctx)
    local h = ctx.request.header
    if not h or type(h) ~= "table" then h = ctx.request.headers or {} end
    local get = function(name)
        if type(h) ~= "table" then return "" end
        local v = h[name] or h[name:lower()] or h[name:upper()] or ""
        if type(v) ~= "string" then v = "" end
        return v
    end
    return get
end

-- 内部函数: 校验抖音回调 RSA 签名 (平台公钥, 仅当配置了平台公钥时启用)
local function verify_callback_signature(get, body, opts)
    local platform_key = opts and (opts.platform_public_key or opts.platformcert or "") or ""
    if not platform_key or platform_key == "" then return true, nil end
    local timestamp = get("Douyinpay-Timestamp")
    local nonce = get("Douyinpay-Nonce")
    local signature = get("Douyinpay-Signature")
    if timestamp == "" or nonce == "" or signature == "" then
        return false, "回调缺少验签头 Douyinpay-Timestamp/Nonce/Signature"
    end
    local sign_str = timestamp .. "\n" .. nonce .. "\n" .. body .. "\n"
    local ok = helper.rsa_public_verify_sign_base64(sign_str, signature, platform_key, "SHA256")
    if not ok then return false, "回调签名验证失败" end
    return true, nil
end

-- =====================================================================
-- 内嵌纯Lua AES-256-GCM 解密引擎 (无bit库/无ffi/无openssl, 兼容Lua 5.1)
-- 仅依赖框架 helper.base64_decode 提供原始字节串. 依据 FIPS-197 + SP800-38D.
-- =====================================================================
local _unpack = unpack or table.unpack

-- 字节按位 XOR (0..255)
local function bxor8(a, b)
    local r, p = 0, 1
    while a > 0 or b > 0 do
        if (a % 2) ~= (b % 2) then r = r + p end
        a, b = math.floor(a / 2), math.floor(b / 2)
        p = p * 2
    end
    return r
end

-- GF(2^8) 乘法 (mod x^8+x^4+x^3+x+1 = 0x11b)
local function gmul8(a, b)
    local p = 0
    for _ = 1, 8 do
        if b % 2 == 1 then p = bxor8(p, a) end
        local hi = math.floor(a / 128)
        a = (a * 2) % 256
        if hi == 1 then a = bxor8(a, 0x1b) end
        b = math.floor(b / 2)
    end
    return p
end

-- AES S盒 (256字节, 规范常量)
local _SBOX = ""
do
    local function hx(h)
        local t = {}
        for i = 1, #h, 2 do t[#t + 1] = string.char(tonumber(h:sub(i, i + 1), 16)) end
        return table.concat(t)
    end
    _SBOX = hx(
        "637c777bf26b6fc53001672bfed7ab76" ..
        "ca82c97dfa5947f0add4a2af9ca472c0" ..
        "b7fd9326363ff7cc34a5e5f171d83115" ..
        "04c723c31896059a071280e2eb27b275" ..
        "09832c1a1b6e5aa0523bd6b329e32f84" ..
        "53d100ed20fcb15b6acbbe394a4c58cf" ..
        "d0efaafb434d338545f9027f503c9fa8" ..
        "51a3408f929d38f5bcb6da2110fff3d2" ..
        "cd0c13ec5f974417c4a77e3d645d1973" ..
        "60814fdc222a908846eeb814de5e0bdb" ..
        "e0323a0a4906245cc2d3ac629195e479" ..
        "e7c8376d8dd54ea96c56f4ea657aae08" ..
        "ba78252e1ca6b4c6e8dd741f4bbd8b8a" ..
        "703eb5664803f60e613557b986c11d9e" ..
        "e1f8981169d98e949b1e87e9ce5528df" ..
        "8ca1890dbfe6426841992d0fb054bb16")
end
local function sbox(v) return string.byte(_SBOX, v + 1) end

-- AES-256 密钥扩展 -> words[0..59], 每个word为{4字节}
local function aes256_words(key)
    local k = {}
    for i = 1, 32 do k[i] = string.byte(key, i) end
    local words = {}
    for i = 0, 7 do words[i] = { k[4 * i + 1], k[4 * i + 2], k[4 * i + 3], k[4 * i + 4] } end
    local rcon = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40 }
    local function subw(w) return { sbox(w[1]), sbox(w[2]), sbox(w[3]), sbox(w[4]) } end
    local function rotw(w) return { w[2], w[3], w[4], w[1] } end
    for i = 8, 59 do
        local t = { words[i - 1][1], words[i - 1][2], words[i - 1][3], words[i - 1][4] }
        if i % 8 == 0 then
            t = subw(rotw(t))
            t[1] = bxor8(t[1], rcon[i / 8])
        elseif i % 8 == 4 then
            t = subw(t)
        end
        local p = words[i - 8]
        words[i] = { bxor8(p[1], t[1]), bxor8(p[2], t[2]), bxor8(p[3], t[3]), bxor8(p[4], t[4]) }
    end
    return words
end

-- 用给定密钥扩展结果加密一个16字节块
local function aes_encrypt_with(words, block)
    local st = {}
    for i = 0, 15 do st[i] = string.byte(block, i + 1) end
    local function addkey(rnd)
        local base = 4 * rnd
        for k = 0, 15 do
            local w = words[base + math.floor(k / 4)]
            st[k] = bxor8(st[k], w[(k % 4) + 1])
        end
    end
    local function subbytes()
        for i = 0, 15 do st[i] = sbox(st[i]) end
    end
    local function shiftrows()
        for r = 1, 3 do
            local old = {}
            for c = 0, 3 do old[c] = st[c * 4 + r] end
            for c = 0, 3 do st[c * 4 + r] = old[((c + r) % 4)] end
        end
    end
    local function mixcolumns()
        for c = 0, 3 do
            local a0, a1, a2, a3 = st[c * 4 + 0], st[c * 4 + 1], st[c * 4 + 2], st[c * 4 + 3]
            st[c * 4 + 0] = bxor8(gmul8(a0, 2), bxor8(gmul8(a1, 3), bxor8(a2, a3)))
            st[c * 4 + 1] = bxor8(a0, bxor8(gmul8(a1, 2), bxor8(gmul8(a2, 3), a3)))
            st[c * 4 + 2] = bxor8(a0, bxor8(a1, bxor8(gmul8(a2, 2), gmul8(a3, 3))))
            st[c * 4 + 3] = bxor8(gmul8(a0, 3), bxor8(a1, bxor8(a2, gmul8(a3, 2))))
        end
    end
    addkey(0)
    for rnd = 1, 13 do
        subbytes(); shiftrows(); mixcolumns(); addkey(rnd)
    end
    subbytes(); shiftrows(); addkey(14)
    local out = {}
    for i = 0, 15 do out[i + 1] = st[i] end
    return string.char(_unpack(out))
end

local function aes_enc_block(key, block)
    return aes_encrypt_with(aes256_words(key), block)
end

-- ---- GF(2^128) 运算, 块以数组[1..16]表示, [1]=最高字节 ----
local function zero_blk()
    return { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
end
local function str_to_blk(s)
    local a = {}
    for i = 1, 16 do a[i] = string.byte(s, i) end
    return a
end
local function blk_xor(a, b)
    local r = {}
    for i = 1, 16 do r[i] = bxor8(a[i], b[i]) end
    return r
end
local function blk_rshift1(V)
    local o = {}
    o[1] = math.floor(V[1] / 2)
    for j = 2, 16 do
        o[j] = math.floor(V[j] / 2) + ((V[j - 1] % 2) * 128)
    end
    return o
end
-- GHASH 域乘法 (NIST SP800-38D): 读A从最高位(x^127)向下, V逐步右移, R=0xE100..00 高位规约
local function gf128_mul(A, B)
    local Z = zero_blk()
    local V = {}
    for i = 1, 16 do V[i] = B[i] end
    local R = zero_blk()
    R[1] = 0xE1
    for p = 0, 127 do
        local by = math.floor(p / 8) + 1
        local bit = 7 - (p % 8)
        if math.floor(A[by] / (2 ^ bit)) % 2 == 1 then Z = blk_xor(Z, V) end
        local lsb = V[16] % 2
        V = blk_rshift1(V)
        if lsb == 1 then V = blk_xor(V, R) end
    end
    return Z
end
local function pad_blocks(str)
    local blocks = {}
    local n = #str
    local full = math.floor(n / 16)
    for b = 0, full - 1 do blocks[#blocks + 1] = str:sub(b * 16 + 1, b * 16 + 16) end
    local rem = n % 16
    if rem > 0 then blocks[#blocks + 1] = str:sub(n - rem + 1) .. string.rep("\0", 16 - rem) end
    return blocks
end
local function be8(v)
    local b = {}
    for i = 8, 1, -1 do
        b[i] = v % 256
        v = math.floor(v / 256)
    end
    return string.char(_unpack(b))
end
local function be4(v)
    return string.char(math.floor(v / 16777216) % 256, math.floor(v / 65536) % 256,
        math.floor(v / 256) % 256, v % 256)
end

-- ---- AEAD-AES-256-GCM 解密 (密钥32字节原串) ----
local function aes_gcm_decrypt(key, iv, ct, tag, aad)
    aad = aad or ""
    if #key ~= 32 then return nil end
    if #tag ~= 16 then return nil end
    local H = aes_enc_block(key, string.rep("\0", 16))
    local J0 = iv .. "\0\0\0\1"
    local n = #ct
    local out = {}
    local blk = math.ceil(n / 16)
    for b = 0, blk - 1 do
        local cnt = b + 2
        local cb = iv .. be4(cnt)
        local ks = aes_enc_block(key, cb)
        local start, len = b * 16 + 1, math.min(16, n - b * 16)
        for i = 1, len do
            out[#out + 1] = string.char(bxor8(string.byte(ct, start + i - 1), string.byte(ks, i)))
        end
    end
    local plain = table.concat(out)
    local Y = zero_blk()
    local Harray = str_to_blk(H)
    local function acc(str16)
        Y = gf128_mul(blk_xor(Y, str_to_blk(str16)), Harray)
    end
    for _, b in ipairs(pad_blocks(aad)) do acc(b) end
    for _, b in ipairs(pad_blocks(ct)) do acc(b) end
    acc(be8(#aad * 8) .. be8(#ct * 8))
    local Yb = {}
    for i = 1, 16 do Yb[i] = string.char(Y[i]) end
    local ej0 = aes_enc_block(key, J0)
    local T = {}
    for i = 1, 16 do
        T[i] = string.char(bxor8(string.byte(ej0, i), string.byte(table.concat(Yb), i)))
    end
    local tagcalc = table.concat(T)
    if tagcalc ~= tag then return nil end
    return plain
end

-- 加载期自检: 使用 Go crypto 官方同款(NIST) AES-256-GCM 测试向量
do
    local function hex2(h)
        local t = {}
        for i = 1, #h, 2 do t[#t + 1] = string.char(tonumber(h:sub(i, i + 1), 16)) end
        return table.concat(t)
    end
    local okSelf = false
    local msgSelf = "未执行"
    pcall(function()
        local k = hex2("feffe9928665731c6d6a8f9467308308feffe9928665731c6d6a8f9467308308")
        local iv = hex2("e1934f5db57cc983e6b180e7")
        local aad = hex2("0a8a18a7150e940c3d87b38e73baee9a5c049ee21795663e264b694a949822b639092d0e67015e86363583fcf0ca645af9f43375f05fdb4ce84f411dcbca73c2220dea03a20115d2e51398344b16bee1ed7c499b353d6c597af8")
        local ct_tag = hex2("fc1ae2b5dcd2c4176c3f538b4c3cc21197f79e608cc3730167936382e4b1e5a7b75ae1678bcebd876705477eb0e0fdbbcda92fb9a0dc58c8d8f84fb590e0422e6077ef")
        local plen = 51
        local ct = ct_tag:sub(1, plen)
        local tag = ct_tag:sub(plen + 1)
        local expect = hex2("73ed042327f70fe9c572a61545eda8b2a0c6e1d6c291ef19248e973aee6c312012f490c2c6f6166f4a59431e182663fcaea05a")
        local p = aes_gcm_decrypt(k, iv, ct, tag, aad)
        if p == expect then
            okSelf = true
            msgSelf = "内嵌AES-256-GCM自检通过"
        else
            msgSelf = "内嵌AES-256-GCM自检失败(明文不匹配)"
        end
    end)
    pcall(function() log.info("douyinpay_hg AES-256-GCM 自检: " .. msgSelf) end)
end

-- 内部函数: 解密抖音支付回调 resource (AEAD-AES-256-GCM, 密钥=接口加密密钥 apikey)
local function decrypt_callback_resource(ciphertext_b64, nonce, aad, apikey)
    -- apikey 兼容两种输入: 直接 32 字节原串, 或 32 字节经 base64 编码的串
    local key_bytes = apikey
    if type(apikey) == "string" and #apikey == 32 then
        key_bytes = apikey
    else
        local okD, dec = pcall(helper.base64_decode, apikey or "")
        if okD and dec and #dec == 32 then key_bytes = dec end
    end
    if not key_bytes or #key_bytes ~= 32 then
        return nil, "apikey需为32字节原串或其base64编码"
    end
    local okC, ct_bytes = pcall(helper.base64_decode, ciphertext_b64)
    if not okC or not ct_bytes then return nil, "ciphertext base64解码失败" end
    if #ct_bytes < 17 then return nil, "密文过短" end
    local ct = ct_bytes:sub(1, #ct_bytes - 16)
    local tag = ct_bytes:sub(#ct_bytes - 15)
    if #nonce ~= 12 then return nil, "nonce需12字节" end
    local okP, plain = pcall(aes_gcm_decrypt, key_bytes, nonce, ct, tag, aad)
    if not okP or not plain then
        return nil, "回调解密失败或标签校验不通过"
    end
    local data, err = json.decode(plain)
    if err or not data then return nil, "解密数据解析失败" end
    return data, nil
end

-- 回调: 抖音官方 Native 回调, 交易数据在加密的 resource.ciphertext 中(AEAD-AES-256-GCM)
function plugin.notify(ctx)
    local o = ctx.order_info; local opts = ctx.account_options; local pp = ctx.params
    local method = (ctx.request and (ctx.request.method or "?")) or "?"
    local body = ctx.request.body_string or ctx.request.body or ""
    log.info("抖音支付收到回调 method=" .. tostring(method) .. " order_id=" .. tostring(o and o.order_id))
    if not body or body == "" then
        log.error("抖音支付回调内容为空 order_id=" .. tostring(o and o.order_id))
        return { code = 400, message = "回调内容为空", data = { response = "" } }
    end

    local get = callback_headers(ctx)
    local ok_sign, sign_err = verify_callback_signature(get, body, opts)
    if not ok_sign then
        log.error("抖音支付回调签名验证失败 order_id=" .. tostring(o and o.order_id) .. " err=" .. tostring(sign_err))
        return { code = 403, message = "签名验证失败: " .. (sign_err or "未知错误"), data = { response = "fail" } }
    end

    local arr = json.decode(body)
    if not arr then
        log.error("抖音支付回调解析失败 order_id=" .. tostring(o and o.order_id))
        return { code = 400, message = "回调解析失败", data = { response = "fail" } }
    end

    -- 非支付成功事件: 返回成功避免抖音重复推送
    if arr.event_type ~= "TRANSACTION.SUCCESS" then
        log.info("抖音支付非支付成功事件 order_id=" .. tostring(o and o.order_id) .. " event_type=" .. tostring(arr.event_type))
        return { code = 200, message = "接收成功", data = { response = "success" } }
    end

    local resource = arr.resource
    if not resource or not resource.ciphertext then
        log.error("抖音支付回调缺少加密资源 order_id=" .. tostring(o and o.order_id))
        return { code = 400, message = "回调缺少加密资源", data = { response = "fail" } }
    end
    if resource.algorithm and resource.algorithm ~= "AEAD-AES-256-GCM" then
        log.error("抖音支付不支持的加密算法 order_id=" .. tostring(o and o.order_id) .. " algorithm=" .. tostring(resource.algorithm))
        return { code = 400, message = "不支持的加密算法: " .. tostring(resource.algorithm), data = { response = "fail" } }
    end

    local plain_data, decrypt_err = decrypt_callback_resource(
        resource.ciphertext,
        resource.nonce or "",
        resource.associated_data or "",
        opts.apikey
    )
    if decrypt_err then
        log.error("抖音支付回调解密失败 order_id=" .. tostring(o and o.order_id) .. " err=" .. tostring(decrypt_err))
        return { code = 400, message = "回调解密失败: " .. decrypt_err, data = { response = "fail" } }
    end
    log.info("抖音支付回调解密成功 order_id=" .. tostring(o.order_id) .. " 交易号=" .. tostring(plain_data.transaction_id))

    -- 校验订单信息
    if opts.appmchid and plain_data.mchid and plain_data.mchid ~= opts.appmchid then
        log.error("抖音支付回调商户号不匹配 order_id=" .. tostring(o and o.order_id) .. " 回调=" .. tostring(plain_data.mchid) .. " 配置=" .. tostring(opts.appmchid))
        return { code = 400, message = "回调商户号不匹配", data = { response = "fail" } }
    end
    if plain_data.out_trade_no ~= o.order_id then
        log.error("抖音支付回调订单号不匹配 order_id=" .. tostring(o and o.order_id) .. " 回调=" .. tostring(plain_data.out_trade_no) .. " 本地=" .. tostring(o.order_id))
        return { code = 400, message = "订单号不匹配", data = { response = "fail" } }
    end
    local callback_amount = (plain_data.amount and plain_data.amount.total) or 0
    local order_amount = o.trade_amount or 0
    if callback_amount ~= order_amount then
        log.error("抖音支付金额不匹配 order_id=" .. tostring(o.order_id) .. " 回调=" .. tostring(callback_amount) .. " 本地=" .. tostring(order_amount))
        return { code = 400, message = "支付金额不匹配", data = { response = "fail" } }
    end

    -- 框架约定(对齐 wxpay_hg/qqpay_native_hg/huifu 等成熟通道): trade_no 槽位传平台订单号 o.order_id(查找键), out_trade_no 槽位传第三方交易号
    local ec, em, rp = orderHelper.notify_process(json.encode({
        out_trade_no = plain_data.transaction_id or "",
        trade_no = o.order_id,
        amount = callback_amount,
    }), json.encode(pp), json.encode(opts))
    log.info("抖音支付订单回调处理结果 order_id=" .. tostring(o.order_id) .. " ec=" .. tostring(ec) .. " em=" .. tostring(em))
    if ec == 200 then
        return { code = 200, message = "success", data = { response = rp or "success" } }
    end
    return { code = ec, message = em, data = { response = "fail" } }
end

return plugin
