---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 PC自挂-支付宝-靓仔监控端
local PAY_PC_ALIPAY_LZ = "pc_alipay_lz"

-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["alipay"] = { {
                label = 'PC自挂-支付宝-靓仔监控端',
                value = PAY_PC_ALIPAY_LZ,
                report = 1,
                parse_msg = 1,
                options = {
                    use_add_amount = 1,
                    use_pay_codes = 1
                }
            } }
        },
        options = {
            callback = 0,
            detection_interval = 0,
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'qrcode',
                label = '收款码地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.type == 'qrcode'",
                options = {
                    append_deqrocde = 1,
                    tip = ''
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = 'qrcode_file',
                label = '收款码图片',
                type = types.InputTypes.IMAGE,
                default = "",
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.type == 'image'",
                options = {
                    tip = ''
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = 'pid',
                label = 'PID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入PID",
                when = "this.formModel.options.type == 'pid'",
                options = {
                    tip = ''
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = 'qrcode_mod',
                label = '二维码模式',
                type = types.InputTypes.SELECT,
                default = "9",
                placeholder = "请选择二维码模式",
                when = "this.formModel.options.type == 'pid'",
                options = {
                    tip = ''
                },
                values = {
                    { label = "模式9", value = "9" },
                    { label = "模式10", value = "10" },
                    { label = "模式11", value = "11" },
                    { label = "转账确认单", value = "12" }
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = 'type',
                label = '收款码类型',
                type = types.InputTypes.SELECT,
                default = "qrcode",
                placeholder = "请选择收款码类型",
                options = {
                    tip = ''
                },
                values = {
                    { label = "二维码", value = "qrcode" },
                    { label = "二维码图片", value = "image" },
                    { label = "PID", value = "pid" }
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local orderInfo = ctx.order_info
    local options = ctx.account_options

    if options['type'] == 'image' then
        return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode_file = options['qrcode_file'], url = "", content = "", out_trade_no = '' } }
    elseif options['type'] == 'pid' then
        if options['qrcode_mod'] == '9' then
            return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode = "https://ds.alipay.com/?from=pc&appId=20000116&actionType=toAccount&goBack=NO&amount=" .. orderInfo.trade_amount_str .. "&userId=" .. options['pid'] .. "&memo=" .. orderInfo.order_id, scheme = "alipayqr://platformapi/startapp?saId=10000007&qrcode=https%3A%2F%2Fds.alipay.com%2F%3Ffrom%3Dpc%26appId%3D20000116%26actionType%3DtoAccount%26goBack%3DNO%26amount%3D" .. orderInfo.trade_amount_str .. "%26userId%3D" .. options['pid'] .. "%26memo%3D" .. orderInfo.order_id, url = "", content = "", out_trade_no = '' } }
        elseif options['qrcode_mod'] == '10' then
            local qrcode = "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" .. options['pid'] .. "%2522%252C%2522a%2522%253A%2522" .. orderInfo.trade_amount_str .. "%2522%252C%2522m%2522%253A%2522" .. orderInfo.order_id .. "%2522%257D"
            return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode_use_short_url = 1, qrcode = qrcode, scheme = qrcode, url = "", content = "", out_trade_no = '' } }
        elseif options['qrcode_mod'] == '11' then
            return { code = 200, message = "success", data = { type = types.PaymentResultTypes.HTML, qrcode_use_short_url = 1, url = "", content = plugin.buildMod11Html(options['pid'], orderInfo.trade_amount_str, orderInfo.order_id), out_trade_no = '' } }
        elseif options['qrcode_mod'] == '12' then
            local qrData = "http://m.alipay.com/?scheme=" .. helper.url_encode("alipays://platformapi/startapp?appId=20000107&page=&url=" .. plugin.buildMod12Uri(options['pid'], orderInfo.trade_amount_str, orderInfo.order_id))
            return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode = qrData, scheme = "alipayqr://platformapi/startapp?saId=10000007&qrcode=" .. helper.url_encode(qrData), out_trade_no = '' } }
        end
    elseif options['type'] == 'qrcode' then
        return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode = options['qrcode'], url = "", scheme = "alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=" .. helper.url_encode(options['qrcode']) .. "%3F_s%3Dweb-other", content = "", out_trade_no = '' } }
    end

    return { code = 500, message = "创建支付失败", data = { type = types.PaymentResultTypes.QRCODE } }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    return { code = 500, message = "暂不支持", data = { response = "" } }
end

function plugin.buildMod11Html(pid, money, order_id)
    return [[<!DOCTYPE html><html lang="zh"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><script src="//gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script></head><body><script>var userId="]] .. pid .. [[";var money="]] .. money .. [[";var remark="]] .. order_id .. [[";function ready(a){window.AlipayJSBridge?a&&a():document.addEventListener("AlipayJSBridgeReady",a,!1)}ready(function(){AlipayJSBridge.call("startApp",{appId:"20000123",param:{actionType:"scan",u:userId,a:money,m:remark,biz_data:{s:"money",u:userId,a:money,m:remark}}},function(a){})});</script></body></html>]]
end

function plugin.buildMod12Uri(pid, money, order_id)
    return string.format("https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%s", helper.url_encode(json.encode({ productCode = "TRANSFER_TO_ALIPAY_ACCOUNT", bizScene = "YUEBAO", transAmount = money, remark = order_id, payeeInfo = { identity = pid, identityType = "ALIPAY_USER_ID" } })))
end

return plugin
