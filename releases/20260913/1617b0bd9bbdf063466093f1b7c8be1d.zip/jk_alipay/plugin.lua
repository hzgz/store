---@diagnostic disable: undefined-global
-- 监控插件 - 支付宝
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

-- 定义常量
local PAY_ALIPAY_APP = "alipay_app"
local PAY_ALIPAY_Dianyuan = "alipay_dianyuan"

local function decodeJsonObject(value)
    if type(value) == "table" then
        return value
    end
    if type(value) ~= "string" or value == "" then
        return nil
    end

    local ok, decoded = pcall(json.decode, value)
    if ok and type(decoded) == "table" then
        return decoded
    end
    return nil
end

local function normalizeHeartbeatStatus(value)
    if type(value) ~= "string" then
        return nil
    end
    local status = string.lower(string.match(value, "^%s*(.-)%s*$"))
    if status == "online" or status == "offline" then
        return status
    end
    return nil
end

local function tableKeys(value)
    local keys = {}
    if type(value) == "table" then
        for key in pairs(value) do
            keys[#keys + 1] = tostring(key)
        end
        table.sort(keys)
    end
    return table.concat(keys, ",")
end

local accountContainerKeys = {
    "account_info",
    "channel_account",
    "account",
    "accountInfo",
    "channelAccount"
}

local function accountFrom(value)
    if type(value) ~= "table" then
        return nil, nil
    end

    local function match(candidate)
        if type(candidate) ~= "table" then
            return nil, nil
        end
        local accountId = tonumber(candidate.id or candidate.account_id or candidate.channel_account_id or candidate.channel_id)
        if accountId ~= nil and accountId > 0 and accountId % 1 == 0 then
            return candidate, accountId
        end
        return nil, nil
    end

    local account, accountId = match(value)
    if account ~= nil then
        return account, accountId
    end

    for _, key in ipairs(accountContainerKeys) do
        account, accountId = match(decodeJsonObject(value[key]))
        if account ~= nil then
            return account, accountId
        end
    end

    local data = decodeJsonObject(value.data)
    if data ~= nil then
        account, accountId = match(data)
        if account ~= nil then
            return account, accountId
        end
        for _, key in ipairs(accountContainerKeys) do
            account, accountId = match(decodeJsonObject(data[key]))
            if account ~= nil then
                return account, accountId
            end
        end
    end

    return nil, nil
end

local function heartbeatRequestFrom(firstData, secondData)
    if type(secondData) == "table" and secondData.ext_data ~= nil then
        return secondData
    end
    if type(firstData) ~= "table" then
        return nil
    end
    if firstData.ext_data ~= nil then
        return firstData
    end

    local requestKeys = { "heartbeat_request", "request_data", "request", "body" }
    for _, key in ipairs(requestKeys) do
        local request = decodeJsonObject(firstData[key])
        if request ~= nil and request.ext_data ~= nil then
            return request
        end
    end
    return nil
end


-- @class plugin
local plugin = {}


--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    local info = {
        -- 支持支付类型
        channels = {
            alipay = {
                {
                    label = '支付宝-软件监控',
                    value = PAY_ALIPAY_APP,
                    -- 支持上报
                    report = 1,
                    parse_msg = 1,
                    options = {
                        use_add_amount = 1,
                        use_pay_codes = 1,
                        unique_alias = 1,
                        need_check_online = 1
                    }
                },
            },
        },
    }
    return info
end

--- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    if ctx.pay_channel == PAY_ALIPAY_APP then
        return {
            inputs = {
                {
                    name = 'qrcode',
                    label = '收款码地址',
                    type = types.InputTypes.INPUT,
                    default = "",
                    options = {
                        tip = '',
                        append_deqrocde = 1, -- 增加解析二维码功能
                    },
                    placeholder = "请输入收款码地址",
                    when = "this.formModel.options.type == 'qrcode'",
                    rules = {
                        {
                            required = true,
                            trigger = { "input", "blur" },
                            message = "请输入",
                        }
                    }
                },
                {
                    name = 'qrcode_file',
                    label = '收款码图片',
                    type = types.InputTypes.IMAGE,
                    default = "",
                    options = {
                        tip = '',
                    },
                    placeholder = "请上传收款码图片",
                    when = "this.formModel.options.type == 'image'",
                    rules = {
                        {
                            required = true,
                            trigger = { "input", "blur" },
                            message = "请输入",
                        }
                    }
                },
                {
                    name = 'pid',
                    label = 'PID',
                    type = types.InputTypes.INPUT,
                    default = "",
                    options = {
                        tip = '',
                    },
                    placeholder = "请输入PID",
                    when = "this.formModel.options.type == 'pid'",
                    rules = {
                        {
                            required = true,
                            trigger = { "input", "blur" },
                            message = "请输入",
                        }
                    }
                },
                {
                    name = 'qrcode_mod',
                    label = '二维码模式',
                    type = types.InputTypes.SELECT,
                    default = "9",
                    options = {
                        tip = '',
                    },
                    placeholder = "请选择二维码模式",
                    when = "this.formModel.options.type == 'pid'",
                    values = {
                        {
                            label = "模式9",
                            value = "9"
                        },
                        {
                            label = "模式10",
                            value = "10"
                        },
                        {
                            label = "模式11",
                            value = "11"
                        },
                        {
                            label = "转账确认单",
                            value = "12"
                        },
                    },
                    rules = {
                        {
                            required = true,
                            trigger = { "input", "blur" },
                            message = "请输入",
                        }
                    }
                },
                {
                    name = 'type',
                    label = '收款码类型',
                    type = types.InputTypes.SELECT,
                    default = "qrcode",
                    options = {
                        tip = '',
                    },
                    placeholder = "请选择收款码类型",
                    values = {
                        {
                            label = "二维码",
                            value = "qrcode"
                        },
                        {
                            label = "二维码图片",
                            value = "image"
                        },
                        {
                            label = "PID",
                            value = "pid"
                        },
                    },
                    rules = {
                        {
                            required = true,
                            trigger = { "input", "blur" },
                            message = "请输入",
                        }
                    }
                },
            },
        }
    end

    return {}
end

--- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    if vAccountOptions['type'] == 'image' then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = vAccountOptions['qrcode_file'],
                qrcode = "",
                url = "",
                content = "",
                out_trade_no = '',
            }
        }

    elseif vAccountOptions['type'] == 'pid' then
        if vAccountOptions['qrcode_mod'] == '9' then
            local uri = "https://ds.alipay.com/?from=pc&appId=20000116&actionType=toAccount&goBack=NO&amount=" .. vOrderInfo.trade_amount_str .. "&userId=" .. vAccountOptions['pid'] .. "&memo=" .. vOrderInfo.order_id

            return {
                code = 200,
                message = "success",
                data = {
                    type = types.PaymentResultTypes.QRCODE,
                    qrcode = uri,
                    url = "",
                    content = "",
                    scheme = "alipayqr://platformapi/startapp?saId=10000007&qrcode=" .. helper.url_encode(uri),
                    out_trade_no = '',
                }
            }
        elseif vAccountOptions['qrcode_mod'] == '10' then
            return {
                code = 200,
                message = "success",
                data = {
                    type = types.PaymentResultTypes.QRCODE,
                    qrcode_use_short_url = 1,
                    qrcode = "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" .. vAccountOptions['pid'] .. "%2522%252C%2522a%2522%253A%2522" .. vOrderInfo.trade_amount_str .. "%2522%252C%2522m%2522%253A%2522" .. vOrderInfo.order_id .. "%2522%257D",
                    url = "",
                    content = "",
                    scheme = "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" .. vAccountOptions['pid'] .. "%2522%252C%2522a%2522%253A%2522" .. vOrderInfo.trade_amount_str .. "%2522%252C%2522m%2522%253A%2522" .. vOrderInfo.order_id .. "%2522%257D",
                    out_trade_no = '',
                }
            }
        elseif vAccountOptions['qrcode_mod'] == '11' then
            return {
                code = 200,
                message = "success",
                data = {
                    type = types.PaymentResultTypes.HTML,
                    qrcode_use_short_url = 1,
                    url = "",
                    content = plugin.buildMod11Html(vAccountOptions['pid'], vOrderInfo.trade_amount_str, vOrderInfo.order_id),
                    scheme = "alipays://platformapi/startapp?appId=20000067&url=" .. helper.url_encode("https://render.alipay.com/p/s/i?scheme=" .. helper.url_encode("alipays://platformapi/startapp?appId=20000180&url=" .. helper.url_encode(orderPayHelper.get_toapp_url(vOrderInfo.order_id, vOrderInfo.host)))),
                    out_trade_no = '',
                }
            }

        elseif vAccountOptions['qrcode_mod'] == '12' then
            local qrData = "http://m.alipay.com/?scheme=" .. helper.url_encode("alipays://platformapi/startapp?appId=20000107&page=&url=" .. plugin.buildMod12Uri(vAccountOptions['pid'], vOrderInfo.trade_amount_str, vOrderInfo.order_id))

            return {
                code = 200,
                message = "success",
                data = {
                    type = types.PaymentResultTypes.QRCODE,
                    qrcode = qrData,
                    scheme = "alipayqr://platformapi/startapp?saId=10000007&qrcode=" .. helper.url_encode(qrData),
                    out_trade_no = '',
                }
            }
        end

    end

    local qrcode = vAccountOptions['qrcode'] or ""
    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = qrcode,
            url = "",
            scheme = "alipayqr://platformapi/startapp?saId=10000007&qrcode=" .. helper.url_encode(qrcode),
            content = "",
            out_trade_no = '',
        }
    }
end

--- 支付回调
---@param ctx types.OrderNotifyParams
---@return types.OrderNotifyResp
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = { response = "" },
    }
end

-- 客户端通过 ext_data 显式控制账号在线状态。
---@param pChannelAccount string|table
---@param pHeartbeatRequest string|table|nil
---@return string
function plugin.heartbeat(pChannelAccount, pHeartbeatRequest)
    local firstData = decodeJsonObject(pChannelAccount)
    local secondData = decodeJsonObject(pHeartbeatRequest)
    local channelAccount, accountId = accountFrom(firstData)
    if channelAccount == nil then
        channelAccount, accountId = accountFrom(secondData)
    end

    if channelAccount == nil then
        local firstLength = type(pChannelAccount) == "string" and #pChannelAccount or 0
        local secondLength = type(pHeartbeatRequest) == "string" and #pHeartbeatRequest or 0
        log.warning(string.format(
            "(jk_alipay) 心跳账号结构无效 arg1=%s/%s keys=[%s] arg2=%s/%s keys=[%s]",
            type(pChannelAccount), firstLength, tableKeys(firstData),
            type(pHeartbeatRequest), secondLength, tableKeys(secondData)))
        return json.encode({
            err_code = 500,
            err_message = "心跳账号信息无效，请提供channel_id"
        })
    end

    local heartbeatData = heartbeatRequestFrom(firstData, secondData)
    if heartbeatData == nil or type(heartbeatData.ext_data) ~= "string" or heartbeatData.ext_data == "" then
        return json.encode({
            err_code = 500,
            err_message = "心跳数据解析失败"
        })
    end

    local extData = decodeJsonObject(heartbeatData.ext_data)
    local status = extData and normalizeHeartbeatStatus(extData.status) or nil
    if status == "online" then
        helper.channel_account_online(accountId)
    elseif status == "offline" then
        helper.channel_account_offline(accountId)
    else
        return json.encode({
            err_code = 500,
            err_message = "ext_data.status仅支持online或offline"
        })
    end

    log.info(string.format("(%s) 心跳状态:%s account_id:%s",
        channelAccount.plugin_name or "jk_alipay", status, tostring(accountId)))
    return json.encode({
        err_code = 200,
        err_message = status == "online" and "账号已上线" or "账号已离线"
    })
end

--- 解析上报数据
---@param ctx types.PluginParseMessage
---@return table
function plugin.parseMessage(ctx)
    ---@type types.MessageParseRules
    local reportApps = {
        ["com.eg.android.AlipayGphone"] = {
            {
                title_reg = "收款通知",
                content_reg = "通过扫码向你付款(?<amount>[\\d\\.]+)元",
                channel_code = PAY_ALIPAY_APP
            },
            {
                title_reg = "收钱码",
                content_reg = "通过扫码向你付款(?<amount>[\\d\\.]+)元",
                channel_code = PAY_ALIPAY_APP
            },
            {
                title_reg = "已转入余额(\\s*立即查看余额)?",
                content_reg = "你已成功收款(?<amount>[\\d\\.]+)元",
                channel_code = PAY_ALIPAY_APP
            },
            {
                title_reg = "店员通",
                content_reg = "你已成功收款(?<amount>[\\d\\.]+)元",
                channel_code = PAY_ALIPAY_Dianyuan
            },
            {
                amount_in_title = true,
                title_reg = "你已成功收款(?<amount>[\\d\\.]+)元",
                content_reg = "已转入余额(\\s*.*?)?",
                channel_code = PAY_ALIPAY_APP
            },
        }
    }

    return message_parser.parse(ctx, reportApps)
end

--- 支付数据渲染
---@param ctx types.OrderRenderParams
---@return types.OrderRenderResp
function plugin.render(ctx)
    log.debug("渲染测试数据", ctx.order_info, ctx.pay_data, ctx.account_info, ctx.device)
    local vDeviceInfo = ctx.device
    local vOldPayData = ctx.pay_data

    -- 设备类型处理器映射表（优化：使用查找表替代多层if-else）
    local deviceHandlers = {
        -- 微信环境
        is_wechat = function()
            return {
                code = 200,
                message = "success",
                action = "render",
                data = {
                    type = "text",
                    content = "我在微信里面"
                }
            }
        end,
        
        -- QQ环境
        is_qq = function()
            return {
                code = 200,
                message = "success",
                action = "render",
                data = {
                    type = "text",
                    content = "我在QQ里面"
                }
            }
        end,
        
        -- 支付宝环境：收款码必须交给原生扫码组件，不能作为 H5 页面打开。
        is_alipay = function()
            local target = vOldPayData.scheme
            if target == nil or target == "" then
                target = vOldPayData.qrcode
            end
            return {
                code = 200,
                message = "success",
                action = "render",
                data = {
                    type = "jump",
                    url = target
                }
            }
        end,
        
        -- 浏览器环境
        is_browser = function()
            return {
                code = 200,
                message = "success",
                action = "render",
                data = {
                    type = "text",
                    content = "我在l浏览器里面"
                }
            }
        end,
        
        -- PC环境
        is_pc = function()
            return {
                code = 200,
                message = "success",
                action = "render",
                data = {
                    type = "text",
                    content = "我是PC"
                }
            }
        end,
        
        -- 移动端环境
        is_mobile = function()
            return {
                code = 200,
                message = "success",
                action = "render",
                data = {
                    type = "text",
                    content = "我是手机"
                }
            }
        end
    }

    -- 按优先级检查设备类型并执行对应处理器
    local deviceTypes = {"is_wechat", "is_qq", "is_alipay", "is_browser", "is_pc", "is_mobile"}
    for _, deviceType in ipairs(deviceTypes) do
        if vDeviceInfo[deviceType] then
            local handler = deviceHandlers[deviceType]
            if handler then
                return handler()
            end
        end
    end

    -- 默认返回原始数据
    return {
        code = 200,
        message = "success",
        action = "",
        data = vOldPayData,
    }
end

--- 构建模式11的HTML
---@param pid string
---@param money string
---@param order_id string
---@return string
function plugin.buildMod11Html(pid, money, order_id)
    return [[<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>收银台</title>
    <script src="//gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script>
</head>
<body>
<script>
    var userId = "]] .. pid .. [[";
    var money = "]] .. money .. [[";
    var remark = "]] .. order_id .. [[";

    function returnApp() {
        AlipayJSBridge.call("exitApp")
    }

    function ready(a) {
        window.AlipayJSBridge ? a && a() : document.addEventListener("AlipayJSBridgeReady", a, !1)
    }

    ready(function () {
        try {
            var a = {
                actionType: "scan",
                u: userId,
                a: money,
                m: remark,
                biz_data: {
                    s: "money",
                    u: userId,
                    a: money,
                    m: remark
                }
            }
        } catch (b) {
            returnApp()
        }
        AlipayJSBridge.call("startApp", {
            appId: "20000123",
            param: a
        }, function (a) { })
    });
    document.addEventListener("resume", function (a) {
        returnApp()
    });
</script>
</body>
</html>]]
end

--- 构建模式12的HTML
---@param pid string
---@param money string
---@param order_id string
---@return string
function plugin.buildMod12Html(pid, money, order_id)
    local url = string.format("https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%s", helper.url_encode(json.encode({
        productCode = "TRANSFER_TO_ALIPAY_ACCOUNT",
        bizScene = "YUEBAO",
        outBizNo = "",
        transAmount = money,
        remark = order_id,
        businessParams = {
            returnUrl = "alipays://platformapi/startApp?appId=20000218&bizScenario=transoutXtrans"
        },
        payeeInfo = {
            identity = pid,
            identityType = "ALIPAY_USER_ID"
        }
    })))
    return [[<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>收银台</title>
    <script src="//gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script>
</head>
<body>
<script>
    var userId = "]] .. pid .. [[";
    var money = "]] .. money .. [[";
    var remark = "]] .. order_id .. [[";

     AlipayJSBridge.call('setTitleColor', {
        color: parseInt('1959c1', 16),
        reset: false
    });
    AlipayJSBridge.call('showTitleLoading');
    AlipayJSBridge.call('setTitle', {
        title: '请稍等..',
        subtitle: 'XArrPay正在检测支付环境..'
    });
    AlipayJSBridge.call('setOptionMenu', {
        icontype: 'filter',
        redDot: '02',
    });
    AlipayJSBridge.call('showOptionMenu');
    document.addEventListener('optionMenu', function(e) {
        AlipayJSBridge.call('showPopMenu', {
            menus: [{
                name: '查看帮助',
                tag: 'tag1',
                redDot: ''
            }, {
                name: 'XArrPay',
                tag: 'tag2',
            }],
        }, function(e) {
            console.log(e)
        })
    }, false);

    AlipayJSBridge.call("pushWindow", {
        url: ']] .. url .. [[',
        param: {
            showToolBar: "NO"
        }
    });



</script>
</body>
</html>]]
end

--- 构建模式12的URI
---@param pid string
---@param money string
---@param order_id string
---@return string
function plugin.buildMod12Uri(pid, money, order_id)
    local url = string.format("https://render.alipay.com/p/yuyan/180020010001206672/rent-index.html?formData=%s", helper.url_encode(json.encode({
        productCode = "TRANSFER_TO_ALIPAY_ACCOUNT",
        bizScene = "YUEBAO",
        transAmount = money,
        remark = order_id,
        payeeInfo = {
            identity = pid,
            identityType = "ALIPAY_USER_ID"
        }
    })))
    return url
end

return plugin
