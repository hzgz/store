---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 支付宝云端-靓仔
local PAY_YUN_ALIPAY_LZ = "yun_alipay_lz"

-- @class plugin
local plugin = {}

local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

local function encodeProxyCredentials(proxy)
    proxy = tostring(proxy or "")
    local prefix, userInfo, address = proxy:match("^([%w+.-]+://)([^@]+)@(.+)$")
    if not prefix then return proxy end
    local username, password = userInfo:match("^([^:]*):(.*)$")
    if not username then return proxy end
    return prefix .. helper.url_encode(username) .. ":" .. helper.url_encode(password) .. "@" .. address
end

local function getProxy(accountOptions)
    accountOptions = accountOptions or {}
    local mode = accountOptions.proxy_mode or "no_proxy"
    if mode == "custom_proxy" then return encodeProxyCredentials(accountOptions.proxy or "") end
    if mode ~= "cloud_proxy" then return "" end

    local poolId = tonumber(accountOptions.proxy_pool_id or 0) or 0
    if poolId <= 0 then return "" end
    local itemId = tonumber(accountOptions.proxy_pool_item_id or 0) or 0
    local proxyItem = helper.proxy_pool_fetch(poolId, itemId)
    if proxyItem and proxyItem.proxy_url and proxyItem.proxy_url ~= "" then
        local proxyId = tonumber(proxyItem.proxy_id or 0) or 0
        if proxyId ~= itemId then
            accountOptions.proxy_pool_item_id = proxyId
            if accountOptions.account_id then
                helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", proxyId)
            end
        end
        return encodeProxyCredentials(proxyItem.proxy_url)
    end
    if itemId > 0 then helper.proxy_pool_release(itemId) end
    accountOptions.proxy_pool_item_id = 0
    if accountOptions.account_id then
        helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", "0")
    end
    return ""
end

local function mergeOptions(ctx)
    ctx = ctx or {}
    local accountInfo = ctx.account_info or {}
    local options = { account_id = accountInfo.id }
    for k, v in pairs(toTable(accountInfo.options)) do
        options[k] = v
    end
    for k, v in pairs(toTable(ctx.plugin_option)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.plugin_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.account_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    return options
end

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["alipay"] = { {
                label = '支付宝云端-靓仔',
                value = PAY_YUN_ALIPAY_LZ,
                options = {
                    use_add_amount = 1,
                    use_qrcode_login = 1
                }
            } }
        },
        options = {
            detection_interval = 30,
            detection_type = "cron",
            config = { {
                title = "请输入云端的token密匙",
                key = "yun_token",
                default = "jiaowoliangzai"
            } }
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            { name = 'gateway', label = '选择网关', type = types.InputTypes.SELECT, default = "", placeholder = "请选址网关", options = { chose_gateway = 1, tip = '' }, rules = { { required = true, trigger = { "input", "blur" }, message = "请选择" } } },
            { name = 'qrcode', label = '收款码地址', type = types.InputTypes.INPUT, default = "", placeholder = "请输入收款码地址", when = "this.formModel.options.type == 'qrcode'", options = { append_deqrocde = 1, tip = '' }, rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
            { name = 'qrcode_file', label = '收款码图片', type = types.InputTypes.IMAGE, default = "", placeholder = "请上传收款码图片", when = "this.formModel.options.type == 'image'", options = { tip = '' }, rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
            { name = 'pid', label = 'PID', type = types.InputTypes.INPUT, default = "", placeholder = "扫码登录自动获取，请忽视我！", when = "this.formModel.options.type == 'pid'", options = { tip = '' } },
            { name = 'qrcode_mod', label = '二维码模式', type = types.InputTypes.SELECT, default = "9", placeholder = "请选择二维码模式", when = "this.formModel.options.type == 'pid'", options = { tip = '' }, values = { { label = "免输-转账模式①", value = "9" }, { label = "免输-转账模式②", value = "10" }, { label = "免输-二维码模式③", value = "11" }, { label = "免输-转账单模式④", value = "12" } }, rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
            { name = 'type', label = '收款码类型', type = types.InputTypes.SELECT, default = "pid", placeholder = "请选择收款码类型", options = { tip = '' }, values = { { label = "二维码", value = "qrcode" }, { label = "二维码图片", value = "image" }, { label = "PID", value = "pid" } }, rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
            { name = 'scan_type', label = '订单检查方式', type = types.InputTypes.RADIO, default = "order_or_amount", options = { tip = '' }, values = { { label = "订单号匹配不到则使用金额", value = "order_or_amount" }, { label = "订单号", value = "order" } }, rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
            { name = 'order_temp_amount', label = '取消订单递增金额', type = types.InputTypes.RADIO, default = "0", options = { tip = '<b>注意:</b>订单检查方式为订单号的时候才能选择[是]' }, values = { { label = "否", value = "0" }, { label = "是", value = "1" } }, rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
            { name = "proxy_mode", label = "代理模式", type = types.InputTypes.SELECT, default = "no_proxy", options = { tip = "选择代理使用模式" }, placeholder = "请选择代理模式", values = { { label = "不使用代理", value = "no_proxy" }, { label = "使用自定义代理", value = "custom_proxy" }, { label = "使用本站代理池", value = "cloud_proxy" } }, rules = { { required = true, trigger = { "input", "blur" }, message = "请选择代理模式" } } },
            { name = "proxy", label = "Socks5代理地址", type = types.InputTypes.INPUT, default = "", when = "this.formModel.options.proxy_mode == 'custom_proxy'", options = { tip = "格式：socks5://IP:端口，或 socks5://用户名:密码@IP:端口" }, placeholder = "例如：socks5://127.0.0.1:1080" },
            { name = "proxy_pool_id", label = "绑定代理池", type = "chose_proxy_pool", default = "-1", when = "this.formModel.options.proxy_mode == 'cloud_proxy'", options = { tip = "请选择绑定的代理池" }, placeholder = "请选择代理池", rules = { { required = true, trigger = { "input", "blur" }, message = "请选择代理池" } } },
            { name = "proxy_pool_item_id", label = "绑定代理", type = types.InputTypes.INPUT, default = "0", hidden = 1 },
            { name = 'bind_token', label = '绑定的用户信息', type = types.InputTypes.INPUT, hidden = 1 }
        }
    }
end

function plugin.create(ctx)
    local orderInfo = ctx.order_info
    local options = ctx.account_options
    local accountInfo = ctx.account_info or {}
    local bindTokenInfo = json.decode(options.bind_token or "{}") or {}
    local serverAddress = helper.channel_gateway_addr(options.gateway)
    if serverAddress ~= "" then
        local params = { amount = orderInfo.trade_amount_str, user_pid = accountInfo.uid, uid = bindTokenInfo.uid or "", pid = options.pid or "", order_id = orderInfo.order_id, type = options.type or "", qrcode_mod = options.qrcode_mod or "" }
        local response, error_message = http.request("POST", string.format('%s/Alipay_Frame/CreateOrder', serverAddress), { query = funcs.table_http_query(params), timeout = "10s" })
        if error_message ~= nil then log.info(string.format("[靓仔]  服务端创建订单报错 POST %s", error_message)) elseif response then log.info(string.format("[靓仔]  服务端创建订单成功 POST %s", response.body)) end
    end
    if options['type'] == 'image' then
        return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode_file = options['qrcode_file'], url = "", content = "", out_trade_no = '' } }
    elseif options['type'] == 'pid' then
        return { code = 200, message = "success", data = { type = "render", out_trade_no = '' } }
    elseif options['type'] == 'qrcode' then
        return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode = options['qrcode'], url = "", scheme = "alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=" .. helper.url_encode(options['qrcode']) .. "%3F_s%3Dweb-other", content = "", out_trade_no = '' } }
    end
    return { code = 500, message = "创建支付失败", data = { type = types.PaymentResultTypes.QRCODE } }
end

function plugin.cron(ctx)
    local accountInfo = ctx.account_info
    local options = ctx.account_options or ctx.plugin_options or ctx.plugin_option or {}
    if options.bind_token == nil or options.bind_token == "" then helper.channel_account_offline(accountInfo.id); return { code = 500, message = "未登录", data = {} } end
    local bindTokeInfo = json.decode(options.bind_token)
    local serverAddress = helper.channel_gateway_addr(options.gateway)
    if serverAddress == "" then return { code = 500, message = "暂未配置支付网关", data = {} } end
    local response, error_message = http.request("POST", string.format('%s/Alipay_Frame/IsLoginStatus', serverAddress), { query = string.format("uid=%s", bindTokeInfo.uid), timeout = "30s" })
    if error_message ~= nil then helper.channel_account_offline(accountInfo.id); return { code = 500, message = string.format('请求错误: %s', error_message), data = {} } end
    local returnInfo = toTable(response and response.body)
    if returnInfo.code == nil then helper.channel_account_offline(accountInfo.id); return { code = 500, message = string.format('请求响应错误,响应内容: %s', response and response.body or ""), data = {} } end
    if returnInfo.code ~= "1" then helper.channel_account_offline(accountInfo.id); if returnInfo.code == "0" then return { code = 201, message = "请扫描二维码登录", data = {} } end; return { code = 500, message = returnInfo.code == "-1" and "uid参数错误" or (returnInfo.code == "-2" and "没有找到Uid" or string.format('返回错误状态吗: %s', response and response.body or "")), data = {} } end
    if accountInfo.online ~= 1 then helper.channel_account_online(accountInfo.id) end
    return { code = 200, message = '在线', data = {} }
end

function plugin.login_qrcode(ctx)
    local params = toTable(ctx.params)
    if next(params) == nil then params = toTable(ctx.plugin_option) end
    if next(params) == nil then params = toTable(ctx.plugin_options) end
    local userInfo = ctx.user_info or {}
    local accountInfo = ctx.account_info or {}
    local options = mergeOptions(ctx)
    local serverAddress = helper.channel_gateway_addr(options.gateway)
    if serverAddress == "" then return { code = 500, message = "暂未配置支付网关", data = {} } end
    local cloudToken = helper.get_plugin_option(PAY_YUN_ALIPAY_LZ, "yun_token", "jiaowoliangzai")
    local configuredSite = params.domain_url or ''
    local deviceSite = (ctx.device and ctx.device.base_url) or ''
    local site = configuredSite:lower():match('^https://') and configuredSite
        or (deviceSite:lower():match('^https://') and deviceSite)
        or (configuredSite ~= '' and configuredSite)
        or deviceSite
    site = site:gsub('/+$', '')
    local req = { data = helper.base64_encode(json.encode({ site = site, pid = tonumber(userInfo.id) or 0, key = userInfo.app_secret or '', token = cloudToken, proxy = getProxy(options) })) }
    local response, error_message = http.request("POST", string.format('%s/Alipay_Frame/CreateID', serverAddress), { query = funcs.table_http_query(req), timeout = "30s" })
    if error_message ~= nil then return { code = 500, message = string.format('请求错误: %s', error_message), data = {} } end
    local returnInfo = toTable(response and response.body)
    if returnInfo.code == nil then return { code = 500, message = string.format('请求响应错误,响应内容: %s', response and response.body or ""), data = {} } end
    if returnInfo.code ~= "1" then return { code = 500, message = string.format('返回错误状态码 响应内容: %s', response and response.body or ""), data = {} } end
    local uid = returnInfo.uid
    helper.channel_account_set_option(accountInfo.id, "bind_token", json.encode({ uid = uid }))
    response, error_message = http.request("POST", string.format('%s/Alipay_Frame/QRCode', serverAddress), { query = string.format("uid=%s", uid), timeout = "30s" })
    if error_message ~= nil then return { code = 500, message = string.format('请求获取登录二维码错误: %s', error_message), data = {} } end
    returnInfo = toTable(response and response.body)
    if returnInfo.code ~= "1" then return { code = 500, message = string.format('返回错误状态吗: %s', response and response.body or ""), data = {} } end
    return { code = 200, message = "success", data = { qrcode = returnInfo.url, options = json.encode({ uid = uid }) } }
end

function plugin.login_qrcode_check(ctx)
    local params = toTable(ctx.params)
    if next(params) == nil then params = toTable(ctx.plugin_option) end
    if next(params) == nil then params = toTable(ctx.plugin_options) end
    local accountInfo = ctx.account_info or {}
    local options = mergeOptions(ctx)
    local uid = params.uid
    if uid == nil or uid == "" then
        local bindTokenInfo = toTable(options.bind_token)
        uid = bindTokenInfo.uid
    end
    if uid == nil or uid == "" then
        return { code = 201, message = "请扫描二维码登录", data = {} }
    end
    local serverAddress = helper.channel_gateway_addr(options.gateway)
    if serverAddress == "" then return { code = 500, message = "暂未配置支付网关", data = {} } end
    local api = options.type == "pid" and 'Alipay_Frame/IsLoginStatus_V2' or 'Alipay_Frame/IsLoginStatus'
    local response, error_message = http.request("POST", string.format('%s/%s', serverAddress, api), { query = string.format("uid=%s", uid), timeout = "30s" })
    if error_message ~= nil then return { code = 500, message = string.format('请求错误: %s', error_message), data = {} } end
    local returnInfo = toTable(response and response.body)
    if returnInfo.code == nil then return { code = 500, message = string.format('请求响应错误,响应内容: %s', response and response.body or ""), data = {} } end
    if returnInfo.code ~= "1" then if returnInfo.code == "0" then return { code = 201, message = "请扫描二维码登录", data = {} } end; return { code = 500, message = returnInfo.code == "-1" and "uid参数错误" or (returnInfo.code == "-2" and "没有找到Uid" or string.format('返回错误状态吗: %s', response and response.body or "")), data = {} } end
    helper.channel_account_set_option(accountInfo.id, "bind_token", json.encode({ uid = uid }))
    if options.type == "pid" and returnInfo.pid then helper.channel_account_set_option(accountInfo.id, "pid", returnInfo.pid) end
    return { code = 200, message = '登录成功', data = {} }
end

function plugin.render(ctx)
    local orderInfo = ctx.order_info
    local oldPayData = ctx.old_pay_data or ctx.pay_data or {}
    local options = mergeOptions(ctx)
    if oldPayData["type"] == "render" then
        local ret
        if options['qrcode_mod'] == '9' then
            ret = { type = "qrcode", qrcode = "https://render.alipay.com/p/s/i?scheme=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000116%26actionType%3DtoAccount%26goBack%3DNO%26amount%3D" .. helper.amount_int2str(orderInfo.trade_amount) .. "%26userId%3D" .. options['pid'] .. "%26memo%3D" .. orderInfo.order_id, url = "", content = "", out_trade_no = '' }
        elseif options['qrcode_mod'] == '10' then
            ret = { type = "qrcode", qrcode_use_short_url = 1, qrcode = "alipayqr://platformapi/startapp?saId=20000032&url=alipays%3A%2F%2Fplatformapi%2Fstartapp%3FappId%3D20000123%26actionType%3Dscan%26biz_data%3D%257B%2522s%2522%253A%2522money%2522%252C%2522u%2522%253A%2522" .. options['pid'] .. "%2522%252C%2522a%2522%253A%2522" .. helper.amount_int2str(orderInfo.trade_amount) .. "%2522%252C%2522m%2522%253A%2522" .. orderInfo.order_id .. "%2522%257D", url = "", content = "", out_trade_no = '' }
        else
            ret = oldPayData
        end
        return { code = 200, message = "success", data = { action = "render", data = ret } }
    end
    return { code = 200, message = "success", data = { action = "render", data = oldPayData } }
end

return plugin
