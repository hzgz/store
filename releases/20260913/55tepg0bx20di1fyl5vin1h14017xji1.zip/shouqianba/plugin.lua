---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

-- 渠道 收钱吧
-- @class plugin
local plugin = {}

PAY_CHANNEL_CODE_SHOUQIANBA = "shouqianba"

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["alipay"] = { {
                label = '收钱吧-支付宝',
                value = PAY_CHANNEL_CODE_SHOUQIANBA,
                options = {}
            } },
            ["wxpay"] = { {
                label = '收钱吧-微信',
                value = PAY_CHANNEL_CODE_SHOUQIANBA,
                options = {}
            } }
        },
        options = {
            -- 启动定时查询在线状态
            detection_interval = 6,
            detection_type = "cron"
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = { {
            name = 'username',
            label = '用户名',
            type = types.InputTypes.INPUT,
            default = "",
            placeholder = "请输入用户名",
            rules = { {
                required = true,
                trigger = { "input", "blur" },
                message = "请输入用户名"
            } }
        }, {
            name = 'password',
            label = '密码',
            type = types.InputTypes.PASSWORD,
            default = "",
            placeholder = "请输入密码",
            rules = { {
                required = true,
                trigger = { "input", "blur" },
                message = "请输入密码"
            } }
        }, {
            name = 'token',
            label = 'Token',
            type = types.InputTypes.INPUT,
            hidden = 1,
            default = ""
        } }
    }
end

-- 保存token
---@param token string
---@param vAccountInfo table
local function saveToken(token, vAccountInfo)
    local options = json.decode(vAccountInfo.options)
    options.token = token
    helper.channel_account_update_options(vAccountInfo.id, json.encode(options))
end

-- 获取token
---@param vAccountInfo table
---@return string
local function getToken(vAccountInfo)
    local options = json.decode(vAccountInfo.options)
    return options.token or ""
end

-- 登录
---@param username string
---@param password string
---@param vAccountInfo table
---@return string|nil, string|nil
local function login(username, password, vAccountInfo)
    local payhost = 'https://web-platforms-msp.shouqianba.com'
    local loginPath = '/api/login/ucUser/login'

    local userInfo = {
        username = username,
        password = helper.md5(password),
        uc_device = {
            device_type = 2,
            default_device = 0,
            platform = "商户服务平台",
            device_fingerprint = "12340d18-e414-49cf-815a-66ab8ec1a480",
            device_name = "收钱吧商户平台",
            device_model = "Windows",
            device_brand = "Chrome"
        }
    }

    local headers = {
        ["Content-Type"] = "application/json;charset=UTF-8",
        ["Host"] = "web-platforms-msp.shouqianba.com",
        ["Origin"] = "https://s.shouqianba.com",
        ["Referer"] = "https://s.shouqianba.com/login"
    }

    local resp, err = http.request("POST", payhost .. loginPath, {
        headers = headers,
        body = json.encode(userInfo)
    })

    if err then
        return nil, err
    end

    local result = json.decode(resp.body)
    if result.code == 50000 and result.data.code == 50000 then
        return result.data.mchUserTokenInfo.token, nil
    end

    return nil, result.msg or "登录失败"
end

-- 刷新token
---@param token string
---@param vAccountInfo table
---@return string|nil, string|nil
local function refreshToken(token, vAccountInfo)
    local payhost = 'https://web-platforms-msp.shouqianba.com'
    local refreshPath = '/api/login/ucUser/refreshToken'

    local headers = {
        ["Authorization"] = "Bearer " .. token
    }

    local resp, err = http.request("GET", payhost .. refreshPath .. "?token=" .. token, {
        headers = headers
    })

    if err then
        return nil, err
    end

    local result = json.decode(resp.body)
    if result.data.status ~= 0 then
        return result.data.token, nil
    end

    return nil, "刷新token失败"
end

-- 查询订单
---@param vAccountInfo table
---@param query table
---@return table|nil, string|nil
local function queryOrder(vAccountInfo, query)
    local options = json.decode(vAccountInfo.options)
    local token = options.token
    if token == "" then
        local newToken, err = login(options.username, options.password, vAccountInfo)
        if not newToken then
            return nil, err
        end
        token = newToken
        saveToken(token, vAccountInfo)
    end

    local payhost = 'https://web-platforms-msp.shouqianba.com'
    local queryPath = '/api/transaction/findTransactions'

    -- 构建查询参数
    local now = os.time()
    query.date_start = (now - 175) * 1000
    query.date_end = now * 1000 + 999

    local headers = {
        ["Content-Type"] = "application/json;charset=UTF-8"
    }

    local resp, err = http.request("POST", payhost .. queryPath .. "?client_version=7.0.0&token=" .. token, {
        headers = headers,
        body = json.encode(query)
    })

    if err then
        return nil, err
    end

    local result = json.decode(resp.body)
    if result.code == 50000 then
        return result.data.records, nil
    end

    -- 尝试刷新token后重试
    local newToken, err = refreshToken(token, vAccountInfo)
    if not newToken then
        return nil, err
    end
    saveToken(newToken, vAccountInfo)

    token = newToken
    resp, err = http.request("POST", payhost .. queryPath .. "?client_version=7.0.0&token=" .. token, {
        headers = headers,
        body = json.encode(query)
    })

    if err then
        return nil, err
    end

    result = json.decode(resp.body)
    if result.code == 50000 then
        return result.data.records, nil
    end

    return nil, "查询订单失败"
end

-- 通道新增或修改
---@param pAccountInfo string
---@return string
function plugin.accountChanged(pAccountInfo)
    local vAccountInfo = json.decode(pAccountInfo)
    local options = json.decode(vAccountInfo.options)

    -- 判断是否有用户名和密码
    if options.username == "" or options.password == "" then
        helper.channel_account_offline(vAccountInfo.id)
        return json.encode({
            err_code = 200,
            err_message = "暂未填写账号密码跳过"
        })
    end

    -- 尝试登录
    local token, err = login(options.username, options.password, vAccountInfo)
    if not token then
        helper.channel_account_offline(vAccountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = err
        })
    end

    -- 保存token
    saveToken(token, vAccountInfo)

    -- 登录成功，设置在线
    helper.channel_account_online(vAccountInfo.id)
    return json.encode({
        err_code = 200,
        err_message = "登录成功"
    })
end

-- 定时任务
---@param ctx types.CronAccountParams
---@return string
function plugin.cron(ctx)
    local vAccountInfo = ctx.account_info
    local vParams = ctx.account_options

    if not vParams.username or not vParams.password then
        if vAccountInfo.online == 1 then
            helper.channel_account_offline(vAccountInfo.id)
        end
        return json.encode({
            err_code = 500,
            err_message = "暂未填写账号密码跳过"
        })
    end

    -- 获取token并检查是否需要刷新
    local token = vParams.token
    if token ~= "" then
        -- 尝试刷新token
        local newToken, err = refreshToken(token, vAccountInfo)
        if not newToken then
            -- 刷新失败，尝试重新登录
            newToken, err = login(vParams.username, vParams.password, vAccountInfo)
            if not newToken then
                helper.channel_account_offline(vAccountInfo.id)
                return json.encode({
                    err_code = 500,
                    err_message = err
                })
            end
            -- 保存新token
            saveToken(newToken, vAccountInfo)
        else
            -- 刷新成功，保存新token
            saveToken(newToken, vAccountInfo)
        end
    else
        -- 没有token，尝试登录
        local newToken, err = login(vParams.username, vParams.password, vAccountInfo)
        if not newToken then
            helper.channel_account_offline(vAccountInfo.id)
            return json.encode({
                err_code = 500,
                err_message = err
            })
        end
        -- 保存新token
        saveToken(newToken, vAccountInfo)
    end

    -- 查询最近订单
    local orders, err = queryOrder(vAccountInfo, {})
    if err then
        helper.channel_account_offline(vAccountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = err
        })
    end

    -- 设置在线
    if vAccountInfo.online ~= 1 then
        helper.channel_account_online(vAccountInfo.id)
    end

    -- 处理订单
    local payways = {
        [2] = "alipay",
        [3] = "wxpay"
    }
    for _, order in ipairs(orders) do
        -- 判断第三方订单是否存在
        local exist = orderPayHelper.third_order_exist({
            pay_type = payways[order.payway],
            channel_code = PAY_CHANNEL_CODE_SHOUQIANBA,
            uid = vAccountInfo.uid,
            account_id = vAccountInfo.id,
            third_account = order.terminal_device_fingerprint,
            third_order_id = order.order_sn
        })

        if not exist then
            -- 录入订单
            local insertId = orderPayHelper.third_order_insert({
                pay_type = payways[order.payway],
                channel_code = PAY_CHANNEL_CODE_SHOUQIANBA,
                uid = vAccountInfo.uid,
                account_id = vAccountInfo.id,
                buyer_id = "",
                buyer_name = "",
                third_order_id = order.order_sn,
                third_account = order.terminal_device_fingerprint,
                amount = order.original_amount / 100,
                remark = "",
                trans_time = os.time(),
                type = tostring(order.payway),
                out_order_id = ""
            })

            if insertId > 0 then
                local err_code, err_message = orderPayHelper.third_order_report(insertId)
                if err_code == 200 then
                    log.info("订单上报成功:" .. err_message, order.order_sn, order.original_amount / 100)
                else
                    log.info("订单上报失败:" .. err_message, order.order_sn, order.original_amount / 100)
                end
            end
        end
    end

    return json.encode({
        err_code = 200,
        err_message = "在线"
    })
end

return plugin
