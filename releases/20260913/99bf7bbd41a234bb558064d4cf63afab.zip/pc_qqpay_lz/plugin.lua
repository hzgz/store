---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 PC自挂-QQ-靓仔监控端
local PAY_PC_QQPAY_LZ = "pc_qqpay_lz"

-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["qqpay"] = { {
                label = 'PC自挂-QQ-靓仔监控端',
                value = PAY_PC_QQPAY_LZ,
                report = 1,
                parse_msg = 1,
                options = {
                    use_add_amount = 1
                }
            } }
        },
        options = {
            callback = 0,
            detection_interval = 0,
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'qrcode',
                label = '收款码地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.type == 'url'",
                options = {
                    append_deqrocde = 1,
                    tip = ''
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = 'qrcode_file',
                label = '收款码图片',
                type = types.InputTypes.IMAGE,
                default = "",
                options = {
                    tip = ''
                },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.type == 'image'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = 'type',
                label = '收款码类型',
                type = types.InputTypes.SELECT,
                default = "url",
                options = {
                    tip = '...'
                },
                placeholder = "请选择收款码类型",
                values = {
                    {
                        label = "地址",
                        value = "url"
                    },
                    {
                        label = "图片",
                        value = "image"
                    }
                },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local options = ctx.account_options

    if options['type'] == 'image' then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = options['qrcode_file'],
                url = "",
                content = "",
                out_trade_no = ''
            }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = " " .. (options['qrcode'] or "") .. " ",
            url = "",
            content = "",
            out_trade_no = ''
        }
    }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = {
            response = ""
        }
    }
end

return plugin
