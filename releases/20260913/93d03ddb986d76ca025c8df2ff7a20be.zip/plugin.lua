---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 QQ云端-靓仔
local PAY_YUN_QQPAY_LZ = "yun_qqpay_lz"

-- @class plugin
local plugin = {}

local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

local function mergeOptions(ctx)
    ctx = ctx or {}
    local accountInfo = ctx.account_info or {}
    local options = {}
    for k, v in pairs(toTable(accountInfo.options)) do
        options[k] = v
    end
    for k, v in pairs(toTable(ctx.plugin_option)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.plugin_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.account_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    return options
end

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["qqpay"] = { {
                label = 'QQ云端-靓仔',
                value = PAY_YUN_QQPAY_LZ,
                options = {
                    use_add_amount = 1,
                    use_qrcode_login = 1
                }
            } }
        },
        options = {
            detection_interval = 30,
            detection_type = "cron",
            config = { {
                title = "请输入云端的token密匙",
                key = "yun_token",
                default = "jiaowoliangzai"
            } }
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            { name = 'gateway', label = '选择网关', type = types.InputTypes.SELECT, default = "", placeholder = "请选择网关", options = { chose_gateway = 1, tip = '' }, rules = { { required = true, trigger = { "input", "blur" }, message = "请选择" } } },
            { name = 'qrcode', label = '收款码地址', type = types.InputTypes.INPUT, default = "", placeholder = "请输入收款码地址", when = "this.formModel.options.type == 'qrcode'", options = { append_deqrocde = 1, tip = '' }, rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
            { name = 'qrcode_file', label = '收款码图片', type = types.InputTypes.IMAGE, default = "", placeholder = "请上传收款码图片", when = "this.formModel.options.type == 'image'", options = { tip = '' }, rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } } },
            { name = 'type', label = '收款码类型', type = types.InputTypes.SELECT, default = "qrcode", options = { tip = '支持/个人码/经营码/赞赏码/商家码/QQ店员/拉卡拉/易生' }, placeholder = "请选择收款码类型", values = { { label = "二维码", value = "qrcode" }, { label = "二维码图片", value = "image" } }, rules = { { required = true, trigger = { "input", "blur" }, message = "请选择类型" } } },
            { name = 'bind_token', label = '绑定的用户信息', type = types.InputTypes.INPUT, hidden = 1 }
        }
    }
end

function plugin.create(ctx)
    local options = ctx.account_options
    if options['type'] == 'image' then
        return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode_file = options['qrcode_file'], url = "", content = "", out_trade_no = '' } }
    end
    return { code = 200, message = "success", data = { type = types.PaymentResultTypes.QRCODE, qrcode = options['qrcode'], url = "", content = "", out_trade_no = '' } }
end

function plugin.cron(ctx)
    local vAccountInfo = ctx.account_info
    local vParams = ctx.account_options or ctx.plugin_options or ctx.plugin_option or {}
    if vParams.bind_token == nil or vParams.bind_token == "" then
        return { code = 500, message = "未登录", data = {} }
    end
    local bindTokeInfo = json.decode(vParams.bind_token)
    local serverAddress = helper.channel_gateway_addr(vParams.gateway)
    if serverAddress == "" then
        return { code = 500, message = "暂未配置支付网关", data = {} }
    end
    local response, error_message = http.request("POST", string.format('%s/QQ_Pc/IsLoginStatus', serverAddress), { query = string.format("uid=%s", bindTokeInfo.uid), timeout = "30s" })
    if error_message ~= nil then
        helper.channel_account_offline(vAccountInfo.id)
        return { code = 500, message = string.format('请求错误: %s', error_message), data = {} }
    end
    local returnInfo = toTable(response and response.body)
    if returnInfo.code == nil then
        helper.channel_account_offline(vAccountInfo.id)
        return { code = 500, message = string.format('请求响应错误,响应内容: %s', response and response.body or ""), data = {} }
    end
    if returnInfo.code ~= "1" then
        helper.channel_account_offline(vAccountInfo.id)
        helper.channel_account_set_option(vAccountInfo.id, "bind_token", "")
        if returnInfo.code == "0" then return { code = 201, message = "请扫描二维码登录", data = {} } end
        if returnInfo.code == "-1" then return { code = 500, message = "uid参数错误", data = {} } end
        if returnInfo.code == "-2" then return { code = 500, message = "没有找到Uid", data = {} } end
        return { code = 500, message = string.format('返回错误状态吗: %s', response and response.body or ""), data = {} }
    end
    if vAccountInfo.online ~= 1 then helper.channel_account_online(vAccountInfo.id) end
    return { code = 200, message = '在线', data = {} }
end

function plugin.login_qrcode(ctx)
    local vParams = toTable(ctx.params)
    if next(vParams) == nil then vParams = toTable(ctx.plugin_option) end
    if next(vParams) == nil then vParams = toTable(ctx.plugin_options) end
    local vUserInfo = ctx.user_info or {}
    local vAccountInfo = ctx.account_info or {}
    local vAccountOption = mergeOptions(ctx)
    local cloudToken = helper.get_plugin_option(PAY_YUN_QQPAY_LZ, "yun_token", "jiaowoliangzai")
    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then return { code = 500, message = "暂未配置支付网关", data = {} } end
    local apiUri = string.format('%s/QQ_Pc/CreateID', serverAddress)
    local configuredSite = vParams.domain_url or ''
    local deviceSite = (ctx.device and ctx.device.base_url) or ''
    local site = configuredSite:lower():match('^https://') and configuredSite
        or (deviceSite:lower():match('^https://') and deviceSite)
        or (configuredSite ~= '' and configuredSite)
        or deviceSite
    site = site:gsub('/+$', '')
    local req = { data = helper.base64_encode(json.encode({ site = site, pid = tonumber(vUserInfo.id) or 0, key = vUserInfo.app_secret or '', token = cloudToken })) }
    local response, error_message = http.request("POST", apiUri, { query = funcs.table_http_query(req), timeout = "30s" })
    if error_message ~= nil then return { code = 500, message = string.format('请求错误: %s', error_message), data = {} } end
    local returnInfo = toTable(response and response.body)
    if returnInfo.code == nil then return { code = 500, message = string.format('请求响应错误,响应内容: %s', response and response.body or ""), data = {} } end
    if returnInfo.code ~= "1" then return { code = 500, message = string.format('返回错误状态码 响应内容: %s', response and response.body or ""), data = {} } end
    helper.channel_account_set_option(vAccountInfo.id, "uid", returnInfo.uid)
    local uid = returnInfo.uid
    helper.channel_account_set_option(vAccountInfo.id, "bind_token", json.encode({ uid = uid }))
    response, error_message = http.request("POST", string.format('%s/QQ_Pc/QRCode', serverAddress), { query = string.format("uid=%s", uid), timeout = "30s" })
    if error_message ~= nil then return { code = 500, message = string.format('请求获取登录二维码错误: %s', error_message), data = {} } end
    returnInfo = toTable(response and response.body)
    if returnInfo.code ~= "1" then return { code = 500, message = string.format('返回错误状态吗: %s', response and response.body or ""), data = {} } end
    return { code = 200, message = "success", data = { qrcode = returnInfo.url, options = json.encode({ uid = uid }) } }
end

function plugin.login_qrcode_check(ctx)
    local vParams = toTable(ctx.params)
    if next(vParams) == nil then vParams = toTable(ctx.plugin_option) end
    if next(vParams) == nil then vParams = toTable(ctx.plugin_options) end
    local vAccountInfo = ctx.account_info or {}
    local vAccountOption = mergeOptions(ctx)
    local uid = vParams.uid
    if uid == nil or uid == "" then
        local bindTokenInfo = toTable(vAccountOption.bind_token)
        uid = bindTokenInfo.uid
    end
    if uid == nil or uid == "" then
        return { code = 201, message = "请扫描二维码登录", data = {} }
    end
    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then return { code = 500, message = "暂未配置支付网关", data = {} } end
    local response, error_message = http.request("POST", string.format('%s/QQ_Pc/IsLoginStatus', serverAddress), { query = string.format("uid=%s", uid), timeout = "30s" })
    if error_message ~= nil then return { code = 500, message = string.format('请求错误: %s', error_message), data = {} } end
    local returnInfo = toTable(response and response.body)
    if returnInfo.code == nil then return { code = 500, message = string.format('请求响应错误,响应内容: %s', response and response.body or ""), data = {} } end
    if returnInfo.code ~= "1" then
        if returnInfo.code == "0" then return { code = 201, message = "请扫描二维码登录", data = {} } end
        if returnInfo.code == "-1" then return { code = 500, message = "uid参数错误", data = {} } end
        if returnInfo.code == "-2" then return { code = 500, message = "没有找到Uid", data = {} } end
        return { code = 500, message = string.format('返回错误状态吗: %s', response and response.body or ""), data = {} }
    end
    helper.channel_account_set_option(vAccountInfo.id, "bind_token", json.encode({ uid = uid }))
    return { code = 200, message = '登录成功', data = {} }
end

return plugin
