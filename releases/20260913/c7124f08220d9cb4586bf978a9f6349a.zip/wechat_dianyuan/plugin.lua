---@diagnostic disable: undefined-global
-- 微信店员-监控-XD
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

-- 定义常量
local PAY_WXPAY_DIANYUAN_THIRD = "wxpay_dianyuan_third"

-- @class plugin
local plugin = {}

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    local info = {
        -- 支持支付类型
        channels = {
            wxpay = {
                {
                    label = "微信店员-监控-XD",
                    value = PAY_WXPAY_DIANYUAN_THIRD,
                    report = 1,
                    options = {
                        use_sub_account = 1,
                        sub_account_label = "店长微信昵称",
                        sub_account_placeholder = "请勿过使用于复杂的名字 如:火星文,Emoji等特殊符号",
                        use_add_amount = 1,
                    },
                },
            },
        },
    }
    return info
end

--- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    if ctx.pay_channel == PAY_WXPAY_DIANYUAN_THIRD then
        return {
            inputs = {
                {
                    name = 'qrcode',
                    label = '收款码地址',
                    type = types.InputTypes.INPUT,
                    default = "",
                    options = {
                        tip = '',
                        append_deqrocde = 1, -- 增加解析二维码功能
                    },
                    placeholder = "请输入收款码地址",
                    when = "this.formModel.options.type == 'qrcode'",
                    rules = {
                        {
                            required = true,
                            trigger = { "input", "blur" },
                            message = "请输入",
                        }
                    }
                },
                {
                    name = 'qrcode_file',
                    label = '收款码图片',
                    type = types.InputTypes.IMAGE,
                    default = "",
                    options = {
                        tip = '',
                    },
                    placeholder = "请上传收款码图片",
                    when = "this.formModel.options.type == 'image'",
                    rules = {
                        {
                            required = true,
                            trigger = { "input", "blur" },
                            message = "请输入",
                        }
                    }
                },
                {
                    name = 'type',
                    label = '收款码类型',
                    type = types.InputTypes.SELECT,
                    default = "qrcode",
                    options = {
                        tip = '',
                    },
                    placeholder = "请选择收款码类型",
                    values = {
                        {
                            label = "二维码",
                            value = "qrcode"
                        },
                        {
                            label = "图片",
                            value = "image"
                        },
                    },
                    rules = {
                        {
                            required = true,
                            trigger = { "input", "blur" },
                            message = "请输入",
                        }
                    }
                },
            },
        }
    end

    return {}
end

--- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vAccountOptions = ctx.account_options

    if vAccountOptions['type'] == 'image' then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = vAccountOptions['qrcode_file'],
                qrcode = "",
                url = "",
                content = "",
                out_trade_no = '',
            }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = vAccountOptions['qrcode'],
            url = "",
            content = "",
            out_trade_no = '',
        }
    }
end

--- 支付回调
---@param ctx types.OrderNotifyParams
---@return types.OrderNotifyResp
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = { response = "" },
    }
end

return plugin
