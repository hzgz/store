---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 易支付
-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["alipay"] = { {
                label = '易支付',
                value = 'alipay_epay'
            } },
            ["wxpay"] = { {
                label = '易支付',
                value = 'wxpay_epay'
            } },
            ["qqpay"] = { {
                label = '易支付',
                value = 'qqpay_epay'
            } },
            ["bank"] = { {
                label = '易支付',
                value = 'bank_epay'
            } }
        },
        options = {
            callback = 1,
            detection_interval = 0,
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'host',
                label = '通讯地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入通讯地址",
                options = {
                    tip = '如: https://xxx.com/xpay/epay'
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'pid',
                label = '商户ID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入商户ID",
                options = {
                    tip = '如: 10000'
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'key',
                label = '通讯密钥',
                type = types.InputTypes.PASSWORD,
                default = "",
                placeholder = "请输入通讯密钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'method',
                label = '请求方式',
                type = types.InputTypes.SELECT,
                default = "POST",
                options = {
                    tip = ''
                },
                placeholder = "请选择请求方式",
                values = {
                    {
                        label = "GET",
                        value = "GET"
                    },
                    {
                        label = "POST",
                        value = "POST"
                    }
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'type',
                label = '接口类型',
                type = types.InputTypes.SELECT,
                default = "mapi",
                options = {
                    tip = ''
                },
                placeholder = "请选择接口类型",
                values = {
                    {
                        label = "mapi.php",
                        value = "mapi"
                    },
                    {
                        label = "submit.php",
                        value = "submit"
                    }
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local host = vAccountOptions['host']
    local pid = vAccountOptions['pid']
    local key = vAccountOptions['key']
    local method = vAccountOptions['method']
    local submitType = vAccountOptions['type']

    local req = {
        pid = pid,
        type = vOrderInfo['pay_type'],
        notify_url = vOrderInfo['notify_url'],
        return_url = vOrderInfo['return_url'],
        out_trade_no = vOrderInfo['order_id'],
        name = vOrderInfo['subject'],
        money = vOrderInfo['trade_amount'] / 100,
        clientip = vOrderInfo['client_ip'],
        device = vOrderInfo['device']
    }

    local res = ""
    local error_message
    local response = {}

    req["sign"] = plugin._getSign(req, key)

    if submitType == 'mapi' then
        local uri = host .. "/mapi.php"

        print("[插件] 请求内容" .. funcs.table_http_query(req))

        if method == "POST" then
            local params = {
                query = "",
                body = funcs.table_http_query(req),
                form = "",
                timeout = "30s",
                headers = {
                    ["content-type"] = "application/x-www-form-urlencoded"
                }
            }

            response, error_message = http.request("POST", uri, params)
            if response and response.body then
                res = response.body
            end
        else
            response, error_message = http.request(method, uri, {
                query = funcs.table_http_query(req),
                timeout = "30s",
                headers = {}
            })
            if response and response.body then
                res = response.body
            end
        end

        print("[插件] 返回内容" .. res)
        local returnInfo = json.decode(res)

        if returnInfo == nil then
            return {
                code = 500,
                message = '请求响应错误 返回内容:' .. res,
                data = {
                    type = types.PaymentResultTypes.QRCODE
                }
            }
        end

        if returnInfo['code'] ~= 1 then
            return {
                code = 500,
                message = returnInfo['msg'] or returnInfo['message'],
                data = {
                    type = types.PaymentResultTypes.QRCODE
                }
            }
        end

        if returnInfo['payurl'] then
            return {
                code = 200,
                message = "success",
                data = {
                    type = types.PaymentResultTypes.JUMP,
                    qrcode = '',
                    url = returnInfo["payurl"],
                    content = "",
                    out_trade_no = returnInfo['trade_no']
                }
            }
        end

        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode = returnInfo['qrcode'],
                url = returnInfo["payurl"],
                content = "",
                out_trade_no = returnInfo['trade_no']
            }
        }
    else
        local uri = host .. "/submit.php"

        if method == "POST" then
            req = plugin._pagePay(req, uri, "正在跳转中,未跳转点击我")

            return {
                code = 200,
                message = "success",
                data = {
                    type = types.PaymentResultTypes.HTML,
                    qrcode = "",
                    url = "",
                    content = req
                }
            }
        end

        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.JUMP,
                qrcode = "",
                url = uri .. "?" .. funcs.table_http_query(req),
                content = ""
            }
        }
    end

    return {
        code = 500,
        message = "创建支付失败",
        data = {}
    }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    local vRequest = ctx.request
    local vParams = ctx.params
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local reqData = ""
    if vRequest['method'] == 'POST' then
        reqData = (vRequest['body'])
    else
        reqData = (vRequest['query'])
    end

    local sign = plugin._getSign(reqData, vAccountOptions['key'])
    if sign == reqData['sign'] then
        if reqData['pid'] ~= vAccountOptions['pid'] then
            return {
                code = 500,
                message = "交易商户号异常",
                data = { response = "" }
            }
        end

        if reqData['trade_status'] ~= "TRADE_SUCCESS" and reqData['trade_status'] ~= "SUCCESS" then
            return {
                code = 500,
                message = "交易未完成",
                data = { response = "" }
            }
        end

        local out_trade_no = reqData['out_trade_no']
        local trade_no = reqData['trade_no']
        local money = math.floor((reqData['money'] + 0.000005) * 100)

        local err_code, err_message, response = orderHelper.notify_process(json.encode({
            out_trade_no = trade_no,
            trade_no = out_trade_no,
            amount = money
        }), json.encode(vParams), json.encode(vAccountOptions))

        return {
            code = err_code,
            message = err_message,
            data = { response = response }
        }
    else
        return {
            code = 500,
            message = "签名校验失败",
            data = { response = "" }
        }
    end
end

-- 发起支付（页面跳转）
---@param param table
---@param submit_url string
---@param button string
---@return string
function plugin._pagePay(param, submit_url, button)
    local html = '<form id="dopay" action="' .. submit_url .. '" method="post">'

    for k, v in pairs(param) do
        html = html .. '<input type="hidden" name="' .. k .. '" value="' .. v .. '"/>'
    end

    html = html .. '<input type="submit" value="' .. button .. '"></form><script>document.getElementById("dopay").submit();</script>'

    return html
end

-- 签名
---@param param table
---@param key string
---@return string
function plugin._getSign(param, key)
    local signstr = ''
    local keys = {}

    for k, _ in pairs(param) do
        table.insert(keys, k)
    end
    table.sort(keys)

    for _, k in ipairs(keys) do
        local v = param[k]
        if k ~= "sign" and k ~= "sign_type" and v ~= '' then
            signstr = signstr .. k .. '=' .. v .. '&'
        end
    end

    signstr = string.sub(signstr, 1, -2)
    signstr = signstr .. key
    local sign = helper.md5(signstr)
    return sign
end

return plugin

