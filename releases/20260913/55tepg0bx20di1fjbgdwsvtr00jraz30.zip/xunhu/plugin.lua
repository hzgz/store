---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 讯虎-虎皮椒
-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["bank"] = { {
                label = '虎皮椒',
                value = 'bank_xunhu_hupijiao',
                bind_pay_type = { "alipay", "wxpay", "bank" }
            } }
        },
        options = {
            callback = 1,
            detection_interval = 0,
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'gateway',
                label = '网关',
                type = types.InputTypes.INPUT,
                default = "https://api.xunhupay.com/",
                placeholder = "请输入网关地址",
                options = {
                    tip = '如: https://api.xunhupay.com/'
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'app_id',
                label = 'AppID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入AppID",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'secret',
                label = '密钥',
                type = types.InputTypes.PASSWORD,
                default = "",
                placeholder = "请输入密钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local gateway = vAccountOptions['gateway']
    local appId = vAccountOptions['app_id']
    local appSecret = vAccountOptions['secret']

    -- 组装提交请求
    local req = {
        version = "1.1",
        trade_order_id = vOrderInfo['order_id'],
        total_fee = vOrderInfo['trade_amount'] / 100,
        title = vOrderInfo['subject'],
        appid = appId,
        notify_url = vOrderInfo['notify_url'],
        return_url = vOrderInfo['return_url'],
        nonce_str = helper.str_random(20),
        wap_name = vOrderInfo['merchant_name'],
        type = ""
    }
    
    if vOrderInfo.pay_type == "alipay" then
        req.type = ""
    elseif vOrderInfo.pay_type == "wxpay" then
        req.type = "WAP"
    end

    req.hash = plugin._getSign(req, appSecret)

    local res = ""
    local error_message
    local response = {}

    -- 创建订单接口导致
    local uri = gateway .. "payment/do.html"

    local params = {
        query = "",
        body = funcs.table_http_query(req),
        form = "",
        timeout = "30s",
        headers = {
            ["content-type"] = "application/x-www-form-urlencoded"
        }
    }

    response, error_message = http.request("POST", uri, params)
    if response and response.body then
        res = response.body
    end

    print("[插件] 请求地址" .. uri)
    print("[插件] 请求内容" .. funcs.table_http_query(req))
    print("[插件] 返回内容" .. res)
    
    local returnInfo = json.decode(res)

    if returnInfo == nil then
        return {
            code = 500,
            message = '请求响应错误 返回内容:' .. res,
            data = {
                type = types.PaymentResultTypes.QRCODE
            }
        }
    end

    if returnInfo['errcode'] ~= 0 or returnInfo['errmsg'] ~= "success!" then
        return {
            code = 500,
            message = returnInfo['errmsg'] or returnInfo['errmsg'],
            data = {
                type = types.PaymentResultTypes.QRCODE
            }
        }
    end

    if returnInfo['url'] then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.JUMP,
                qrcode = '',
                url = returnInfo["url"],
                content = "",
                out_trade_no = returnInfo['oderid']
            }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = returnInfo['url_qrcode'],
            url = returnInfo["url"],
            content = "",
            out_trade_no = returnInfo['oderid']
        }
    }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    local vRequest = ctx.request
    local vParams = ctx.params
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    -- 判断请求方式
    local reqData = ""
    if vRequest['method'] == 'POST' then
        reqData = (vRequest['body'])
    else
        reqData = (vRequest['query'])
    end

    -- 获取签名内容
    local sign = plugin._getSign(reqData, vAccountOptions['secret'])
    if sign == reqData['hash'] then
        -- 签名校验成功
        if reqData['appid'] ~= vAccountOptions['app_id'] then
            return {
                code = 500,
                message = "交易商户号异常",
                data = { response = "" }
            }
        end
        
        -- 商户订单号
        local out_trade_no = reqData['trade_order_id']
        -- 外部系统订单号
        local trade_no = reqData['transaction_id']
        -- 避免精度有问题
        local money = math.floor((reqData['total_fee'] + 0.000005) * 100)

        -- 通知订单处理完成
        local err_code, err_message, response = orderHelper.notify_process(json.encode({
            out_trade_no = trade_no,
            trade_no = out_trade_no,
            amount = money
        }), json.encode(vParams), json.encode(vAccountOptions))

        return {
            code = err_code,
            message = err_message,
            data = { response = response }
        }
    else
        return {
            code = 500,
            message = "签名校验失败",
            data = { response = "" }
        }
    end
end

-- 绑定参数
---@param params table
---@param key string
---@return table
function plugin._buildRequestParams(params, key)
    params['sign'] = plugin._getSign(params, key)
    params['sign_type'] = 'MD5'
    return params
end

-- 发起支付（页面跳转）
---@param param table
---@param submit_url string
---@param button string
---@return string
function plugin._pagePay(param, submit_url, button)
    local html = '<form id="dopay" action="' .. submit_url .. '" method="post">'

    for k, v in pairs(param) do
        html = html .. '<input type="hidden" name="' .. k .. '" value="' .. v .. '"/>'
    end

    html = html .. '<input type="submit" value="' .. button .. '"></form><script>document.getElementById("dopay").submit();</script>'

    return html
end

-- 签名
---@param param table
---@param key string
---@return string
function plugin._getSign(param, key)
    local signstr = ''
    local keys = {}

    for k, _ in pairs(param) do
        table.insert(keys, k)
    end
    table.sort(keys)

    for _, k in ipairs(keys) do
        local v = param[k]
        if k ~= "sign" and k ~= "sign_type" and v ~= '' then
            signstr = signstr .. k .. '=' .. v .. '&'
        end
    end

    signstr = string.sub(signstr, 1, -2)
    signstr = signstr .. key
    local sign = helper.md5(signstr)
    return sign
end

return plugin

