---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local funcs = funcs or require("funcs")
local http = http or require("http")
local json = json or require("json")
local helper = helper or require("helper")
local orderHelper = orderHelper or require("orderHelper")
local websocket = websocket or require("websocket")
local log = log or require("log")

local PAY_CHANNEL_CODE_YUN_WECHAT_WATCH_XD = "yun_wechat_watch_xd"
local forwardEnsureAt = {}

local GATEWAY = {
    RECEIPT_MD = "https://payapp.wechatpay.cn/receiptmdmgr",
    RECEIPT_SJT = "https://payapp.wechatpay.cn/receiptsjtmgr",
    RECEIPT_WX = "https://payapp.wechatpay.cn/receiptwxmgr",
    SMALLBOOK = "https://smallbook.wxpapp.weixin.qq.com"
}

local WXAPP = {
    RECEIPT = {
        app_id = "wx264e9b6d4d484f51",
        login_url = "https://payapp.wechatpay.cn/receiptwxmgr/account/list?miniprogram_version=3.15.9&js_code=",
        referer = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html"
    },
    SMALLBOOK = {
        app_id = "wx28be8489b7a36aaa",
        login_url = "https://smallbook.wxpapp.weixin.qq.com/qrapp/user/login?js_code=",
        referer = "https://servicewechat.com/wx28be8489b7a36aaa/1181/page-frame.html"
    }
}

local MINI_PROGRAM_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " ..
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) " ..
    "NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581"

---@param v any
---@return table
local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

---@param body string
---@return table|nil
local function decodeBody(body)
    if not body or body == "" then
        return nil
    end
    local ok, data = pcall(json.decode, body)
    if ok and type(data) == "table" then
        return data
    end
    return nil
end

---@param value any
---@return boolean
local function isBlank(value)
    return value == nil or value == ""
end

---URL 解码
---@param s string
---@return string
local function urlDecode(s)
    s = tostring(s or "")
    s = s:gsub("%+", " ")
    s = s:gsub("%%(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end)
    return s
end

---@param proxy string
---@return string
local function encodeProxyCredentials(proxy)
    proxy = tostring(proxy or "")
    local prefix, userInfo, address = proxy:match("^([%w+.-]+://)([^@]+)@(.+)$")
    if not prefix then
        return proxy
    end
    local username, password = userInfo:match("^([^:]*):(.*)$")
    if not username then
        return proxy
    end
    return prefix .. helper.url_encode(username) .. ":" .. helper.url_encode(password) .. "@" .. address
end

---解析账号代理配置：不使用/自定义/本站代理池
---@param accountOptions table
---@return string
local function getProxy(accountOptions)
    accountOptions = accountOptions or {}
    local mode = accountOptions.proxy_mode or "no_proxy"
    if mode == "custom_proxy" then
        return encodeProxyCredentials(accountOptions.proxy or "")
    end
    if mode ~= "cloud_proxy" then
        return ""
    end

    local poolId = tonumber(accountOptions.proxy_pool_id or 0) or 0
    if poolId <= 0 then
        return ""
    end
    local itemId = tonumber(accountOptions.proxy_pool_item_id or 0) or 0
    local proxyItem = helper.proxy_pool_fetch(poolId, itemId)
    if proxyItem and proxyItem.proxy_url and proxyItem.proxy_url ~= "" then
        local proxyId = tonumber(proxyItem.proxy_id or 0) or 0
        if proxyId ~= itemId then
            accountOptions.proxy_pool_item_id = proxyId
            if accountOptions.account_id then
                helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", proxyId)
            end
        end
        return encodeProxyCredentials(proxyItem.proxy_url)
    end
    if itemId > 0 then
        helper.proxy_pool_release(itemId)
    end
    accountOptions.proxy_pool_item_id = 0
    if accountOptions.account_id then
        helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", "0")
    end
    return ""
end

---把代理配置转换为云端约定的代理请求头（X-Proxy-Cluster-*）
---@param accountOptions table
---@return table|nil
local function getProxyHeaders(accountOptions)
    if not accountOptions then
        return nil
    end
    local proxy = getProxy(accountOptions)
    if proxy == "" then
        return nil
    end
    local rest = proxy
    local scheme = rest:match("^([%w+.-]+)://")
    if scheme then
        rest = rest:sub(#scheme + 4)
    end
    local userInfo, address = rest:match("^([^@/]+)@(.+)$")
    if not userInfo then
        address = rest
    end
    if not address or address == "" then
        return nil
    end
    local username, password = "", ""
    if userInfo then
        username, password = userInfo:match("^([^:]*):(.*)$")
        username = urlDecode(username or "")
        password = urlDecode(password or "")
    end
    return {
        ["X-Proxy-Cluster-URL"] = address,
        ["X-Proxy-Cluster-Type"] = scheme or "socks5",
        ["X-Proxy-Cluster-User"] = username,
        ["X-Proxy-Cluster-Pass"] = password
    }
end

---@param value any
---@return string
local function toLogString(value)
    if value == nil then
        return ""
    end
    if type(value) == "table" then
        local ok, encoded = pcall(json.encode, value)
        if ok then
            return encoded
        end
    end
    return tostring(value)
end

---@param url string
---@return string
local function toWebsocketUrl(url)
    return string.gsub(string.gsub(url, "http://", "ws://"), "https://", "wss://")
end

---@param ctx table
---@return table
local function mergeOptions(ctx)
    ctx = ctx or {}
    local options = {}
    local accountInfo = toTable(ctx.account_info)
    local sources = {
        toTable(accountInfo.options),
        toTable(ctx.plugin_option),
        toTable(ctx.plugin_options),
        toTable(ctx.account_options)
    }
    for _, source in ipairs(sources) do
        for key, value in pairs(source) do
            if value ~= nil then
                options[key] = value
            end
        end
    end
    return options
end

---@param options table
---@return string
local function getPayMode(options)
    local mode = options and options.pay_mode or ""
    if mode == "receipt" or mode == "smallbook" then
        return mode
    end
    if mode == "platform" or mode == "self" or mode == "ipad" then
        return "ipad"
    end

    -- 兼容曾使用qrcode_type字段保存的账号配置。
    local legacyType = options and options.qrcode_type or ""
    if legacyType == "receipt" or legacyType == "smallbook" then
        return legacyType
    end
    return "ipad"
end

---@param options table
---@return boolean
local function isSpecialPayMode(options)
    return getPayMode(options) ~= "ipad"
end

---@param errCode number
---@param errMessage string
---@return table
local function errorResponse(errCode, errMessage)
    return {
        code = errCode,
        message = errMessage,
        data = {}
    }
end

---@param referer string
---@return table
local function miniProgramHeaders(referer)
    return {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = MINI_PROGRAM_USER_AGENT,
        ["Content-Type"] = "application/json",
        ["Accept"] = "*/*",
        ["Referer"] = referer,
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }
end

---@param value any
---@return string|nil
local function extractAppletCode(value)
    if type(value) == "string" then
        if value == "" then
            return nil
        end
        local decoded = decodeBody(value)
        if decoded then
            return extractAppletCode(decoded)
        end
        return value
    end
    if type(value) ~= "table" then
        return nil
    end

    local code = value.code or value.Code or value.js_code or value.jsCode
    if code ~= nil and tostring(code) ~= "" then
        return tostring(code)
    end
    return extractAppletCode(value.data) or extractAppletCode(value.result)
end

---@param value any
---@return string|nil
local function extractSid(value)
    if type(value) == "string" then
        return extractSid(decodeBody(value))
    end
    if type(value) ~= "table" then
        return nil
    end
    local sid = value.sid or value.Sid or value.receipt_sid or value.receiptSid
    if sid ~= nil and tostring(sid) ~= "" then
        return tostring(sid)
    end
    return extractSid(value.data) or extractSid(value.result)
end

---@param accountType any
---@return string|nil
local function getReceiptGateway(accountType)
    accountType = tonumber(accountType) or accountType
    if accountType == 1 then
        return GATEWAY.RECEIPT_MD
    elseif accountType == 2 then
        return GATEWAY.RECEIPT_WX
    elseif accountType == 3 then
        return GATEWAY.RECEIPT_SJT
    end
    return nil
end

---@param params table
---@param requiredFields string[]
---@return boolean, string
local function validateParams(params, requiredFields)
    for _, field in ipairs(requiredFields) do
        if isBlank(params[field]) then
            return false, string.format("缺少必要参数: %s", field)
        end
    end
    return true, ""
end

-- @class types.plugin
local plugin = {}

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        channels = {
            ["wxpay"] = { {
                label = "微信-手表_闲蛋",
                value = PAY_CHANNEL_CODE_YUN_WECHAT_WATCH_XD,
                options = {
                    use_add_amount = 1,
                    use_qrcode_login = 1,
                    actions = { {
                        label = "唤醒",
                        func = "action_wake",
                        type = "confirm",
                        options = {
                            tip = "是否需要唤醒"
                        }
                    } }
                },
                info = "微信手表方式登录"
            } }
        },
        options = {
            crontab_list = { {
                crontab = "*/10 * * * * *",
                fun = "cron",
                args = "",
                name = "检查账号状态",
                scope = "account",
                options = {
                    has_wait_pay_order = 0
                }
            } }
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = "gateway",
                label = "选择网关",
                type = types.InputTypes.SELECT,
                default = "",
                options = {
                    tip = "",
                    chose_gateway = 1
                },
                placeholder = "请选择网关",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择"
                } }
            },
            {
                name = "client_id",
                label = "客户端ID",
                type = types.InputTypes.INPUT,
                default = "",
                options = {
                    tip = "不需要填写，客户端ID就是你号的设备，同一个账号请不要随意更换客户端ID"
                }
            },
            {
                name = "pay_mode",
                label = "收款方式",
                type = types.InputTypes.RADIO,
                default = "self",
                options = {
                    tip = "收款单和小账本会通过手表登录态自动获取SID"
                },
                placeholder = "请选择收款方式",
                values = { {
                    label = "个人上传",
                    value = "self"
                }, {
                    label = "收款单",
                    value = "receipt"
                }, {
                    label = "小账本",
                    value = "smallbook"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择收款方式"
                } }
            },
            {
                name = "sid",
                label = "SID",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt' || this.formModel.options.pay_mode == 'smallbook'",
                options = {
                    tip = "登录手表微信后自动获取，也可手动填写"
                },
                placeholder = "自动获取或手动输入SID"
            },
            {
                name = "account_list",
                label = "账号列表(一行一组)",
                type = "textarea",
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt' && this.formModel.options.sid",
                hidden_list = 1,
                options = {
                    tip = "自动获取；清空后保存会重新拉取"
                },
                placeholder = "清空后重新获取"
            },
            {
                name = "aid",
                label = "账号ID",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt' && this.formModel.options.sid",
                options = {
                    tip = "从账号列表选择对应账号ID"
                },
                placeholder = "请输入账号ID"
            },
            {
                name = "account_type",
                label = "账号类型",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt' && this.formModel.options.sid",
                options = {
                    tip = "从账号列表选择对应账号类型(1-3)"
                },
                placeholder = "请输入账号类型"
            },
            {
                name = "shop_id",
                label = "店铺ID",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt' && this.formModel.options.sid",
                options = {
                    tip = "自动获取；没有店铺ID时保持为空"
                },
                placeholder = "请输入店铺ID"
            },
            {
                name = "qrcode",
                label = "收款码地址",
                type = types.InputTypes.INPUT,
                default = "",
                options = {
                    append_deqrocde = 1,
                    tip = ""
                },
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.pay_mode == 'self' && this.formModel.options.type == 'url'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "qrcode_file",
                label = "收款码图片",
                type = types.InputTypes.IMAGE,
                default = "",
                options = {
                    tip = ""
                },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.pay_mode == 'self' && this.formModel.options.type == 'image'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "type",
                label = "收款码类型",
                type = types.InputTypes.SELECT,
                default = "url",
                options = {
                    tip = ""
                },
                placeholder = "请选择收款码类型",
                when = "this.formModel.options.pay_mode == 'self'",
                values = { {
                    label = "地址",
                    value = "url"
                }, {
                    label = "图片",
                    value = "image"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "proxy_mode",
                label = "代理模式",
                type = types.InputTypes.SELECT,
                default = "no_proxy",
                options = { tip = "选择代理使用模式" },
                placeholder = "请选择代理模式",
                values = { {
                    label = "不使用代理",
                    value = "no_proxy"
                }, {
                    label = "使用自定义代理",
                    value = "custom_proxy"
                }, {
                    label = "使用本站代理池",
                    value = "cloud_proxy"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择代理模式"
                } }
            },
            {
                name = "proxy",
                label = "Socks5代理地址",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.proxy_mode == 'custom_proxy'",
                options = { tip = "格式：socks5://IP:端口，或 socks5://用户名:密码@IP:端口" },
                placeholder = "例如：socks5://127.0.0.1:1080"
            },
            {
                name = "proxy_pool_id",
                label = "绑定代理池",
                type = "chose_proxy_pool",
                default = "-1",
                when = "this.formModel.options.proxy_mode == 'cloud_proxy'",
                options = { tip = "请选择绑定的代理池" },
                placeholder = "请选择代理池",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择代理池"
                } }
            },
            {
                name = "proxy_pool_item_id",
                label = "绑定代理",
                type = types.InputTypes.INPUT,
                default = "0",
                hidden = 1
            },
            {
                name = "mac_url",
                label = "Mac",
                type = types.InputTypes.INPUT,
                default = "",
                hidden = 1,
                options = {
                    tip = "XD测试"
                }
            },
            {
                name = "sid_pay_mode",
                label = "SID模式",
                type = types.InputTypes.INPUT,
                default = "",
                hidden = 1
            }
        }
    }
end

---@param response any
---@return boolean
function plugin._is_sid_invalid_response(response)
    if type(response) == "string" then
        return string.find(response, "登录态", 1, true) ~= nil or
            string.find(response, "登录失效", 1, true) ~= nil or
            string.find(response, "登录过期", 1, true) ~= nil
    end
    if type(response) ~= "table" then
        return false
    end
    return plugin._is_sid_invalid_response(response.msg) or
        plugin._is_sid_invalid_response(response.errmsg) or
        plugin._is_sid_invalid_response(response.message) or
        plugin._is_sid_invalid_response(response.data)
end

---@param response table|nil
---@param operation string
---@return boolean, table|nil, string
function plugin._check_special_http_response(response, operation)
    if response == nil then
        return false, nil, operation .. "请求失败"
    end
    if response.status_code ~= 200 then
        return false, nil, string.format("%s失败,状态码:%s", operation, tostring(response.status_code))
    end
    local data = decodeBody(response.body)
    if not data then
        return false, nil, operation .. "响应解析失败"
    end
    if data.errcode ~= nil and tonumber(data.errcode) ~= 0 then
        return false, data, data.msg or data.errmsg or operation .. "失败"
    end
    return true, data, ""
end

---@param accountInfo table
---@param options table
---@return boolean, string
function plugin._sync_special_sid(accountInfo, options)
    local valid, errMessage = validateParams(options, { "client_id" })
    if not valid then
        return false, "请先扫码登录手表微信账号"
    end

    local serverAddress = options.mac_url or ""
    if serverAddress == "" and not isBlank(options.gateway) then
        serverAddress = helper.channel_gateway_addr(options.gateway)
    end
    if serverAddress == "" then
        return false, "暂未配置支付网关"
    end

    local mode = getPayMode(options)
    local app = mode == "smallbook" and WXAPP.SMALLBOOK or WXAPP.RECEIPT
    local sidName = mode == "smallbook" and "小账本SID" or "收款单SID"
    local apiUri = string.format("%s/applet/JsLogin?key=%s", serverAddress,
        helper.url_encode(tostring(options.client_id)))
    local response, requestError = http.request("POST", apiUri, {
        body = json.encode({
            AppId = app.app_id
        }),
        timeout = "60s",
        headers = {
            ["accept"] = "application/json",
            ["content-type"] = "application/json"
        }
    })
    if requestError ~= nil or response == nil then
        return false, string.format("调用/applet/JsLogin失败: %s", requestError or "请求失败")
    end
    if response.status_code ~= 200 then
        return false, string.format("调用/applet/JsLogin失败,状态码:%s", tostring(response.status_code))
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo then
        return false, "/applet/JsLogin响应解析失败"
    end

    local code
    if returnInfo.Code ~= nil and tonumber(returnInfo.Code) ~= nil then
        local statusCode = tonumber(returnInfo.Code)
        if statusCode ~= 0 and statusCode ~= 200 then
            return false, returnInfo.Text or returnInfo.Message or "获取小程序code失败"
        end
        code = extractAppletCode(returnInfo.Data)
    elseif returnInfo.code ~= nil and tonumber(returnInfo.code) ~= nil and returnInfo.data ~= nil then
        local statusCode = tonumber(returnInfo.code)
        if statusCode ~= 0 and statusCode ~= 200 then
            return false, returnInfo.msg or returnInfo.message or "获取小程序code失败"
        end
        code = extractAppletCode(returnInfo.data)
    else
        code = extractAppletCode(returnInfo)
    end
    if isBlank(code) then
        return false, "/applet/JsLogin未返回" .. sidName .. "登录code"
    end

    local loginResponse, loginError = http.request("GET", app.login_url .. helper.url_encode(code), {
        timeout = "30s",
        headers = miniProgramHeaders(app.referer)
    })
    if loginError ~= nil or loginResponse == nil or loginResponse.status_code ~= 200 then
        return false, string.format("使用小程序code获取%s失败: %s", sidName,
            loginError or (loginResponse and tostring(loginResponse.status_code)) or "请求失败")
    end

    local loginData = decodeBody(loginResponse.body)
    local sid = extractSid(loginData)
    if isBlank(sid) then
        return false, (loginData and (loginData.msg or loginData.errmsg)) or "小程序接口未返回" .. sidName
    end

    local oldMode = options.sid_pay_mode
    helper.channel_account_set_option(accountInfo.id, "sid", sid)
    helper.channel_account_set_option(accountInfo.id, "sid_pay_mode", mode)
    options.sid = sid
    options.sid_pay_mode = mode

    if oldMode and oldMode ~= "" and oldMode ~= mode then
        helper.channel_account_set_option(accountInfo.id, "account_list", "")
        helper.channel_account_set_option(accountInfo.id, "aid", "")
        helper.channel_account_set_option(accountInfo.id, "account_type", "")
        helper.channel_account_set_option(accountInfo.id, "shop_id", "")
        options.account_list = ""
        options.aid = ""
        options.account_type = ""
        options.shop_id = ""
    end
    return true, ""
end

---@param accountInfo table
---@param options table
---@param scene string
---@return boolean, string
function plugin._refresh_special_sid(accountInfo, options, scene)
    log.warning(string.format("(%s) %s SID可能已失效，尝试通过手表登录态刷新SID",
        PAY_CHANNEL_CODE_YUN_WECHAT_WATCH_XD, scene or "收款"))
    local ok, errMessage = plugin._sync_special_sid(accountInfo, options)
    if not ok then
        return false, errMessage
    end
    if getPayMode(options) == "receipt" then
        return plugin._sync_receipt_account_options(accountInfo, options)
    end
    return true, ""
end

---@param accountList string
---@param aid any
---@param accountType any
---@return string|nil
function plugin._get_shop_id_from_account_list(accountList, aid, accountType)
    if isBlank(accountList) or isBlank(aid) then
        return nil
    end
    for line in string.gmatch(accountList, "[^\r\n]+") do
        local lineAid = string.match(line, "账号ID:([^|]+)")
        local lineType = string.match(line, "账号类型:([^|]+)")
        local shopId = string.match(line, "shop_id:([^|]+)")
        if lineAid == tostring(aid) and (isBlank(accountType) or lineType == tostring(accountType)) then
            return not isBlank(shopId) and shopId or nil
        end
    end
    return nil
end

---@param sid string
---@return table|nil, string
function plugin._get_receipt_account_list(sid)
    local url = GATEWAY.RECEIPT_WX .. "/account/list?miniprogram_version=3.15.10&sid=" ..
        helper.url_encode(tostring(sid))
    local response = http.request("GET", url, {
        timeout = "30s",
        headers = miniProgramHeaders(WXAPP.RECEIPT.referer)
    })
    local ok, data, errMessage = plugin._check_special_http_response(response, "获取收款单账号列表")
    if not ok then
        return nil, errMessage
    end
    if data.data and type(data.data.account_list) == "table" then
        return data.data.account_list, ""
    end
    return nil, "收款单账号列表为空"
end

---@param sid string
---@param accountId any
---@param accountType any
---@return string|nil
function plugin._get_shop_id(sid, accountId, accountType)
    local gateway = getReceiptGateway(accountType)
    if not gateway then
        return nil
    end
    local url = string.format(
        "%s/account/get?miniprogram_version=3.15.10&account_id=%s&account_type=%s&sid=%s",
        gateway, helper.url_encode(tostring(accountId)), helper.url_encode(tostring(accountType)),
        helper.url_encode(tostring(sid)))
    local response = http.request("GET", url, {
        timeout = "30s",
        headers = miniProgramHeaders(WXAPP.RECEIPT.referer)
    })
    local ok, data = plugin._check_special_http_response(response, "获取店铺ID")
    if ok and data.data and type(data.data.auth_shop_list) == "table" and #data.data.auth_shop_list > 0 then
        local shopId = data.data.auth_shop_list[1].shop_id
        return not isBlank(shopId) and tostring(shopId) or nil
    end
    return nil
end

---@param accountInfo table
---@param options table
---@return boolean, string
function plugin._sync_receipt_account_options(accountInfo, options)
    local accountList, errMessage = plugin._get_receipt_account_list(options.sid)
    if not accountList then
        return false, errMessage
    end

    local lines = {}
    local activatedAccounts = {}
    for _, account in ipairs(accountList) do
        if account.account_status == "ACTIVATED" then
            local shopId = plugin._get_shop_id(options.sid, account.account_id, account.account_type) or ""
            account.shop_id = shopId
            table.insert(lines, string.format("账号ID:%s|账号类型:%s|商户名称:%s|shop_id:%s",
                account.account_id or "", account.account_type or "", account.account_name or "", shopId))
            table.insert(activatedAccounts, account)
        end
    end

    local accountListText = table.concat(lines, "\n")
    helper.channel_account_set_option(accountInfo.id, "account_list", accountListText)
    options.account_list = accountListText
    if #activatedAccounts == 0 then
        return false, "没有可用的收款单账号"
    end

    local selected = activatedAccounts[1]
    for _, account in ipairs(activatedAccounts) do
        if tostring(account.account_id) == tostring(options.aid) and
            tostring(account.account_type) == tostring(options.account_type) then
            selected = account
            break
        end
    end
    helper.channel_account_set_option(accountInfo.id, "aid", selected.account_id)
    helper.channel_account_set_option(accountInfo.id, "account_type", selected.account_type)
    helper.channel_account_set_option(accountInfo.id, "shop_id", selected.shop_id or "")
    options.aid = selected.account_id
    options.account_type = tostring(selected.account_type)
    options.shop_id = selected.shop_id or ""
    return true, ""
end

---@param accountInfo table
---@param options table
---@return boolean, string
function plugin._verify_special_account(accountInfo, options)
    local mode = getPayMode(options)
    if mode == "ipad" then
        return true, ""
    end

    local shouldRefresh = isBlank(options.sid) or
        (not isBlank(options.sid_pay_mode) and options.sid_pay_mode ~= mode)
    if shouldRefresh then
        local ok, errMessage = plugin._sync_special_sid(accountInfo, options)
        if not ok then
            return false, errMessage
        end
    end

    if mode == "smallbook" then
        return true, ""
    end
    if isBlank(options.account_list) or not string.find(options.account_list, "shop_id:", 1, true) then
        local ok, errMessage = plugin._sync_receipt_account_options(accountInfo, options)
        if not ok then
            return false, errMessage
        end
    end
    if isBlank(options.aid) then
        return false, "请选择一个收款单账号"
    end
    if isBlank(options.account_type) then
        return false, "请选择收款单账号类型"
    end

    local shopId = plugin._get_shop_id_from_account_list(options.account_list, options.aid, options.account_type)
    if not isBlank(shopId) and shopId ~= options.shop_id then
        helper.channel_account_set_option(accountInfo.id, "shop_id", shopId)
        options.shop_id = shopId
    end
    return true, ""
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local orderInfo = ctx.order_info or {}
    local accountInfo = toTable(ctx.account_info)
    local accountOptions = mergeOptions(ctx)

    if isSpecialPayMode(accountOptions) then
        local ok, errMessage = plugin._verify_special_account(accountInfo, accountOptions)
        if not ok then
            return errorResponse(500, errMessage)
        end
        if getPayMode(accountOptions) == "smallbook" then
            return plugin._create_smallbook_order(orderInfo, accountOptions, accountInfo, false)
        end
        return plugin._create_receipt_order(orderInfo, accountOptions, accountInfo, false)
    end

    if accountOptions.pay_mode == "self" or
        (isBlank(accountOptions.pay_mode) and accountOptions.qrcode_type == "self") then
        if accountOptions.type == "image" then
            return {
                code = 200,
                message = "success",
                data = {
                    type = types.PaymentResultTypes.QRCODE,
                    qrcode_file = accountOptions.qrcode_file,
                    qrcode = "",
                    url = "",
                    content = "",
                    out_trade_no = ""
                }
            }
        end

        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode = accountOptions.qrcode,
                url = "",
                content = "",
                out_trade_no = ""
            }
        }
    end

    -- 手表协议不支持个码免输（GeneratePayQCode），其余收款方式请另行选择。
    return errorResponse(500, "手表协议不支持个码免输，请将收款方式改为 个人上传/收款单/小账本")
end

---@param orderInfo table
---@param options table
---@param accountInfo table
---@param retried boolean
---@return table
function plugin._create_receipt_order(orderInfo, options, accountInfo, retried)
    local valid, errMessage = validateParams(options, { "sid", "aid", "account_type" })
    if not valid then
        return errorResponse(500, errMessage)
    end
    local gateway = getReceiptGateway(options.account_type)
    if not gateway then
        return errorResponse(500, "不支持的收款单账号类型")
    end

    local url = gateway .. "/receipt/create"
    local headers = miniProgramHeaders(WXAPP.RECEIPT.referer)
    local accountType = tostring(options.account_type)
    local response, requestError
    if accountType == "1" or accountType == "2" then
        local query = {
            "miniprogram_version=3.15.9",
            "remark_pic_urls=",
            "option_list=%5B%5D",
            "account_type=" .. helper.url_encode(accountType),
            "remark=" .. helper.url_encode(tostring(orderInfo.order_id or "")),
            "account_id=" .. helper.url_encode(tostring(options.aid)),
            "sid=" .. helper.url_encode(tostring(options.sid)),
            "fee=" .. helper.url_encode(tostring(orderInfo.trade_amount or 0))
        }
        if not isBlank(options.shop_id) then
            table.insert(query, "shop_id=" .. helper.url_encode(tostring(options.shop_id)))
        end
        url = url .. "?" .. table.concat(query, "&")
        response, requestError = http.request("GET", url, {
            timeout = "30s",
            headers = headers
        })
    else
        url = string.format("%s?miniprogram_version=3.15.9&account_id=%s&account_type=%s&sid=%s",
            url, helper.url_encode(tostring(options.aid)), helper.url_encode(accountType),
            helper.url_encode(tostring(options.sid)))
        local body = {
            miniprogram_version = "3.15.9",
            fee = orderInfo.trade_amount,
            remark = orderInfo.order_id,
            remark_pic_urls = "",
            option_list = {},
            receipt_item_list = {},
            sid = options.sid
        }
        if not isBlank(options.shop_id) then
            body.shop_id = tonumber(options.shop_id) or options.shop_id
        end
        response, requestError = http.request("POST", url, {
            body = json.encode(body),
            timeout = "30s",
            headers = headers
        })
    end

    if response == nil then
        return errorResponse(500, "创建收款单请求失败: " .. (requestError or "未知错误"))
    end
    local createData = decodeBody(response.body)
    if response.status_code ~= 200 or not createData or tonumber(createData.errcode) ~= 0 then
        local sidInvalid = plugin._is_sid_invalid_response(createData) or
            response.status_code == 401 or response.status_code == 403
        if not retried and sidInvalid then
            local ok, refreshError = plugin._refresh_special_sid(accountInfo, options, "创建收款单")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, accountInfo, true)
            end
            return errorResponse(500, refreshError)
        end
        return errorResponse(500, (createData and (createData.msg or createData.errmsg)) or
            string.format("创建收款单失败,状态码:%s", tostring(response.status_code)))
    end

    local receipt = createData.data and createData.data.receipt
    local receiptId = receipt and receipt.receipt_id
    if isBlank(receiptId) then
        return errorResponse(500, "创建收款单成功但未返回receipt_id")
    end

    local qrcodeUrl = string.format(
        "%s/receipt/getwxacode?miniprogram_version=3.15.10&wxacode_path_type=1&receipt_id=%s&account_id=%s&account_type=%s&sid=%s",
        gateway, helper.url_encode(tostring(receiptId)), helper.url_encode(tostring(options.aid)),
        helper.url_encode(accountType), helper.url_encode(tostring(options.sid)))
    local qrcodeResponse, qrcodeError = http.request("GET", qrcodeUrl, {
        timeout = "30s",
        headers = headers
    })
    if qrcodeResponse == nil then
        return errorResponse(500, "获取收款单二维码请求失败: " .. (qrcodeError or "未知错误"))
    end
    local qrcodeData = decodeBody(qrcodeResponse.body)
    if qrcodeResponse.status_code ~= 200 or not qrcodeData or tonumber(qrcodeData.errcode) ~= 0 then
        local sidInvalid = plugin._is_sid_invalid_response(qrcodeData) or
            qrcodeResponse.status_code == 401 or qrcodeResponse.status_code == 403
        if not retried and sidInvalid then
            local ok, refreshError = plugin._refresh_special_sid(accountInfo, options, "获取收款单二维码")
            if ok then
                return plugin._create_receipt_order(orderInfo, options, accountInfo, true)
            end
            return errorResponse(500, refreshError)
        end
        return errorResponse(500, (qrcodeData and (qrcodeData.msg or qrcodeData.errmsg)) or
            string.format("获取收款单二维码失败,状态码:%s", tostring(qrcodeResponse.status_code)))
    end

    local qrcode = qrcodeData.data and qrcodeData.data.qrcode
    if isBlank(qrcode) then
        return errorResponse(500, "收款单接口未返回二维码")
    end
    local written, filePath = helper.save_image_cache_base64(qrcode)
    if not written then
        return errorResponse(500, "收款单二维码保存失败")
    end
    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode_file = filePath,
            qrcode = "",
            url = "",
            content = "",
            out_trade_no = tostring(receiptId)
        }
    }
end

---@param orderInfo table
---@param options table
---@param accountInfo table
---@param retried boolean
---@return table
function plugin._create_smallbook_order(orderInfo, options, accountInfo, retried)
    local valid, errMessage = validateParams(options, { "sid" })
    if not valid then
        return errorResponse(500, errMessage)
    end
    local url = GATEWAY.SMALLBOOK .. "/qrappsl/profile/getpayqrcode?sid=" ..
        helper.url_encode(tostring(options.sid)) .. "&v=6.23.1"
    local response, requestError = http.request("GET", url, {
        timeout = "30s",
        headers = miniProgramHeaders(WXAPP.SMALLBOOK.referer)
    })
    if response == nil then
        return errorResponse(500, "获取小账本二维码请求失败: " .. (requestError or "未知错误"))
    end

    local data = decodeBody(response.body)
    if response.status_code ~= 200 or not data or tonumber(data.errcode) ~= 0 then
        local sidInvalid = plugin._is_sid_invalid_response(data) or
            response.status_code == 401 or response.status_code == 403
        if not retried and sidInvalid then
            local ok, refreshError = plugin._refresh_special_sid(accountInfo, options, "获取小账本二维码")
            if ok then
                return plugin._create_smallbook_order(orderInfo, options, accountInfo, true)
            end
            return errorResponse(500, refreshError)
        end
        return errorResponse(500, (data and (data.msg or data.errmsg)) or
            string.format("获取小账本二维码失败,状态码:%s", tostring(response.status_code)))
    end

    local qrcode = data.data and (data.data.qrcode_content or data.data.qrcode)
    if isBlank(qrcode) then
        return errorResponse(500, "小账本接口未返回二维码")
    end
    local written, filePath = helper.save_image_cache_base64(qrcode)
    if not written then
        return errorResponse(500, "小账本二维码保存失败")
    end
    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode_file = filePath,
            qrcode = "",
            url = "",
            content = "",
            out_trade_no = tostring(orderInfo.order_id or "")
        }
    }
end

-- 定时任务
---@param ctx types.CronAccountParams
---@return table
function plugin.cron(ctx)
    local accountInfo = toTable(ctx.account_info)
    local params = mergeOptions(ctx)
    local accountOptions = params

    if isBlank(params.client_id) then
        params.client_id = accountOptions.client_id
    end
    if isBlank(params.mac_url) then
        params.mac_url = accountOptions.mac_url
    end
    if isBlank(params.websocket_conn_id) then
        params.websocket_conn_id = accountOptions.websocket_conn_id
    end

    if isBlank(params.client_id) then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end

        return {
            code = 500,
            message = "未登录"
        }
    end

    local serverAddress = params.mac_url or ""
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关"
        }
    end

    local apiUri = string.format("%s/login/GetLoginStatus?key=%s", serverAddress, params.client_id)
    local response, error_message = http.request("GET", apiUri, {
        timeout = "30s",
        headers = {
            ["accept"] = "application/json",
            ["content-type"] = "application/json"
        }
    })

    if response == nil then
        log.error("请求获取登录状态失败", error_message)
        return {
            code = 500,
            message = "请求网关失败"
        }
    end

    if response.status_code ~= 200 then
        return {
            code = 500,
            message = "请求网关失败"
        }
    end

    local loginStatus = decodeBody(response.body)
    if not loginStatus or loginStatus.Code ~= 200 then
        helper.channel_account_offline(accountInfo.id)
        return {
            code = 500,
            message = string.format("登录状态异常: %s", (loginStatus and loginStatus.Message) or "未知错误")
        }
    end

    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
        accountInfo.online = 1
    end

    local gatewayAddress = helper.channel_gateway_addr(accountOptions.gateway)
    local ensureKey = tostring(accountInfo.id or params.client_id)
    local now = os.time()
    local lastEnsureAt = forwardEnsureAt[ensureKey] or 0
    if not isBlank(gatewayAddress) and now - lastEnsureAt >= 120 then
        forwardEnsureAt[ensureKey] = now
        local ensureUri = string.format("%s/internal/wechat-ipad/forward/ensure?key=%s", gatewayAddress, helper.url_encode(params.client_id))
        local ensureResponse, ensureError = http.request("POST", ensureUri, {
            body = "{}",
            timeout = "30s",
            headers = {
                ["accept"] = "application/json",
                ["content-type"] = "application/json"
            }
        })
        if ensureResponse == nil or ensureResponse.status_code ~= 200 then
            forwardEnsureAt[ensureKey] = 0
            log.error("ensure gateway forwarding failed", ensureError or (ensureResponse and ensureResponse.body) or "unknown error")
        end
    end

    if isSpecialPayMode(accountOptions) then
        local ok, verifyError = plugin._verify_special_account(accountInfo, accountOptions)
        if not ok then
            return {
                code = 200,
                message = "手表在线，特殊收款初始化失败: " .. verifyError,
                data = {}
            }
        end
        return {
            code = 200,
            message = "在线，支付结果依赖手表消息上报",
            data = {}
        }
    end

    return {
        code = 200,
        message = "在线，消息由网关内部处理"
    }
end

---@param accountId any
---@param uid any
---@param msg table
function plugin.parseMsg(accountId, uid, msg)
    local contentInfo = toTable(msg.content)
    local msgData = contentInfo.str or ""
    if msgData == "" then
        return
    end

    local appMsg = msgData:match("<appmsg([%W%w]+)</appmsg>") or ""
    local remark = appMsg:match("<des>%s*<!%[CDATA%[[%w%W]+收款方备注(%d+)[%w%W]+<%/des>%s+<action>")
    local title = msgData:match("<appname><!%[CDATA%[(.*)%]%]><%/appname>")
    local content = msgData:match("<title><!%[CDATA%[(.*)%]%]><%/title>%s+<des")
    log.debug("消息内容", msgData)
    log.debug("解析消息", remark, title, content)

    if isBlank(title) or isBlank(content) then
        return
    end

    local rules = { {
        TitleReg = "微信收款助手",
        ContentReg = "微信支付收款(?<amount>[\\d\\.]+)元(\\(([新老]顾客)?(朋友)?到店\\))?"
    }, {
        TitleReg = "微信支付",
        ContentReg = "微信支付：微信支付收款(?<amount>[\\d\\.]+)元"
    }, {
        TitleReg = "微信支付",
        ContentReg = "个人收款码到账¥(?<amount>[\\d\\.]+)"
    }, {
        TitleReg = "微信收款助手",
        ContentReg = "\\[店员消息\\]收款到账(?<amount>[\\d\\.]+)元"
    }, {
        TitleReg = "微信支付",
        ContentReg = "二维码赞赏到账(?<amount>[\\d\\.]+)元"
    }, {
        TitleReg = "微信收款商业版",
        ContentReg = "收款(?<amount>[\\d\\.]+)元"
    }, {
        TitleReg = "收款通知",
        ContentReg = "微信收款商业版: 收款(?<amount>[\\d\\.]+)元"
    }, {
        TitleReg = "微信收款助手",
        ContentReg = "收款单到账(?<amount>[\\d\\.]+)元"
    } }

    for _, rule in ipairs(rules) do
        local titleMatched = helper.regexp_match(title, rule.TitleReg)
        if titleMatched then
            local matched, matchGroups = helper.regexp_match_group(content, rule.ContentReg)
            local groups = toTable(matchGroups)
            if matched and groups.amount and #groups.amount > 0 then
                local amount = tonumber(groups.amount[1])
                if amount then
                    orderHelper.report({
                        id = accountId,
                        uid = uid
                    }, {
                        amount = math.floor((amount + 0.000005) * 100),
                        pay_type = "wxpay",
                        channel_code = PAY_CHANNEL_CODE_YUN_WECHAT_WATCH_XD,
                        pay_time = msg.create_time,
                        out_order_id = remark
                    })
                end
            end
        end
    end
end

-- 二维码登录
---@param ctx table
---@return table
function plugin.login_qrcode(ctx)
    local accountInfo = toTable(ctx.account_info)
    local accountOption = toTable(accountInfo.options)
    local userInfo = toTable(ctx.user_info)
    local deviceInfo = toTable(ctx.device)

    local serverAddress = helper.channel_gateway_addr(accountOption.gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    accountOption.account_id = accountInfo.id

    local clientId = tostring(accountOption.client_id or "")
    local apiUri = string.format("%s/login/WatchLoginApi?key=%s", serverAddress, clientId)
    local merchantData = helper.base64_encode(json.encode({
        site = deviceInfo.base_url or deviceInfo.domain or deviceInfo.host or "",
        pid = userInfo.id or "",
        key = userInfo.app_secret or "",
        channel_account_id = accountInfo.id or 0
    }))
    apiUri = apiUri .. "&data=" .. helper.url_encode(merchantData)
    local loginHeaders = {
        ["content-type"] = "application/json"
    }
    local proxyHeaders = getProxyHeaders(accountOption)
    if proxyHeaders then
        for key, value in pairs(proxyHeaders) do
            loginHeaders[key] = value
        end
    end
    local response, error_message = http.request("POST", apiUri, {
        body = json.encode({
            Check = false,
            Proxy = ""
        }),
        headers = loginHeaders,
        timeout = "30s"
    })

    if error_message ~= nil or response == nil then
        return {
            code = 500,
            message = string.format("请求获取登录二维码错误: %s", error_message or "请求失败"),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.Code ~= 200 then
        return {
            code = 500,
            message = string.format("返回错误状态码: %s", response.body or ""),
            data = {}
        }
    end

    log.debug("获取登录二维码成功", response.body)
    local qrcode = returnInfo.Data and returnInfo.Data.QrCodeUrl or ""
    local xdUrl = returnInfo.Url
    clientId = returnInfo.Key or clientId
    log.debug("获取key成功", clientId)

    local parsed, parsedUrl = helper.url_parse(qrcode)
    if parsed and parsedUrl ~= nil and parsedUrl.host == "iis.xdau.cn" and parsedUrl.query and parsedUrl.query.text then
        qrcode = parsedUrl.query.text
        log.debug("获取到登录链接", qrcode)
    end

    helper.channel_account_set_option(accountInfo.id, "client_id", clientId)

    return {
        code = 200,
        message = "success",
        data = {
            qrcode = qrcode,
            options = json.encode({
                client_id = clientId,
                xd_url = xdUrl
            })
        }
    }
end

-- 检查二维码登录状态
---@param ctx table
---@return table
function plugin.login_qrcode_check(ctx)
    local params = toTable(ctx.params)
    local accountInfo = toTable(ctx.account_info)
    local accountOption = toTable(accountInfo.options)

    local serverAddress = helper.channel_gateway_addr(accountOption.gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    if not isBlank(params.xd_url) then
        serverAddress = params.xd_url
    end

    local clientId = params.client_id or accountOption.client_id
    if isBlank(clientId) then
        return {
            code = 201,
            message = "等待扫码",
            data = {}
        }
    end

    local apiUri = string.format("%s/login/CheckLoginStatus?key=%s", serverAddress, clientId)
    log.debug(" 检查二维码登录状态", apiUri)
    local response, error_message = http.request("GET", apiUri, {
        timeout = "30s",
        headers = {
            ["accept"] = "application/json"
        }
    })

    if error_message ~= nil or response == nil then
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message or "请求失败"),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.Code == nil then
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    if returnInfo.Code ~= 200 then
        return {
            code = 500,
            message = returnInfo.Text or "登录失败",
            data = {}
        }
    end

    if returnInfo.Data and returnInfo.Data.state == 1 then
        return {
            code = 201,
            message = "扫码中",
            data = {}
        }
    end

    if returnInfo.Data and returnInfo.Data.state == 2 then
        helper.channel_account_set_option(accountInfo.id, "client_id", clientId)
        helper.channel_account_set_option(accountInfo.id, "mac_url", serverAddress)
        accountOption.client_id = clientId
        accountOption.mac_url = serverAddress
        local successMessage = string.format("登录成功 %s", returnInfo.Data.nick_name or "")
        if isSpecialPayMode(accountOption) then
            local initialized, initError = plugin._verify_special_account(accountInfo, accountOption)
            if initialized then
                successMessage = successMessage .. "，已初始化" ..
                    (getPayMode(accountOption) == "smallbook" and "小账本" or "收款单")
            else
                successMessage = successMessage .. "，特殊收款初始化失败: " .. initError
            end
        end
        return {
            code = 200,
            message = successMessage,
            data = {
                can_bind_token = false
            }
        }
    end

    return {
        code = 201,
        message = "等待扫码",
        data = {}
    }
end

-- 通道新增或修改
---@param ctx table
---@return table
function plugin.onAccountChanged(ctx)
    local accountInfo = toTable(ctx.account_info or ctx)
    local options = mergeOptions(ctx.account_info and ctx or { account_info = accountInfo })
    if not isSpecialPayMode(options) then
        return {
            code = 200,
            message = "账号保存成功",
            data = {}
        }
    end

    if getPayMode(options) == "receipt" then
        local shopId = plugin._get_shop_id_from_account_list(options.account_list, options.aid, options.account_type)
        if not isBlank(shopId) and shopId ~= options.shop_id then
            helper.channel_account_set_option(accountInfo.id, "shop_id", shopId)
            options.shop_id = shopId
        end
        if options.account_list == "" then
            helper.channel_account_set_option(accountInfo.id, "aid", "")
            helper.channel_account_set_option(accountInfo.id, "account_type", "")
            helper.channel_account_set_option(accountInfo.id, "shop_id", "")
        end
    end

    if isBlank(options.client_id) or isBlank(options.mac_url) then
        return {
            code = 200,
            message = "账号保存成功，请扫码登录手表微信账号",
            data = {}
        }
    end
    local initialized, initError = plugin._verify_special_account(accountInfo, options)
    return {
        code = 200,
        message = initialized and "账号保存成功，特殊收款已初始化" or
            ("账号保存成功，特殊收款待初始化: " .. initError),
        data = {}
    }
end

-- 唤醒
---@param ctx table
---@return table
function plugin.action_wake(ctx)
    local accountInfo = toTable(ctx.account_info)
    local accountOption = toTable(accountInfo.options)
    accountOption.account_id = accountInfo.id

    local serverAddress = helper.channel_gateway_addr(accountOption.gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    if not isBlank(accountOption.mac_url) then
        serverAddress = accountOption.mac_url
    end

    local apiUri = string.format("%s/login/WakeUpLogin?key=%s", serverAddress, accountOption.client_id or "")
    local response, error_message = http.request("POST", apiUri, {
        body = json.encode({
            Check = false,
            Proxy = getProxy(accountOption)
        }),
        timeout = "30s",
        headers = {
            ["accept"] = "application/json",
            ["content-type"] = "application/json"
        }
    })

    if response == nil then
        log.error("唤醒请求失败", error_message)
        return {
            code = 500,
            message = "唤醒请求失败: " .. (error_message or "未知错误"),
            data = {}
        }
    end

    log.info("唤醒请求响应", response.body)

    return {
        code = 200,
        message = "唤醒请求已发送",
        data = {}
    }
end

-- 消息处理回调
function plugin.onConnect(connID, pOptions)
    log.info("连接成功" .. connID)
end

-- 消息处理回调
function plugin.onMessage(connID, pOptions, message)
    log.info("收到消息: ", toLogString(message))
    local options = toTable(pOptions)
    local wsMessage = toTable(message)
    local messageData = wsMessage.data
    if messageData == nil then
        messageData = wsMessage
    end

    local parsedMessage = toTable(messageData)
    log.debug("解析后的消息: ", toLogString(parsedMessage))
    plugin.parseMsg(options.id, options.uid, parsedMessage)
end

-- 错误处理回调
function plugin.onError(connID, pOptions, errorMsg)
    log.info("发生错误: " .. errorMsg)
end

-- 连接关闭回调
function plugin.onClose(connID, pOptions, reason)
    log.info("连接关闭: " .. reason)
end

return plugin
