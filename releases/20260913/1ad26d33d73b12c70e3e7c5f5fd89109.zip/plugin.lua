---@diagnostic disable: undefined-global
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local PLUGIN = "pc_wxpay_lz"
local PAY_WXPAY_APP = PLUGIN

local plugin = {}

function plugin.pluginInfo()
    return {
        channels = {
            ["wxpay"] = { {
                label = 'PC自挂-微信-靓仔监控端',
                value = PAY_WXPAY_APP,
                report = 1,
                parse_msg = 1,
                options = {
                    use_add_amount = 1,
                }
            } }
        },
        options = {
            callback = 0,
            detection_interval = 0,
        }
    }
end

function plugin.formItems(ctx)
    return {
        inputs = {
            {
                name = 'qrcode',
                label = '收款码地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.type == 'url'",
                options = {
                    append_deqrocde = 1,
                    tip = '',
                },
                rules = {{
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                }}
            },
            {
                name = 'qrcode_file',
                label = '收款码图片',
                type = types.InputTypes.IMAGE,
                default = "",
                options = { tip = '' },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.type == 'image'",
                rules = {{
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                }}
            },
            {
                name = 'type',
                label = '收款码类型',
                type = types.InputTypes.SELECT,
                default = "url",
                options = { tip = '支持/个人码/经营码/赞赏码/商家码/微信店员/拉卡拉/易生' },
                placeholder = "请选择收款码类型",
                values = {{ label = "地址", value = "url" }, { label = "图片", value = "image" }},
                rules = {{
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                }}
            },
        },
    }
end

function plugin.create(ctx)
    local options = ctx.account_options

    if options['type'] == 'image' then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = options['qrcode_file'],
                qrcode = "",
                url = "",
                content = "",
                out_trade_no = ''
            }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = " " .. (options['qrcode'] or "") .. " ",
            url = "",
            content = "",
            out_trade_no = ''
        }
    }
end

function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = { response = "" }
    }
end

return plugin
