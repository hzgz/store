-- 监控插件 - 微信
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local heartbeatSessionContainers = {
    "ext_data",
    "extData",
    "heartbeat",
    "heartbeat_request",
    "heartbeat_data",
    "request_data",
    "request",
    "body",
    "params",
    "query",
    "data",
}

local function trimmedFirst(...)
    for index = 1, select("#", ...) do
        local value = tostring(select(index, ...) or ""):match("^%s*(.-)%s*$")
        if value ~= "" then
            return value
        end
    end
    return ""
end

local function decodeHeartbeatObject(value)
    if type(value) == "table" then
        return value
    end
    if type(value) ~= "string" or value == "" then
        return nil
    end
    local ok, decoded = pcall(json.decode, value)
    if ok and type(decoded) == "table" then
        return decoded
    end
    return nil
end

local function heartbeatSessionForKind(value, kindID, depth)
    local data = decodeHeartbeatObject(value)
    if data == nil or depth < 0 then
        return nil
    end

    local sessions = decodeHeartbeatObject(data.sid_sessions or data.sidSessions)
    local session = sessions and decodeHeartbeatObject(sessions[kindID]) or nil
    if session ~= nil and tostring(session.sid or ""):match("^%s*(.-)%s*$") ~= "" then
        return session
    end

    for _, key in ipairs(heartbeatSessionContainers) do
        local nested = heartbeatSessionForKind(data[key], kindID, depth - 1)
        if nested ~= nil then
            return nested
        end
    end
    return nil
end

local function heartbeatStatusFrom(value, depth)
    local data = decodeHeartbeatObject(value)
    if data == nil or depth < 0 then
        return nil
    end

    if type(data.status) == "string" then
        local status = data.status:match("^%s*(.-)%s*$"):lower()
        if status == "online" or status == "offline" then
            return status
        end
    end

    for _, key in ipairs(heartbeatSessionContainers) do
        local status = heartbeatStatusFrom(data[key], depth - 1)
        if status ~= nil then
            return status
        end
    end
    return nil
end

local function heartbeatAccountOnlineState(account)
    local value = type(account) == "table" and account.online or nil
    if value == true or value == 1 or value == "1" then
        return true
    end
    if value == false or value == 0 or value == "0" then
        return false
    end
    return nil
end

local function syncHeartbeatAccountState(accountId, account, status, pluginName)
    if status ~= "online" and status ~= "offline" then
        return true, false
    end

    local expectedOnline = status == "online"
    if heartbeatAccountOnlineState(account) == expectedOnline then
        return true, false
    end

    local action = expectedOnline and helper.channel_account_online or helper.channel_account_offline
    local callOk, result = pcall(action, accountId)
    if not callOk or result == false then
        log.error(string.format("(%s) 心跳更新账号状态失败，账号ID:%s，目标状态:%s",
            pluginName or "jk_wechat_pc", tostring(accountId), status))
        return false, false
    end

    log.info(string.format("(%s) 心跳已将账号%s，账号ID:%s",
        pluginName or "jk_wechat_pc", expectedOnline and "上线" or "离线", tostring(accountId)))
    return true, true
end

local function createGmdtPlugin()
---@diagnostic disable: undefined-global
-- 微信个码动态-XD监控端

local PAY_WXPAY_GMDT_XD = "jk_wechat_pc"
local WAITING_FOR_REPORT = "等待PC自挂上报！"

---@class plugin
local plugin = {}

local function trim(value)
    return tostring(value or ""):match("^%s*(.-)%s*$")
end

local function decodeTable(value)
    if type(value) == "table" then
        return value
    end

    if type(value) == "string" and value ~= "" then
        local ok, decoded = pcall(json.decode, value)
        if ok and type(decoded) == "table" then
            return decoded
        end
    end

    return {}
end

local function positiveId(...)
    for index = 1, select("#", ...) do
        local value = select(index, ...)
        if type(value) == "number" or type(value) == "string" then
            local id = tonumber(value)
            if id ~= nil and id > 0 then
                return id
            end
        end
    end
    return nil
end

local function normalizedKey(value)
    return tostring(value or ""):gsub("[^%w]", ""):lower()
end

local ACCOUNT_ID_KEY_PRIORITY = {
    "id",
    "accountid",
    "channelaccountid",
    "channelid",
}

local ACCOUNT_CONTAINER_KEY_PRIORITY = {
    "payaccount",
    "accountinfo",
    "channelaccount",
    "account",
    "data",
}

local function findAccountId(value, depth, allowScalar)
    if allowScalar then
        local scalarId = positiveId(value)
        if scalarId ~= nil then
            return scalarId
        end
    end

    local data = decodeTable(value)
    for _, expectedKey in ipairs(ACCOUNT_ID_KEY_PRIORITY) do
        for key, candidate in pairs(data) do
            if normalizedKey(key) == expectedKey then
                local id = positiveId(candidate)
                if id ~= nil then
                    return id
                end
            end
        end
    end

    if depth > 0 then
        for _, expectedKey in ipairs(ACCOUNT_CONTAINER_KEY_PRIORITY) do
            for key, nested in pairs(data) do
                if normalizedKey(key) == expectedKey then
                    local nestedId = findAccountId(nested, depth - 1, true)
                    if nestedId ~= nil then
                        return nestedId
                    end
                end
            end
        end
        for _, nested in ipairs(data) do
            local nestedId = findAccountId(nested, depth - 1, true)
            if nestedId ~= nil then
                return nestedId
            end
        end
    end
    return nil
end

local function findSid(value, depth)
    local data = decodeTable(value)
    local sid = trim(data.sid or data.Sid or data.receipt_sid or data.receiptSid)
    if sid ~= "" then
        return sid
    end
    if depth <= 0 then
        return nil
    end
    for _, key in ipairs({
        "ext_data",
        "extData",
        "request",
        "heartbeat_request",
        "heartbeat_data",
        "body",
        "params",
        "query",
        "data",
    }) do
        local nestedSid = findSid(data[key], depth - 1)
        if nestedSid ~= nil then
            return nestedSid
        end
    end
    return nil
end

local function describeValue(value)
    local valueType = type(value)
    if valueType == "table" then
        local keys = {}
        for key in pairs(value) do
            table.insert(keys, tostring(key))
        end
        table.sort(keys)
        return "table{" .. table.concat(keys, ",") .. "}"
    end
    if valueType == "string" then
        local decoded = decodeTable(value)
        if next(decoded) ~= nil then
            return "json:" .. describeValue(decoded)
        end
        return string.format("string(len=%d)", #value)
    end
    return valueType .. "(" .. tostring(value) .. ")"
end

local function redactSecret(value, secret)
    local message = tostring(value or "")
    local secretText = tostring(secret or "")
    if secretText ~= "" then
        local escapedSecret = secretText:gsub("([^%w])", "%%%1")
        message = message:gsub(escapedSecret, "[REDACTED]")
    end
    return message:sub(1, 500)
end

local function saveAccountOption(accountId, key, value, payAccount)
    local callOk, saved, saveError = pcall(helper.channel_account_set_option, accountId, key, value)
    if callOk and saved == true then
        return true, ""
    end

    local failureType
    local failureDetail
    if not callOk then
        failureType = "保存接口调用异常"
        failureDetail = saved
    elseif saved == false then
        failureType = "保存接口返回 false"
        failureDetail = saveError
    else
        failureType = "保存接口未返回成功状态"
        failureDetail = saveError or describeValue(saved)
    end

    log.error(string.format(
        "(%s) 保存账号配置失败，账号ID:%s，配置项:%s，结果:%s，详情:%s，PayAccount:%s",
        PAY_WXPAY_GMDT_XD,
        tostring(accountId),
        tostring(key),
        failureType,
        redactSecret(failureDetail, value),
        describeValue(payAccount)
    ))
    return false, failureType
end

local function createError(message)
    return {
        code = 500,
        message = message,
        data = {
            type = types.PaymentResultTypes.ERROR,
        },
    }
end

local function heartbeatResponse(useLegacyResponse, code, message, data)
    if useLegacyResponse then
        return json.encode({
            err_code = code,
            err_message = message,
            data = data or {},
        })
    end

    return {
        code = code,
        message = message,
        err_code = code,
        err_message = message,
        data = data or {},
    }
end

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    return {
        channels = {
            wxpay = {
                {
                    label = '微信个码动态-XD监控端',
                    value = PAY_WXPAY_GMDT_XD,
                    report = 1,
                    parse_msg = 0,
                    options = {
                        bind_client_name = 1,
                        use_add_amount = 1,
                    }
                },
            },
        },
        options = {
            callback = 0,
            detection_interval = 0,
        },
    }
end

--- 获取通道账号配置表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    if ctx.pay_channel ~= PAY_WXPAY_GMDT_XD then
        return { inputs = {} }
    end

    return {
        inputs = {
            {
                name = 'sid',
                label = 'SID',
                type = types.InputTypes.INPUT,
                default = "",
                options = {
                    tip = '可手动输入 SID，或等待 PC 监控端通过心跳自动上报',
                },
                placeholder = "请输入 SID 或等待监控端上报",
            },
        },
    }
end

--- 创建订单并获取动态收款码
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local accountOptions = ctx.account_options or {}
    local sid = trim(accountOptions.sid)

    if sid == "" or sid == WAITING_FOR_REPORT then
        return createError("请先输入 SID 或等待 PC 监控端上报")
    end

    local url = "https://smallbook.wxpapp.weixin.qq.com/qrappsl/profile/getpayqrcode"
        .. "?sid=" .. helper.url_encode(sid)
        .. "&v=6.23.1"

    log.debug(string.format("[插件] (%s) 获取动态收款码", PAY_WXPAY_GMDT_XD))

    local result, requestError = http.request("GET", url, {
        timeout = "30s",
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx28be8489b7a36aaa/1061/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9",
        },
    })

    if requestError ~= nil or result == nil then
        return createError("获取二维码请求失败: " .. tostring(requestError or "空响应"))
    end

    local statusCode = tonumber(result.status_code or result.status)
    if statusCode ~= nil and statusCode ~= 200 then
        return createError(string.format("获取二维码请求失败，状态码: %d", statusCode))
    end

    if result.body == nil or result.body == "" then
        return createError("获取二维码失败: 返回内容为空")
    end

    local decodeOk, response = pcall(json.decode, result.body)
    if not decodeOk or type(response) ~= "table" then
        return createError("获取二维码失败: 无法解析返回数据")
    end

    if tonumber(response.errcode) ~= 0 then
        return createError(response.msg or response.errmsg or "获取二维码失败")
    end

    local qrcode = response.data and response.data.qrcode_content or ""
    if qrcode == "" then
        return createError("获取二维码失败: 二维码内容为空")
    end

    local saved, filePath = helper.save_image_cache_base64(qrcode)
    if not saved or filePath == nil or filePath == "" then
        return createError("二维码保存失败")
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode_file = filePath,
            qrcode = "",
            url = "",
            content = "",
            out_trade_no = "",
        },
    }
end

--- 处理监控端心跳并更新 SID
--- 同时兼容新版单 table 上下文，以及旧版双参数（JSON 或已解码 table）。
---@param ctx table|string
---@param legacyRequest? any
---@return table|string
function plugin.heartbeat(ctx, legacyRequest, ...)
    local extraArgs = { ... }
    local useLegacyResponse = legacyRequest ~= nil or type(ctx) ~= "table"
    local context = decodeTable(ctx)
    local payAccount = context.PayAccount or context.pay_account or context.payAccount
    local channelAccount
    local heartbeatData

    if useLegacyResponse then
        channelAccount = decodeTable(
            context.account_info or context.accountInfo or context.AccountInfo
                or context.channel_account or context.channelAccount or context.ChannelAccount
                or payAccount
                or context.account or context.Account or context
        )
        heartbeatData = decodeTable(legacyRequest)
    else
        channelAccount = decodeTable(ctx.account_info or ctx.channel_account or ctx.account)

        local request = decodeTable(
            ctx.heartbeat_request or ctx.heartbeat_data or ctx.request or ctx.params or ctx.data or ctx
        )
        if request.body ~= nil then
            heartbeatData = decodeTable(request.body)
        elseif request.params ~= nil then
            heartbeatData = decodeTable(request.params)
        else
            heartbeatData = request
        end
    end

    local session = heartbeatSessionForKind(heartbeatData, "personal-dynamic-code", 4)
        or heartbeatSessionForKind(ctx, "personal-dynamic-code", 4)
    local sid = session and trim(session.sid) or ""
    if sid == "" then
        sid = findSid(heartbeatData, 4) or findSid(ctx, 4)
    end
    if sid == nil then
        for _, extraArg in ipairs(extraArgs) do
            sid = findSid(extraArg, 4)
            if sid ~= nil then
                break
            end
        end
    end
    if sid == nil or sid == "" then
        return heartbeatResponse(useLegacyResponse, 500, "心跳数据解析失败: 缺少 SID")
    end

    local accountId = findAccountId(payAccount, 4, true)
    local accountSource = "PayAccount"
    if accountId == nil then
        accountId = findAccountId(channelAccount, 4, true)
        accountSource = "channelAccount"
    end
    if accountId == nil then
        accountId = findAccountId(ctx, 4, true)
        accountSource = "ctx"
    end
    if accountId == nil then
        accountId = findAccountId(heartbeatData, 4, false)
        accountSource = "heartbeatData"
    end
    if accountId == nil then
        accountId = findAccountId(legacyRequest, 4, false)
        accountSource = "request"
    end
    if accountId == nil then
        for _, extraArg in ipairs(extraArgs) do
            accountId = findAccountId(extraArg, 4, true)
            if accountId ~= nil then
                accountSource = "extraArgs"
                break
            end
        end
    end
    if accountId == nil then
        local argumentShapes = {
            "ctx=" .. describeValue(ctx),
            "request=" .. describeValue(legacyRequest),
        }
        if payAccount ~= nil then
            table.insert(argumentShapes, "PayAccount=" .. describeValue(payAccount))
        end
        for index, extraArg in ipairs(extraArgs) do
            table.insert(argumentShapes, string.format("arg%d=%s", index + 2, describeValue(extraArg)))
        end
        log.warning(string.format("(%s) 心跳未找到有效账号ID，参数结构: %s",
            PAY_WXPAY_GMDT_XD, table.concat(argumentShapes, "; ")))
        return heartbeatResponse(useLegacyResponse, 500, "心跳数据解析失败: 缺少有效通道账号 ID")
    end

    local pluginName = channelAccount.plugin_name or PAY_WXPAY_GMDT_XD
    log.info(string.format("(%s) 心跳更新 SID，通道账号 ID: %s，来源:%s",
        pluginName, tostring(accountId), accountSource))

    local saved, saveError = saveAccountOption(accountId, "sid", sid, payAccount)
    if not saved then
        return heartbeatResponse(useLegacyResponse, 500,
            string.format("SID 保存失败: %s（账号ID:%s）", saveError, tostring(accountId)))
    end

    local status = heartbeatStatusFrom(heartbeatData, 4) or heartbeatStatusFrom(ctx, 4)
    local stateSynced = syncHeartbeatAccountState(accountId, channelAccount, status, pluginName)
    if not stateSynced then
        return heartbeatResponse(useLegacyResponse, 500, "账号状态更新失败")
    end

    return heartbeatResponse(useLegacyResponse, 200, "心跳正常")
end

return plugin
end
local gmdtPlugin = createGmdtPlugin()

local function createLinkQrcodePlugin()
---@diagnostic disable: undefined-global
-- 微信收款连接-XD监控端

local PAY_WXPAY_LINKQRCODE_XD = "jk_wechat_pc"

---@class plugin
local plugin = {}

local function trim(value)
    return tostring(value or ""):match("^%s*(.-)%s*$")
end

local function decodeTable(value)
    if type(value) == "table" then
        return value
    end
    if type(value) == "string" and value ~= "" then
        local ok, decoded = pcall(json.decode, value)
        if ok and type(decoded) == "table" then
            return decoded
        end
    end
    return {}
end

local function positiveId(value)
    if type(value) ~= "number" and type(value) ~= "string" then
        return nil
    end
    local id = tonumber(value)
    if id ~= nil and id > 0 then
        return id
    end
    return nil
end

local function normalizedKey(value)
    return tostring(value or ""):gsub("[^%w]", ""):lower()
end

local ACCOUNT_ID_KEY_PRIORITY = {
    "id",
    "accountid",
    "channelaccountid",
    "channelid",
}

local ACCOUNT_CONTAINER_KEY_PRIORITY = {
    "payaccount",
    "accountinfo",
    "channelaccount",
    "account",
    "data",
}

local function findAccountId(value, depth, allowScalar)
    if allowScalar then
        local scalarId = positiveId(value)
        if scalarId ~= nil then
            return scalarId
        end
    end

    local data = decodeTable(value)
    for _, expectedKey in ipairs(ACCOUNT_ID_KEY_PRIORITY) do
        for key, candidate in pairs(data) do
            if normalizedKey(key) == expectedKey then
                local id = positiveId(candidate)
                if id ~= nil then
                    return id
                end
            end
        end
    end

    if depth > 0 then
        for _, expectedKey in ipairs(ACCOUNT_CONTAINER_KEY_PRIORITY) do
            for key, nested in pairs(data) do
                if normalizedKey(key) == expectedKey then
                    local nestedId = findAccountId(nested, depth - 1, true)
                    if nestedId ~= nil then
                        return nestedId
                    end
                end
            end
        end
        for _, nested in ipairs(data) do
            local nestedId = findAccountId(nested, depth - 1, true)
            if nestedId ~= nil then
                return nestedId
            end
        end
    end
    return nil
end

local function describeValue(value)
    local valueType = type(value)
    if valueType == "table" then
        local keys = {}
        for key in pairs(value) do
            table.insert(keys, tostring(key))
        end
        table.sort(keys)
        return "table{" .. table.concat(keys, ",") .. "}"
    end
    if valueType == "string" then
        return string.format("string(len=%d)", #value)
    end
    return valueType .. "(" .. tostring(value) .. ")"
end

local function redactSecret(value, secret)
    local message = tostring(value or "")
    local secretText = tostring(secret or "")
    if secretText ~= "" then
        local escapedSecret = secretText:gsub("([^%w])", "%%%1")
        message = message:gsub(escapedSecret, "[REDACTED]")
    end
    return message:sub(1, 500)
end

local function saveAccountOption(accountId, key, value, payAccount)
    local callOk, saved, saveError = pcall(helper.channel_account_set_option, accountId, key, value)
    if callOk and saved == true then
        return true, ""
    end

    local failureType
    local failureDetail
    if not callOk then
        failureType = "保存接口调用异常"
        failureDetail = saved
    elseif saved == false then
        failureType = "保存接口返回 false"
        failureDetail = saveError
    else
        failureType = "保存接口未返回成功状态"
        failureDetail = saveError or describeValue(saved)
    end
    log.error(string.format(
        "(%s) 保存账号配置失败，账号ID:%s，配置项:%s，结果:%s，详情:%s，PayAccount:%s",
        PAY_WXPAY_LINKQRCODE_XD,
        tostring(accountId),
        tostring(key),
        failureType,
        redactSecret(failureDetail, value),
        describeValue(payAccount)
    ))
    return false, failureType
end

local function createError(message)
    return {
        code = 500,
        message = message,
        data = { type = types.PaymentResultTypes.ERROR },
    }
end

local function heartbeatResponse(legacy, code, message)
    local response = {
        code = code,
        message = message,
        err_code = code,
        err_message = message,
        data = {},
    }
    if legacy then
        return json.encode({ err_code = code, err_message = message })
    end
    return response
end

---@return types.PluginInfo
function plugin.pluginInfo()
    return {
        channels = {
            wxpay = {
                {
                    label = '微信收款连接-XD监控端',
                    value = PAY_WXPAY_LINKQRCODE_XD,
                    report = 1,
                    parse_msg = 0,
                    options = {
                        bind_client_name = 1,
                    },
                },
            },
        },
        options = {
            callback = 0,
            detection_interval = 0,
        },
    }
end


---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    if ctx.pay_channel ~= PAY_WXPAY_LINKQRCODE_XD then
        return { inputs = {} }
    end

    return {
        inputs = {
            {
                name = 'payment_link_sid',
                label = 'SID',
                type = types.InputTypes.INPUT,
                default = "",
                options = { tip = '可等待监控端心跳自动上报' },
                placeholder = "请输入 SID",
                rules = {
                    { required = true, trigger = { "input", "blur" }, message = "请输入 SID" },
                },
            },
            {
                name = 'payment_link_shop_id',
                label = '商户ID',
                type = types.InputTypes.INPUT,
                default = "",
                options = { tip = '可等待监控端心跳自动上报' },
                placeholder = "请输入商户ID",
                rules = {
                    { required = true, trigger = { "input", "blur" }, message = "请输入商户ID" },
                },
            },
        },
    }
end

---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local orderInfo = ctx.order_info
    local options = ctx.account_options or {}
    local sid = trimmedFirst(options.payment_link_sid, options.sid)
    local shopId = trimmedFirst(options.payment_link_shop_id, options.shop_id)

    if sid == "" then
        return createError("请输入 SID")
    end
    if shopId == "" then
        return createError("请输入商户ID")
    end

    local numericShopId = tonumber(shopId)
    if numericShopId == nil then
        return createError("商户ID格式错误")
    end

    local url = "https://sjtmgr.wxpapp.weixin.qq.com/sjt/linkqrcode/linkqrcode/create"
        .. "?sid=" .. helper.url_encode(sid)
        .. "&v=0.69.8"
    local orderId = tostring(orderInfo.order_id or "")
    local body = {
        v = "0.69.8",
        shop_id = numericShopId,
        link_qr_code = {
            remark = string.sub(orderId, 1, 10),
            payfee_type = "E_LINK_QRCODE_PAY_FEE_TYPE_FIX",
            image_description = { image_url_list = {} },
        },
        receipt_item = {
            {
                desc = string.sub(orderId, 11, 20),
                price = tonumber(orderInfo.trade_amount),
                quota_type = "E_LINK_QRCODE_QUOTATYPE_NO_LIMIT",
            },
        },
        option_type = {},
        sid = sid,
    }

    local result, requestError = http.request("POST", url, {
        timeout = "30s",
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Referer"] = "https://servicewechat.com/wx9291fe7dadf5a574/169/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9",
        },
        body = json.encode(body),
    })

    if requestError ~= nil or result == nil then
        return createError("创建订单请求失败: " .. tostring(requestError or "空响应"))
    end
    local statusCode = tonumber(result.status_code or result.status)
    if statusCode ~= nil and statusCode ~= 200 then
        return createError(string.format("创建订单请求失败，状态码: %d", statusCode))
    end
    if result.body == nil or result.body == "" then
        return createError("创建订单失败: 返回内容为空")
    end

    local decodeOk, response = pcall(json.decode, result.body)
    if not decodeOk or type(response) ~= "table" then
        return createError("创建订单失败: 无法解析返回数据")
    end
    if tonumber(response.errcode) ~= 0 then
        return createError(response.msg or response.errmsg or "创建订单失败")
    end

    local data = response.data or {}
    local receiptId = trim(data.receipt_id)
    local qrcode = trim(data.qr_code_url)
    if receiptId == "" then
        return createError("创建订单失败: 未获取到 receipt_id")
    end
    if qrcode == "" then
        return createError("创建订单失败: 未获取到二维码")
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = qrcode,
            url = "",
            content = "",
            out_trade_no = receiptId,
        },
    }
end

---@param ctx table|string
---@param legacyRequest? string
---@return table|string
function plugin.heartbeat(ctx, legacyRequest)
    local legacy = legacyRequest ~= nil or type(ctx) ~= "table"
    local context = decodeTable(ctx)
    local payAccount = context.PayAccount or context.pay_account or context.payAccount
    local account
    local heartbeatData

    if legacy then
        account = decodeTable(
            context.account_info or context.accountInfo or context.AccountInfo
                or context.channel_account or context.channelAccount or context.ChannelAccount
                or payAccount
                or context.account or context.Account or context
        )
        heartbeatData = decodeTable(legacyRequest)
    else
        account = decodeTable(ctx.account_info or ctx.channel_account or ctx.account or payAccount)
        local request = decodeTable(
            ctx.heartbeat_request or ctx.heartbeat_data or ctx.request or ctx.params or ctx.data or ctx
        )
        heartbeatData = decodeTable(request.body or request.params or request)
    end

    local extData = decodeTable(heartbeatData.ext_data)
    local session = heartbeatSessionForKind(heartbeatData, "payment-link", 4)
        or heartbeatSessionForKind(ctx, "payment-link", 4)
    local sid = trim(session and session.sid or extData.sid)
    local shopId = trim(session and (session.shop_id or session.shopId) or extData.shop_id)
    local accountId = findAccountId(payAccount, 4, true)
    local accountSource = "PayAccount"
    if accountId == nil then
        accountId = findAccountId(account, 4, true)
        accountSource = "account"
    end
    if accountId == nil then
        accountId = findAccountId(ctx, 4, true)
        accountSource = "ctx"
    end
    if accountId == nil then
        accountId = findAccountId(heartbeatData, 4, false)
        accountSource = "request"
    end
    if accountId == nil or sid == "" then
        if accountId == nil then
            log.warning(string.format("(%s) 心跳未找到有效账号ID，ctx:%s，request:%s，PayAccount:%s",
                PAY_WXPAY_LINKQRCODE_XD,
                describeValue(ctx),
                describeValue(legacyRequest),
                describeValue(payAccount)))
        end
        return heartbeatResponse(legacy, 500, "心跳数据解析失败")
    end

    local sidSaved, sidError = saveAccountOption(accountId, "payment_link_sid", sid, payAccount)
    if not sidSaved then
        return heartbeatResponse(legacy, 500,
            string.format("SID 保存失败: %s（账号ID:%s）", sidError, tostring(accountId)))
    end
    if shopId ~= "" then
        local shopSaved, shopError = saveAccountOption(accountId, "payment_link_shop_id", shopId, payAccount)
        if not shopSaved then
            return heartbeatResponse(legacy, 500,
                string.format("商户ID保存失败: %s（账号ID:%s）", shopError, tostring(accountId)))
        end
    end

    local status = heartbeatStatusFrom(heartbeatData, 4) or heartbeatStatusFrom(ctx, 4)
    local stateSynced = syncHeartbeatAccountState(accountId, account, status, PAY_WXPAY_LINKQRCODE_XD)
    if not stateSynced then
        return heartbeatResponse(legacy, 500, "账号状态更新失败")
    end

    local updatedFields = shopId ~= "" and "SID 和商户ID" or "SID"
    log.info(string.format("(%s) 心跳更新 %s，账号: %s，来源:%s",
        PAY_WXPAY_LINKQRCODE_XD, updatedFields, tostring(accountId), accountSource))
    return heartbeatResponse(legacy, 200, "心跳正常")
end

return plugin
end
local linkQrcodePlugin = createLinkQrcodePlugin()

local function createSkdPlugin()
---@diagnostic disable: undefined-global
-- 微信收款单-XD监控端

local PAY_WXPAY_SKD_XD = "jk_wechat_pc"
local MINI_PROGRAM_VERSION = "3.15.10"

local GATEWAY = {
    RECEIPT_MD = "https://payapp.wechatpay.cn/receiptmdmgr",
    RECEIPT_SJT = "https://payapp.wechatpay.cn/receiptsjtmgr",
    RECEIPT_WX = "https://payapp.wechatpay.cn/receiptwxmgr",
}

local WINDOWS_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    .. "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 "
    .. "MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows "
    .. "WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581"
local REFERER = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html"

---@class plugin
local plugin = {}

local function trim(value)
    return tostring(value or ""):match("^%s*(.-)%s*$")
end

local function decodeTable(value)
    if type(value) == "table" then
        return value
    end
    if type(value) == "string" and value ~= "" then
        local ok, decoded = pcall(json.decode, value)
        if ok and type(decoded) == "table" then
            return decoded
        end
    end
    return {}
end

local function positiveId(value)
    if type(value) ~= "number" and type(value) ~= "string" then
        return nil
    end
    local id = tonumber(value)
    if id ~= nil and id > 0 then
        return id
    end
    return nil
end

local function normalizedKey(value)
    return tostring(value or ""):gsub("[^%w]", ""):lower()
end

local ACCOUNT_ID_KEY_PRIORITY = {
    "id",
    "accountid",
    "channelaccountid",
    "channelid",
}

local ACCOUNT_CONTAINER_KEY_PRIORITY = {
    "payaccount",
    "accountinfo",
    "channelaccount",
    "account",
    "data",
}

local function findAccountId(value, depth, allowScalar)
    if allowScalar then
        local scalarId = positiveId(value)
        if scalarId ~= nil then
            return scalarId
        end
    end

    local data = decodeTable(value)
    for _, expectedKey in ipairs(ACCOUNT_ID_KEY_PRIORITY) do
        for key, candidate in pairs(data) do
            if normalizedKey(key) == expectedKey then
                local id = positiveId(candidate)
                if id ~= nil then
                    return id
                end
            end
        end
    end

    if depth > 0 then
        for _, expectedKey in ipairs(ACCOUNT_CONTAINER_KEY_PRIORITY) do
            for key, nested in pairs(data) do
                if normalizedKey(key) == expectedKey then
                    local nestedId = findAccountId(nested, depth - 1, true)
                    if nestedId ~= nil then
                        return nestedId
                    end
                end
            end
        end
        for _, nested in ipairs(data) do
            local nestedId = findAccountId(nested, depth - 1, true)
            if nestedId ~= nil then
                return nestedId
            end
        end
    end
    return nil
end

local function describeValue(value)
    local valueType = type(value)
    if valueType == "table" then
        local keys = {}
        for key in pairs(value) do
            table.insert(keys, tostring(key))
        end
        table.sort(keys)
        return "table{" .. table.concat(keys, ",") .. "}"
    end
    if valueType == "string" then
        return string.format("string(len=%d)", #value)
    end
    return valueType .. "(" .. tostring(value) .. ")"
end

local function redactSecret(value, secret)
    local message = tostring(value or "")
    local secretText = tostring(secret or "")
    if secretText ~= "" then
        local escapedSecret = secretText:gsub("([^%w])", "%%%1")
        message = message:gsub(escapedSecret, "[REDACTED]")
    end
    return message:sub(1, 500)
end

local function tableIsEmpty(value)
    return type(value) ~= "table" or next(value) == nil
end

local function createError(message)
    return {
        code = 500,
        message = message,
        data = { type = types.PaymentResultTypes.ERROR },
    }
end

local function statusResponse(code, message, data)
    return json.encode({
        err_code = code,
        err_message = message,
        data = data or {},
    })
end

local function heartbeatResponse(useLegacyResponse, code, message, data)
    if useLegacyResponse then
        return statusResponse(code, message, data)
    end
    return {
        code = code,
        message = message,
        err_code = code,
        err_message = message,
        data = data or {},
    }
end

local function urlEncode(value)
    local ok, encoded = pcall(helper.url_encode, tostring(value or ""))
    if ok and encoded ~= nil then
        return tostring(encoded)
    end
    return tostring(value or "")
end

local function withQuery(base, params)
    local query = {}
    for _, param in ipairs(params) do
        table.insert(query, urlEncode(param[1]) .. "=" .. urlEncode(param[2]))
    end
    return base .. "?" .. table.concat(query, "&")
end

local function requestHeaders(userAgent, includeAccept)
    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = userAgent or WINDOWS_USER_AGENT,
        ["Content-Type"] = "application/json",
        ["Referer"] = REFERER,
        ["Accept-Language"] = "zh-CN,zh;q=0.9",
    }
    if includeAccept then
        headers["Accept"] = "*/*"
    end
    return headers
end

local function requestJson(method, url, options, accountId, operation)
    local callOk, response, requestError = pcall(http.request, method, url, options or {})
    if not callOk then
        log.warning(string.format("[%s] (%s) %s请求异常: %s", PAY_WXPAY_SKD_XD,
            tostring(accountId or "-"), operation, tostring(response)))
        return nil, operation .. "请求异常"
    end
    if requestError ~= nil or response == nil then
        log.warning(string.format("[%s] (%s) %s请求失败: %s", PAY_WXPAY_SKD_XD,
            tostring(accountId or "-"), operation, tostring(requestError or "空响应")))
        return nil, operation .. "请求失败"
    end

    local statusCode = tonumber(response.status_code or response.status)
    if statusCode ~= nil and statusCode ~= 200 then
        local message = string.format("%s失败，状态码: %d", operation, statusCode)
        log.warning(string.format("[%s] (%s) %s", PAY_WXPAY_SKD_XD, tostring(accountId or "-"), message))
        return nil, message
    end
    if response.body == nil or response.body == "" then
        local message = operation .. "失败，返回数据为空"
        log.warning(string.format("[%s] (%s) %s", PAY_WXPAY_SKD_XD, tostring(accountId or "-"), message))
        return nil, message
    end

    local decodeOk, data = pcall(json.decode, response.body)
    if not decodeOk or type(data) ~= "table" then
        local message = operation .. "失败，返回数据无法解析"
        log.warning(string.format("[%s] (%s) %s", PAY_WXPAY_SKD_XD, tostring(accountId or "-"), message))
        return nil, message
    end

    local errCode = tonumber(data.errcode)
    if errCode == nil or errCode ~= 0 then
        local message = data.msg or data.errmsg or operation .. "失败"
        log.warning(string.format("[%s] (%s) %s，错误码: %s", PAY_WXPAY_SKD_XD,
            tostring(accountId or "-"), tostring(message), tostring(data.errcode or "-1")))
        return nil, tostring(message)
    end
    return data, nil
end

local function setAccountOption(accountId, key, value, payAccount)
    local callOk, saved, saveError = pcall(helper.channel_account_set_option, accountId, key, value)
    if callOk and saved == true then
        return true, ""
    end

    local failureType
    local failureDetail
    if not callOk then
        failureType = "保存接口调用异常"
        failureDetail = saved
    elseif saved == false then
        failureType = "保存接口返回 false"
        failureDetail = saveError
    else
        failureType = "保存接口未返回成功状态"
        failureDetail = saveError or describeValue(saved)
    end
    log.error(string.format(
        "(%s) 保存账号配置失败，账号ID:%s，配置项:%s，结果:%s，详情:%s，PayAccount:%s",
        PAY_WXPAY_SKD_XD,
        tostring(accountId),
        tostring(key),
        failureType,
        redactSecret(failureDetail, value),
        describeValue(payAccount)
    ))
    return false, failureType
end

local function setAccountOnline(accountId)
    local ok, result = pcall(helper.channel_account_online, accountId)
    return ok and result == true
end

local function setAccountOffline(accountId)
    local ok, result = pcall(helper.channel_account_offline, accountId)
    return ok and result == true
end

---@return types.PluginInfo
function plugin.pluginInfo()
    return {
        channels = {
            wxpay = {
                {
                    label = '微信收款单-XD监控端',
                    value = PAY_WXPAY_SKD_XD,
                    report = 1,
                    parse_msg = 0,
                    options = {
                        need_check_online = 1,
                        bind_client_name = 1,
                    },
                },
            },
        },
        options = {
            callback = 0,
            detection_interval = 0,
        },
    }
end

---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    if ctx.pay_channel ~= PAY_WXPAY_SKD_XD then
        return { inputs = {} }
    end

    return {
        inputs = {
            {
                name = 'receipt_sid',
                label = 'SID',
                type = types.InputTypes.INPUT,
                default = "",
                options = { tip = '' },
                placeholder = "请输入SID或等待上报",
            },
            {
                name = 'receipt_account_list',
                label = '账号列表(一行一组)',
                type = "textarea",
                default = "",
                when = "this.formModel.options.receipt_sid",
                hidden_list = 1,
                placeholder = "清空后会重新获取",
                options = {
                    tip = '清空后保存会重新获取；如需切换账号，可复制对应账号ID和账号类型到下方输入框',
                },
            },
            {
                name = 'receipt_aid',
                label = '账号ID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.receipt_sid",
                placeholder = "请输入账号ID",
                options = { tip = "请从账号列表选择一组账号信息的账号ID" },
            },
            {
                name = 'receipt_account_type',
                label = '账号类型',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.receipt_sid",
                placeholder = "请输入账号类型[1或3]",
                options = { tip = "请填写账号列表中对应的账号类型" },
            },
            {
                name = 'receipt_shop_id',
                label = '店铺ID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.receipt_sid",
                options = { tip = '店铺ID会在保存账号时刷新' },
                placeholder = "请输入商户ID",
            },
        },
    }
end

function plugin._get_gateway_by_account_type(accountType)
    accountType = tonumber(accountType)
    if accountType == 1 then
        return GATEWAY.RECEIPT_MD
    end
    if accountType == 3 then
        return GATEWAY.RECEIPT_SJT
    end
    return nil
end

---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local orderInfo = ctx.order_info or {}
    local accountInfo = ctx.account_info or {}
    local options = ctx.account_options or {}
    local sid = trimmedFirst(options.receipt_sid, options.sid)
    local shopId = trimmedFirst(options.receipt_shop_id, options.shop_id)
    local accountId = trimmedFirst(options.receipt_aid, options.aid)
    local accountType = trimmedFirst(options.receipt_account_type, options.account_type)

    if sid == "" then
        return createError("缺少必要参数: sid")
    end
    if shopId == "" then
        return createError("缺少必要参数: shop_id")
    end
    if accountId == "" then
        return createError("缺少必要参数: aid")
    end
    if accountType == "" then
        return createError("缺少必要参数: account_type")
    end

    local numericShopId = tonumber(shopId)
    if numericShopId == nil then
        return createError("店铺ID格式错误")
    end
    local gateway = plugin._get_gateway_by_account_type(accountType)
    if gateway == nil then
        return createError("不支持的账号类型，仅支持1或3")
    end

    local createUrl = withQuery(gateway .. "/receipt/create", {
        { "account_type", accountType },
        { "account_id", accountId },
        { "sid", sid },
    })
    local body = {
        miniprogram_version = MINI_PROGRAM_VERSION,
        fee = orderInfo.trade_amount,
        remark = orderInfo.order_id,
        remark_pic_urls = "",
        option_list = {},
        receipt_item_list = {},
        shop_id = numericShopId,
        sid = sid,
    }

    log.info(string.format("(%s) %s(%s) 创建订单", PAY_WXPAY_SKD_XD,
        tostring(accountInfo.name or ""), tostring(accountInfo.id or "")))
    local createResponse, createRequestError = requestJson("POST", createUrl, {
        timeout = "30s",
        headers = requestHeaders(WINDOWS_USER_AGENT, false),
        body = json.encode(body),
    }, accountInfo.id, "创建订单")
    if createResponse == nil then
        return createError(createRequestError)
    end

    local receipt = createResponse.data and createResponse.data.receipt or {}
    local receiptId = trim(receipt.receipt_id)
    if receiptId == "" then
        return createError("创建订单失败，未获取到receipt_id")
    end

    local qrcodeUrl = withQuery(gateway .. "/receipt/getwxacode", {
        { "miniprogram_version", MINI_PROGRAM_VERSION },
        { "wxacode_path_type", 1 },
        { "receipt_id", receiptId },
        { "account_id", accountId },
        { "account_type", accountType },
        { "sid", sid },
    })
    local qrcodeResponse, qrcodeRequestError = requestJson("GET", qrcodeUrl, {
        timeout = "30s",
        headers = requestHeaders(WINDOWS_USER_AGENT, true),
    }, accountInfo.id, "获取二维码")
    if qrcodeResponse == nil then
        return createError(qrcodeRequestError)
    end

    local qrcode = trim(qrcodeResponse.data and qrcodeResponse.data.qrcode)
    if qrcode == "" then
        return createError("获取二维码失败，二维码内容为空")
    end
    local saveCallOk, saved, filePath = pcall(helper.save_image_cache_base64, qrcode)
    if not saveCallOk or not saved or trim(filePath) == "" then
        return createError("二维码保存失败")
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode_file = filePath,
            qrcode = "",
            url = "",
            content = "",
            out_trade_no = receiptId,
        },
    }
end

function plugin.getAccountList(sid)
    local url = withQuery(GATEWAY.RECEIPT_WX .. "/account/list", {
        { "miniprogram_version", MINI_PROGRAM_VERSION },
        { "sid", sid },
    })
    local response, requestError = requestJson("GET", url, {
        timeout = "30s",
        headers = requestHeaders(WINDOWS_USER_AGENT, true),
    }, "-", "获取账号列表")
    if response == nil then
        return nil, requestError
    end
    if response.data and type(response.data.account_list) == "table" then
        return response.data.account_list, nil
    end
    return nil, "账号列表为空"
end

---@param ctx table|string
---@param legacyRequest? table|string
---@return table|string
function plugin.heartbeat(ctx, legacyRequest)
    local useLegacyArgs = legacyRequest ~= nil or type(ctx) ~= "table"
    local context = decodeTable(ctx)
    local payAccount = context.PayAccount or context.pay_account or context.payAccount
    local accountInfo
    local heartbeatData

    if useLegacyArgs then
        accountInfo = decodeTable(
            context.account_info or context.accountInfo or context.AccountInfo
                or context.channel_account or context.channelAccount or context.ChannelAccount
                or payAccount
                or context.account or context.Account or context
        )
        heartbeatData = decodeTable(legacyRequest)
    else
        accountInfo = decodeTable(ctx.account_info or ctx.channel_account or ctx.account or payAccount)
        local request = decodeTable(
            ctx.heartbeat_request or ctx.heartbeat_data or ctx.request or ctx.params or ctx.data or ctx
        )
        heartbeatData = decodeTable(request.body or request.params or request.query or request)
    end

    local extData = decodeTable(heartbeatData.ext_data)
    local session = heartbeatSessionForKind(heartbeatData, "payment-order", 4)
        or heartbeatSessionForKind(ctx, "payment-order", 4)
    local sid = trim(session and session.sid or extData.sid)
    local accountId = findAccountId(payAccount, 4, true)
    local accountSource = "PayAccount"
    if accountId == nil then
        accountId = findAccountId(accountInfo, 4, true)
        accountSource = "accountInfo"
    end
    if accountId == nil then
        accountId = findAccountId(ctx, 4, true)
        accountSource = "ctx"
    end
    if accountId == nil then
        accountId = findAccountId(heartbeatData, 4, false)
        accountSource = "request"
    end
    if accountId == nil or sid == "" then
        if accountId == nil then
            log.warning(string.format("(%s) 心跳未找到有效账号ID，ctx:%s，request:%s，PayAccount:%s",
                PAY_WXPAY_SKD_XD,
                describeValue(ctx),
                describeValue(legacyRequest),
                describeValue(payAccount)))
        end
        return heartbeatResponse(useLegacyArgs, 500, "心跳数据解析失败")
    end
    local saved, saveError = setAccountOption(accountId, "receipt_sid", sid, payAccount)
    if not saved then
        return heartbeatResponse(useLegacyArgs, 500,
            string.format("SID 保存失败: %s（账号ID:%s）", saveError, tostring(accountId)))
    end
    local status = heartbeatStatusFrom(heartbeatData, 4) or heartbeatStatusFrom(ctx, 4)
    local stateSynced = syncHeartbeatAccountState(accountId, accountInfo, status, PAY_WXPAY_SKD_XD)
    if not stateSynced then
        return heartbeatResponse(useLegacyArgs, 500, "账号状态更新失败")
    end

    log.info(string.format("(%s) 心跳更新SID，账号: %s，来源:%s",
        PAY_WXPAY_SKD_XD, tostring(accountId), accountSource))
    return heartbeatResponse(useLegacyArgs, 200, "心跳正常")
end

function plugin._get_shop_id(sid, accountId, accountType)
    local gateway = plugin._get_gateway_by_account_type(accountType)
    if gateway == nil then
        return nil, "不支持的账号类型"
    end
    local url = withQuery(gateway .. "/account/get", {
        { "miniprogram_version", MINI_PROGRAM_VERSION },
        { "account_id", accountId },
        { "account_type", accountType },
        { "sid", sid },
    })
    local response, requestError = requestJson("GET", url, {
        timeout = "30s",
        headers = requestHeaders(WINDOWS_USER_AGENT, false),
    }, accountId, "获取商户ID")
    if response == nil then
        return nil, requestError
    end

    local shopList = response.data and response.data.auth_shop_list
    if type(shopList) == "table" and #shopList > 0 and shopList[1].shop_id ~= nil then
        return tostring(shopList[1].shop_id), nil
    end
    return nil, "获取商户ID失败"
end

function plugin._verify_and_init_account(accountInfo, options)
    local accountRecordId = accountInfo.id
    if accountRecordId == nil then
        return false, "缺少通道账号ID"
    end

    options.receipt_sid = trimmedFirst(options.receipt_sid, options.sid)
    options.receipt_aid = trimmedFirst(options.receipt_aid, options.aid)
    options.receipt_account_type = trimmedFirst(options.receipt_account_type, options.account_type)
    if options.receipt_sid == "" then
        return false, "暂未填写sid"
    end

    if trimmedFirst(options.receipt_account_list, options.account_list) == "" then
        local accountList, listError = plugin.getAccountList(options.receipt_sid)
        if accountList == nil then
            return false, listError
        end

        local lines = {}
        local activatedAccounts = {}
        for _, account in ipairs(accountList) do
            if account.account_status == "ACTIVATED" then
                table.insert(lines, string.format("账号ID:%s|账号类型:%s|商户名称:%s",
                    tostring(account.account_id or ""), tostring(account.account_type or ""),
                    tostring(account.account_name or "")))
                table.insert(activatedAccounts, account)
            end
        end
        if #activatedAccounts == 0 then
            return false, "没有可用的已激活账号"
        end

        local accountListText = table.concat(lines, "\n")
        if not setAccountOption(accountRecordId, "receipt_account_list", accountListText) then
            return false, "账号列表保存失败"
        end
        options.receipt_account_list = accountListText

        local selected = activatedAccounts[1]
        options.receipt_aid = trim(selected.account_id)
        options.receipt_account_type = trim(selected.account_type)
        if not setAccountOption(accountRecordId, "receipt_aid", options.receipt_aid)
            or not setAccountOption(accountRecordId, "receipt_account_type", options.receipt_account_type) then
            return false, "默认账号保存失败"
        end
    end

    if options.receipt_aid == "" then
        return false, "请选择一个账号"
    end
    if options.receipt_account_type == "" then
        return false, "请选择一个账号类型"
    end
    if plugin._get_gateway_by_account_type(options.receipt_account_type) == nil then
        return false, "不支持的账号类型，仅支持1或3"
    end

    local shopId, shopError = plugin._get_shop_id(
        options.receipt_sid,
        options.receipt_aid,
        options.receipt_account_type
    )
    if shopId == nil then
        return false, shopError
    end
    if not setAccountOption(accountRecordId, "receipt_shop_id", shopId) then
        return false, "商户ID保存失败"
    end
    options.receipt_shop_id = shopId
    return true, ""
end

---@param ctx table|string
---@param legacyChannelInfo? table|string
---@return string
function plugin.onAccountChanged(ctx, legacyChannelInfo)
    local accountInfo
    local options
    if legacyChannelInfo ~= nil or type(ctx) ~= "table" then
        accountInfo = decodeTable(ctx)
        options = decodeTable(accountInfo.options)
    else
        accountInfo = decodeTable(ctx.account_info or ctx.channel_account or ctx.account or ctx)
        options = decodeTable(ctx.account_options)
        if tableIsEmpty(options) then
            options = decodeTable(accountInfo.options)
        end
    end

    if accountInfo.id == nil then
        return statusResponse(500, "缺少通道账号ID")
    end
    if trimmedFirst(options.receipt_account_list, options.account_list) == "" then
        for _, key in ipairs({ "receipt_aid", "receipt_account_type", "receipt_shop_id" }) do
            if not setAccountOption(accountInfo.id, key, "") then
                return statusResponse(500, "账号配置重置失败: " .. key)
            end
            options[key] = ""
        end
    end

    local success, message = plugin._verify_and_init_account(accountInfo, options)
    if not success then
        if accountInfo.online == 1 then
            setAccountOffline(accountInfo.id)
        end
        return statusResponse(500, message)
    end
    if accountInfo.online ~= 1 and not setAccountOnline(accountInfo.id) then
        return statusResponse(500, "账号上线失败")
    end
    return statusResponse(200, "账号验证成功")
end

return plugin
end
local skdPlugin = createSkdPlugin()


local PAY_WXPAY_PC = "jk_wechat_pc"
local MODE_PC = "pc"
local MODE_GMDT = "gmdt"
local MODE_LINKQRCODE = "linkqrcode"
local MODE_SKD = "skd"

local MODE_PLUGINS = {
    [MODE_GMDT] = gmdtPlugin,
    [MODE_LINKQRCODE] = linkQrcodePlugin,
    [MODE_SKD] = skdPlugin,
}

local MODE_ALIASES = {
    platform = MODE_GMDT,
    self = MODE_PC,
    receipt = MODE_SKD,
    smallbook = MODE_LINKQRCODE,
}

local KNOWN_MODES = {
    [MODE_PC] = true,
    [MODE_GMDT] = true,
    [MODE_LINKQRCODE] = true,
    [MODE_SKD] = true,
}

local function decodeJsonObject(value)
    if type(value) == "table" then
        return value
    end
    if type(value) ~= "string" or value == "" then
        return nil
    end

    local ok, decoded = pcall(json.decode, value)
    if ok and type(decoded) == "table" then
        return decoded
    end
    return nil
end

local function normalizeHeartbeatStatus(value)
    if type(value) ~= "string" then
        return nil
    end
    local status = string.lower(string.match(value, "^%s*(.-)%s*$"))
    if status == "online" or status == "offline" then
        return status
    end
    return nil
end

local function accountOnlineState(account)
    local value = type(account) == "table" and account.online or nil
    if value == true or value == 1 or value == "1" then
        return true
    end
    if value == false or value == 0 or value == "0" then
        return false
    end
    return nil
end

local function tableKeys(value)
    local keys = {}
    if type(value) == "table" then
        for key in pairs(value) do
            keys[#keys + 1] = tostring(key)
        end
        table.sort(keys)
    end
    return table.concat(keys, ",")
end

local accountContainerKeys = {
    "account_info",
    "channel_account",
    "account",
    "accountInfo",
    "channelAccount"
}

local function accountFrom(value)
    if type(value) ~= "table" then
        return nil, nil
    end

    local function match(candidate)
        if type(candidate) ~= "table" then
            return nil, nil
        end
        local accountId = tonumber(candidate.id or candidate.account_id or candidate.channel_account_id or candidate.channel_id)
        if accountId ~= nil and accountId > 0 and accountId % 1 == 0 then
            return candidate, accountId
        end
        return nil, nil
    end

    local account, accountId = match(value)
    if account ~= nil then
        return account, accountId
    end

    for _, key in ipairs(accountContainerKeys) do
        account, accountId = match(decodeJsonObject(value[key]))
        if account ~= nil then
            return account, accountId
        end
    end

    local data = decodeJsonObject(value.data)
    if data ~= nil then
        account, accountId = match(data)
        if account ~= nil then
            return account, accountId
        end
        for _, key in ipairs(accountContainerKeys) do
            account, accountId = match(decodeJsonObject(data[key]))
            if account ~= nil then
                return account, accountId
            end
        end
    end

    return nil, nil
end

local heartbeatContainerKeys = {
    "heartbeat",
    "heartbeat_request",
    "request_data",
    "request",
    "body",
    "params",
    "request_info",
    "data"
}

local function extDataFrom(value, depth)
    if type(value) ~= "table" or depth < 0 then
        return nil
    end

    if value.ext_data ~= nil then
        return decodeJsonObject(value.ext_data)
    end

    for _, key in ipairs(heartbeatContainerKeys) do
        local nested = decodeJsonObject(value[key])
        local extData = extDataFrom(nested, depth - 1)
        if extData ~= nil then
            return extData
        end
    end
    return nil
end

local function heartbeatExtDataFrom(firstData, secondData)
    return extDataFrom(secondData, 2) or extDataFrom(firstData, 3)
end

local modeKeys = {
    "pay_mode",
    "payMode",
    "wechat_mode",
    "wechatMode",
    "mode",
}

local modeContainerKeys = {
    "account_info",
    "accountInfo",
    "channel_account",
    "channelAccount",
    "pay_account",
    "payAccount",
    "PayAccount",
    "account",
    "heartbeat_request",
    "heartbeat_data",
    "request",
    "params",
    "body",
    "ext_data",
    "data",
}

local function knownMode(value)
    local mode = type(value) == "string" and value or tostring(value or "")
    if MODE_ALIASES[mode] ~= nil then
        return MODE_ALIASES[mode]
    end
    if KNOWN_MODES[mode] then
        return mode
    end
    return nil
end

local function inferModeFromOptions(value)
    local options = decodeJsonObject(value)
    if options == nil then
        return nil
    end
    for _, key in ipairs(modeKeys) do
        local mode = knownMode(options[key])
        if mode ~= nil then
            return mode
        end
    end
    if options.receipt_sid ~= nil
        or options.receipt_aid ~= nil
        or options.receipt_account_type ~= nil
        or options.receipt_account_list ~= nil
        or options.receipt_shop_id ~= nil then
        return MODE_SKD
    end
    if options.payment_link_sid ~= nil or options.payment_link_shop_id ~= nil then
        return MODE_LINKQRCODE
    end
    if options.aid ~= nil or options.account_type ~= nil or options.account_list ~= nil then
        return MODE_SKD
    end
    if options.shop_id ~= nil then
        return MODE_LINKQRCODE
    end
    if options.qrcode ~= nil or options.qrcode_file ~= nil or options.type ~= nil then
        return MODE_PC
    end
    if options.sid ~= nil then
        return MODE_GMDT
    end
    return nil
end

local function modeFrom(value, depth)
    local directMode = knownMode(value)
    if directMode ~= nil then
        return directMode
    end

    local data = decodeJsonObject(value)
    if data == nil then
        return nil
    end
    for _, key in ipairs(modeKeys) do
        local mode = knownMode(data[key])
        if mode ~= nil then
            return mode
        end
    end

    local inferredMode = inferModeFromOptions(data.account_options or data.options)
    if inferredMode ~= nil then
        return inferredMode
    end

    if depth > 0 then
        for _, key in ipairs(modeContainerKeys) do
            local mode = modeFrom(data[key], depth - 1)
            if mode ~= nil then
                return mode
            end
        end
    end
    return nil
end

local function modeFromArguments(...)
    for index = 1, select("#", ...) do
        local value = select(index, ...)
        local mode = modeFrom(value, 4)
        if mode ~= nil then
            return mode
        end
    end
    return nil
end

local function unsupportedModeResponse(mode)
    return {
        code = 500,
        message = "不支持的微信模式: " .. tostring(mode or "未知"),
        data = {
            type = types.PaymentResultTypes.ERROR,
        },
    }
end

local function withReportChannel(patterns)
    local rules = {}
    for _, pattern in ipairs(patterns) do
        local rule = { channel_code = PAY_WXPAY_PC }
        for key, value in pairs(pattern) do
            rule[key] = value
        end
        rules[#rules + 1] = rule
    end
    return rules
end

local plugin = {}

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    return {
        channels = {
            ["wxpay"] = { {
                label = "微信-PC全能监控",
                value = PAY_WXPAY_PC,
                report = 1,
                parse_msg = 1,
                options = {
                    use_add_amount = 1,
                    use_pay_codes = 1,
                    need_check_online = 1,
                },
                info = "微信PC、个码动态、收款连接、收款单（客户端上报）",
            } },
        },
    }
end

--- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    if type(ctx) ~= "table" or ctx.pay_channel ~= PAY_WXPAY_PC then
        return { inputs = {} }
    end

    return {
        inputs = {
            {
                name = "pay_mode",
                label = "收款方式",
                type = types.InputTypes.RADIO,
                default = "self",
                options = {
                    tip = "请选择微信收款方式",
                },
                placeholder = "请选择收款方式",
                values = { {
                    label = "自己上传",
                    value = "self",
                }, {
                    label = "个码动态",
                    value = "platform",
                }, {
                    label = "收款单",
                    value = "receipt",
                }, {
                    label = "收款连接",
                    value = "smallbook",
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择收款方式",
                } },
            },
            {
                name = 'type',
                label = '收款码类型',
                type = types.InputTypes.SELECT,
                default = "url",
                when = "this.formModel.options.pay_mode == 'self'",
                placeholder = "请选择收款码类型",
                values = {
                    { label = "地址", value = "url" },
                    { label = "图片", value = "image" },
                },
                rules = {
                    { required = true, trigger = { "input", "blur" }, message = "请选择收款码类型" },
                },
            },
            {
                name = 'qrcode',
                label = '收款码地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.pay_mode == 'self' && this.formModel.options.type == 'url'",
                options = {
                    append_deqrocde = 1,
                    tip = '个人码 赞赏码 经营码 商业码 微信全能码',
                },
                rules = {
                    { required = true, trigger = { "input", "blur" }, message = "请输入收款码地址" },
                },
            },
            {
                name = 'qrcode_file',
                label = '收款码图片',
                type = types.InputTypes.IMAGE,
                default = "",
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.pay_mode == 'self' && this.formModel.options.type == 'image'",
                rules = {
                    { required = true, trigger = { "input", "blur" }, message = "请上传收款码图片" },
                },
            },
            {
                name = 'sid',
                label = 'SID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'platform'",
                placeholder = "请输入SID或等待客户端上报",
                options = { tip = '动态个人码 SID，可由PC监控端通过心跳自动上报' },
            },
            {
                name = 'receipt_sid',
                label = 'SID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt'",
                placeholder = "请输入SID或等待客户端上报",
                options = { tip = '收款单 SID，可由PC监控端通过心跳自动上报' },
            },
            {
                name = 'payment_link_sid',
                label = 'SID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'smallbook'",
                placeholder = "请输入SID或等待客户端上报",
                options = { tip = '收款链接 SID，可由PC监控端通过心跳自动上报' },
            },
            {
                name = 'receipt_account_list',
                label = '账号列表(一行一组)',
                type = "textarea",
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt' && this.formModel.options.receipt_sid",
                hidden_list = 1,
                placeholder = "清空后会重新获取",
                options = {
                    tip = '清空后保存会重新获取；如需切换账号，可复制对应账号ID和账号类型到下方输入框',
                },
            },
            {
                name = 'receipt_aid',
                label = '账号ID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt' && this.formModel.options.receipt_sid",
                placeholder = "请输入账号ID",
                options = { tip = '请从账号列表选择一组账号信息的账号ID' },
            },
            {
                name = 'receipt_account_type',
                label = '账号类型',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt' && this.formModel.options.receipt_sid",
                placeholder = "请输入账号类型[1或3]",
                options = { tip = '请填写账号列表中对应的账号类型' },
            },
            {
                name = 'receipt_shop_id',
                label = '店铺/商户ID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt'",
                placeholder = "请输入店铺/商户ID或等待自动获取",
                options = { tip = '收款单会在保存账号时刷新' },
            },
            {
                name = 'payment_link_shop_id',
                label = '店铺/商户ID',
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'smallbook'",
                placeholder = "请输入店铺/商户ID或等待自动获取",
                options = { tip = '收款链接可由心跳自动上报' },
            },
        },
    }
end

--- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local mode = modeFrom(ctx, 4) or MODE_PC
    local modePlugin = MODE_PLUGINS[mode]
    if modePlugin ~= nil then
        return modePlugin.create(ctx)
    end
    if mode ~= MODE_PC then
        return unsupportedModeResponse(mode)
    end

    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options or {}

    if vAccountOptions['type'] == 'image' then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = vAccountOptions['qrcode_file'],
                qrcode = "",
                url = "",
                content = "",
                out_trade_no = '',
            }
        }
    end

    local qrcode = vAccountOptions['qrcode'] or ""

    -- 检查二维码链接是否以http开头
    if string.match(qrcode, "^http") then
        -- 如果是http开头的链接，直接使用该链接
        qrcode = vAccountOptions['qrcode']
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = qrcode,
            url = "",
            content = "",
            out_trade_no = '',
        }
    }
end

--- 支付回调
---@param ctx types.OrderNotifyParams
---@return types.OrderNotifyResp
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = { response = "" }
    }
end

-- 客户端通过 ext_data 显式控制账号在线状态。
---@param pChannelAccount string|table
---@param pHeartbeatRequest string|table|nil
---@return table
function plugin.heartbeat(pChannelAccount, pHeartbeatRequest)
    local mode = modeFromArguments(pChannelAccount, pHeartbeatRequest) or MODE_PC
    local modePlugin = MODE_PLUGINS[mode]
    if modePlugin ~= nil then
        return modePlugin.heartbeat(pChannelAccount, pHeartbeatRequest)
    end

    local firstData = decodeJsonObject(pChannelAccount)
    local secondData = decodeJsonObject(pHeartbeatRequest)
    local channelAccount, accountId = accountFrom(firstData)
    if channelAccount == nil then
        channelAccount, accountId = accountFrom(secondData)
    end

    if channelAccount == nil then
        local firstLength = type(pChannelAccount) == "string" and #pChannelAccount or 0
        local secondLength = type(pHeartbeatRequest) == "string" and #pHeartbeatRequest or 0
        log.warning(string.format(
            "(jk_wechat_pc) 心跳账号结构无效 arg1=%s/%s keys=[%s] arg2=%s/%s keys=[%s]",
            type(pChannelAccount), firstLength, tableKeys(firstData),
            type(pHeartbeatRequest), secondLength, tableKeys(secondData)))
        return {
            code = 500,
            message = "心跳账号信息无效，请提供channel_id",
            data = {}
        }
    end

    local extData = heartbeatExtDataFrom(firstData, secondData)
    if extData == nil then
        log.warning(string.format(
            "(jk_wechat_pc) 心跳数据结构无效 arg1 keys=[%s] arg2 keys=[%s]",
            tableKeys(firstData), tableKeys(secondData)))
        return {
            code = 500,
            message = "心跳数据解析失败",
            data = {
                arg1_type = type(pChannelAccount),
                arg1_length = type(pChannelAccount) == "string" and #pChannelAccount or 0,
                arg1_keys = tableKeys(firstData),
                arg2_type = type(pHeartbeatRequest),
                arg2_length = type(pHeartbeatRequest) == "string" and #pHeartbeatRequest or 0,
                arg2_keys = tableKeys(secondData)
            }
        }
    end

    local status = normalizeHeartbeatStatus(extData.status)
    local currentOnline = accountOnlineState(channelAccount)
    local stateChanged = false
    local message

    if status == "online" then
        if currentOnline ~= true then
            helper.channel_account_online(accountId)
            stateChanged = true
        end
        message = stateChanged and "账号已上线" or "账号已在线，无需更新"
    elseif status == "offline" then
        if currentOnline ~= false then
            helper.channel_account_offline(accountId)
            stateChanged = true
        end
        message = stateChanged and "账号已离线" or "账号已离线，无需更新"
    else
        return {
            code = 500,
            message = "ext_data.status仅支持online或offline",
            data = {}
        }
    end

    if stateChanged then
        log.info(string.format("(%s) 心跳状态:%s account_id:%s",
            channelAccount.plugin_name or "jk_wechat_pc", status, tostring(accountId)))
    end
    return {
        code = 200,
        message = message,
        data = {}
    }
end

--- 收款单账号保存时初始化账号列表和店铺信息；其他通道无需处理。
---@param ctx table|string
---@param legacyChannelInfo? table|string
---@return table
function plugin.onAccountChanged(ctx, legacyChannelInfo)
    local mode = modeFromArguments(ctx, legacyChannelInfo) or MODE_PC
    if mode == MODE_SKD then
        local response = skdPlugin.onAccountChanged(ctx, legacyChannelInfo)
        if type(response) == "table" then
            return response
        end
        local decoded = decodeJsonObject(response)
        if decoded ~= nil then
            local code = tonumber(decoded.code or decoded.err_code) or 500
            local message = tostring(decoded.message or decoded.err_message or "账号配置处理失败")
            return {
                code = code,
                message = message,
                err_code = code,
                err_message = message,
                data = type(decoded.data) == "table" and decoded.data or {},
            }
        end
        return {
            code = 500,
            message = "账号配置处理结果无效",
            err_code = 500,
            err_message = "账号配置处理结果无效",
            data = {},
        }
    end
    return {
        code = 200,
        message = "无需初始化",
        err_code = 200,
        err_message = "无需初始化",
        data = {},
    }
end

--- 解析上报数据
---@param msg types.PluginParseMessage
---@return table
function plugin.parseMessage(msg)
    local messagePatterns = {
        -- 个人码
        {
            title_reg = "微信收款助手|微信支付",
            content_reg = "^(?:\\[\\d+条\\]微信收款助手: )?微信支付收款(?<amount>[\\d\\.]+)元( )?(?!.*消费)[\\s\\S]*"
        },
        {
            title_reg = "微信支付",
            content_reg = "个人收款码到账¥(?<amount>[\\d\\.]+)"
        },
        -- 店员码
        {
            title_reg = "微信收款助手",
            content_reg = "\\[店员消息\\]收款到账(?<amount>[\\d\\.]+)元"
        },
        -- 赞赏码
        {
            title_reg = "微信支付",
            content_reg = "二维码赞赏到账(?<amount>[\\d\\.]+)元"
        },
        -- 商业码
        {
            title_reg = "微信收款商业版",
            content_reg = "收款(?:¥|￥|)(?<amount>[\\d.]+)"
        },
        {
            title_reg = "收款通知",
            content_reg = "微信收款商业版: 收款(?<amount>[\\d\\.]+)元"
        },
        -- 收款单
        {
            title_reg = "微信收款助手",
            content_reg = "收款单到账(?<amount>[\\d\\.]+)元"
        },
        -- 经营码
        {
            title_reg = "微信收款助手|微信支付",
            content_reg = "^(?:\\[\\d+条\\]微信收款助手: )?微信支付收款(?<amount>[\\d\\.]+)元( )?(?!.*朋友|到店)(\\((老顾客第\\d+次|新顾客)?消费\\))"
        },
        -- 企业微信
        {
            title_reg = "对外收款",
            content_reg = "^(?:\\[\\d+条\\])?收款通知：[\\s\\S]*?已收款(?<amount>[\\d\\.]+)元"
        }
    }

    local rules = withReportChannel(messagePatterns)
    local reportApps = {
        -- XArr PC 端通常沿用移动包名；同时兼容监控器直接传 Windows 进程名的情况。
        ["com.tencent.mm"] = rules,
        ["com.tencent.wework"] = rules,
        ["WeChat"] = rules,
        ["WeChat.exe"] = rules,
        ["WeChatAppEx"] = rules,
        ["WeChatAppEx.exe"] = rules,
        ["Weixin"] = rules,
        ["Weixin.exe"] = rules,
        ["WeixinAppEx"] = rules,
        ["WeixinAppEx.exe"] = rules,
        ["WXWork"] = rules,
        ["WXWork.exe"] = rules
    }

    return message_parser.parse(msg, reportApps)
end


return plugin
