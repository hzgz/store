/**
 * 支付SDK - 统一支付功能模块
 * 整合倒计时、状态检查、订单管理等功能，提供简化的API
 */
const PaymentSDK = {
    // SDK版本
    version: '1.0.0',
    
    // 配置
    config: {
        // API端点
        apiEndpoints: {
            orderInfo: '/api/order/info',
            orderQrcode: '/api/order/qrcode',
            orderStatus: '/api/order/status'
        },
        // 轮询配置
        pollInterval: 3000,
        maxPollAttempts: 200,
        // 倒计时配置
        countdownInterval: 1000,
        // 调试模式
        debug: true
    },

    // 内部状态
    _state: {
        countdownTimer: null,
        statusPoller: null,
        orderData: null,
        callbacks: {},
        isInitialized: false
    },

    // 订单状态常量 - 与后端Go代码保持一致
    STATUS: {
        WAIT_PAY: 1,    // 待支付
        PAYED: 2,       // 支付完成
        CLOSE: 3,       // 关闭
        EXPIRED: 4,     // 超时
        FAIL: 5         // 创建订单失败
    },

    /**
     * 初始化支付SDK
     * @param {Object} options - 配置选项
     * @param {Object} options.orderInfo - 订单信息 (必需)
     * @param {string} options.orderInfo.order_id - 订单ID
     * @param {number} options.orderInfo.expire_time - 过期时间戳(秒)
     * @param {number} options.orderInfo.status - 订单状态
     * @param {Object} options.elements - DOM元素选择器 (可选)
     * @param {string} options.elements.countdown - 倒计时显示元素 (默认: '#order-expire-countdown')
     * @param {string} options.elements.qrcode - 二维码显示元素 (默认: '#order-qrcode')
     * @param {Object} options.callbacks - 回调函数
     * @param {Function} options.callbacks.onSuccess - 订单支付成功回调
     * @param {Function} options.callbacks.onFailure - 支付失败回调
     * @param {Function} options.callbacks.onExpired - 订单过期回调
     * @param {Function} options.callbacks.onQrCodeLoaded - 二维码加载完成回调
     * @param {Function} options.callbacks.onError - 错误处理回调
     */
    init(options = {}) {
        try {
            this._log('正在初始化支付SDK...');

            // 验证必需参数
            if (!options.orderInfo || !options.orderInfo.order_id) {
                throw new Error('orderInfo.order_id 是必需的');
            }


            // 保存配置
            this._state.orderData = options.orderInfo;
            this._state.callbacks = options.callbacks || {};

            // 元素选择器配置
            const elements = {
                countdown: '#order-expire-countdown',
                qrcode: '#order-qrcode',
                ...options.elements
            };

            // 如果不是待支付状态 就不需要获取二维码和轮询了
            if(options.orderInfo.status != this.STATUS.WAIT_PAY){
                this._log('订单状态非待支付，跳过二维码获取和状态轮询', options.orderInfo.status);
                
                // 统一处理订单状态和回调
                this._handleOrderStatus(options.orderInfo.status, options.orderInfo, false);
                
                this._state.isInitialized = true;
                return this;
            }

            // 启动倒计时
            if (options.orderInfo.expire_time) {
                this._startCountdown(options.orderInfo.expire_time, elements.countdown);
            }


            // 获取并显示二维码
            this._loadQrCode(options.orderInfo.order_id, elements.qrcode);

            // 开始状态轮询
            this._startStatusPolling(options.orderInfo.order_id);

            this._state.isInitialized = true;
            this._log('支付SDK初始化完成');

            return this;
        } catch (error) {
            console.error('支付SDK初始化失败:', error);
            this._callCallback('onError', error);
            throw error;
        }
    },

    /**
     * 快速启动 - 使用全局orderInfo变量
     * @param {Object} callbacks - 回调函数
     */
    quickStart(callbacks = {}) {
        if (typeof orderInfo === 'undefined') {
            throw new Error('全局变量 orderInfo 未定义');
        }

        return this.init({
            orderInfo: orderInfo,
            callbacks: callbacks
        });
    },

    /**
     * 手动检查订单状态
     */
    async checkStatus() {
        if (!this._state.orderData) {
            throw new Error('SDK未初始化');
        }

        try {
            const result = await this._checkOrderStatus(this._state.orderData.order_id, false);
            return result;
        } catch (error) {
            this._callCallback('onError', error);
            throw error;
        }
    },

    /**
     * 停止所有功能
     */
    stop() {
        // 停止倒计时
        if (this._state.countdownTimer) {
            clearInterval(this._state.countdownTimer);
            this._state.countdownTimer = null;
        }

        // 停止状态轮询
        if (this._state.statusPoller) {
            clearTimeout(this._state.statusPoller);
            this._state.statusPoller = null;
        }

        this._log('所有功能已停止');
    },

    /**
     * 获取SDK状态
     */
    getStatus() {
        return {
            isInitialized: this._state.isInitialized,
            hasCountdown: !!this._state.countdownTimer,
            hasPoller: !!this._state.statusPoller,
            orderData: this._state.orderData
        };
    },

    // ==========================================================================
    // 内部方法 - 倒计时功能
    // ==========================================================================

    /**
     * 启动倒计时
     */
    _startCountdown(expireTime, elementSelector) {
        const element = document.querySelector(elementSelector);
        if (!element) {
            this._log('倒计时元素未找到:', elementSelector);
            return;
        }

        const updateCountdown = () => {
            const timeData = this._calculateTimeRemaining(expireTime);
            const timeString = this._formatTimeString(timeData);
            
            element.innerHTML = timeString;

            if (timeData.isExpired) {
                clearInterval(this._state.countdownTimer);
                this._state.countdownTimer = null;
                this._callCallback('onExpired', timeData);
            }
        };

        // 立即执行一次
        updateCountdown();

        // 设置定时器
        this._state.countdownTimer = setInterval(updateCountdown, this.config.countdownInterval);
        this._log('倒计时已启动');
    },

    /**
     * 计算剩余时间
     */
    _calculateTimeRemaining(expireTimestamp) {
        const expireDate = new Date(expireTimestamp * 1000);
        const now = new Date();
        const diffTime = expireDate - now;
        
        const diffSeconds = Math.max(0, Math.ceil(diffTime / 1000));

        return {
            totalMs: diffTime,
            totalSeconds: diffSeconds,
            days: Math.floor(diffSeconds / 86400),
            hours: Math.floor((diffSeconds % 86400) / 3600),
            minutes: Math.floor((diffSeconds % 3600) / 60),
            seconds: diffSeconds % 60,
            isExpired: diffTime <= 0
        };
    },

    /**
     * 格式化时间显示
     */
    _formatTimeString(timeData) {
        if (timeData.isExpired) {
            return '已过期,请勿支付';
        }

        let timeString = '';
        
        if (timeData.days > 0) {
            timeString += `${timeData.days}天`;
        }
        if (timeData.hours > 0) {
            timeString += `${timeData.hours}小时`;
        }
        if (timeData.minutes > 0) {
            timeString += `${timeData.minutes}分钟`;
        }
        timeString += `${timeData.seconds}秒`;

        return timeString;
    },

    // ==========================================================================
    // 内部方法 - 二维码功能
    // ==========================================================================

    /**
     * 加载二维码
     */
    async _loadQrCode(orderId, elementSelector) {
        try {
            const response = await fetch(this.config.apiEndpoints.orderQrcode, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    order_id: orderId
                })
            });

            if (!response.ok) {
                throw new Error(`获取二维码失败: ${response.status}`);
            }

            const result = await response.json();
            
            if (result.code === 200) {
                const qrcodeEl = document.querySelector(elementSelector);
                if (qrcodeEl) {
                    if(result.data.type == "qrcode" && result.data.qrcode_data){
                        qrcodeEl.src = result.data.qrcode_data;
                    }
                    this._callCallback('onQrCodeLoaded', result.data);
                    this._log('二维码加载完成');
                }
            } else {
                throw new Error(result.message || '获取二维码失败');
            }
        } catch (error) {
            console.error('加载二维码失败:', error);
            this._callCallback('onError', error);
        }
    },

    // ==========================================================================
    // 内部方法 - 状态检查功能
    // ==========================================================================

    /**
     * 开始状态轮询
     */
    _startStatusPolling(orderId) {
        let attempts = 0;

        const pollStatus = async () => {
            if (attempts >= this.config.maxPollAttempts) {
                this._log('轮询达到最大次数，停止轮询');
                return;
            }

            attempts++;

            try {
                const result = await this._checkOrderStatus(orderId, false);
                
                if (result.success) {
                    // 统一处理订单状态和回调
                    const shouldStop = this._handleOrderStatus(result.status, result.data, true);
                    if (shouldStop) {
                        return; // 停止轮询
                    }
                }

                // 继续下一次轮询
                this._state.statusPoller = setTimeout(pollStatus, this.config.pollInterval);

            } catch (error) {
                console.error('状态轮询失败:', error, '尝试次数:', attempts);
                // 出错时继续轮询
                this._state.statusPoller = setTimeout(pollStatus, this.config.pollInterval);
            }
        };

        // 立即开始轮询
        pollStatus();
        this._log('状态轮询已启动');
    },

    /**
     * 检查订单状态
     */
    async _checkOrderStatus(orderId, showAlert = false) {
        const response = await fetch(this.config.apiEndpoints.orderStatus, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                order_id: orderId
            })
        });

        if (!response.ok) {
            throw new Error(`请求失败: ${response.status}`);
        }

        const result = await response.json();
        
        if (result.code !== 200) {
            const errorMsg = result.message || '获取订单状态失败';
            if (showAlert) alert(errorMsg);
            return { success: false, error: errorMsg };
        }

        const statusData = result.data;
        const status = statusData.status;

        // 根据状态执行相应操作
        const statusMessages = {
            1: '订单待支付,请支付',
            2: '订单已支付成功',
            3: '订单已关闭,请重新下单',
            4: '订单已超时,请重新下单',
            5: '订单创建失败,请重新下单'
        };

        if (showAlert && statusMessages[status]) {
            alert(statusMessages[status]);
        }

        // 支付成功的跳转逻辑由回调函数处理，不在SDK中自动跳转

        return { success: true, status, data: statusData };
    },

    // ==========================================================================
    // 内部工具方法
    // ==========================================================================

    /**
     * 统一处理订单状态和回调
     * @param {number} status - 订单状态
     * @param {Object} data - 订单数据
     * @param {boolean} stopPolling - 是否停止轮询
     * @returns {boolean} - 是否应该停止轮询
     */
    _handleOrderStatus(status, data, stopPolling = false) {
        orderInfo.status = status
        switch (status) {
            case this.STATUS.WAIT_PAY:
                // 继续轮询
                if (stopPolling) this._log('订单待支付，继续轮询');
                return false;

            case this.STATUS.PAYED:
                this._callCallback('onSuccess', data);
                this._log('订单支付成功' + (stopPolling ? '，停止轮询' : ''));
                return true; // 停止轮询

            case this.STATUS.EXPIRED:
                this._callCallback('onExpired', data);
                this._log('订单已超时' + (stopPolling ? '，停止轮询' : ''));
                return true; // 停止轮询

            case this.STATUS.CLOSE:
                this._callCallback('onFailure', data);
                this._log('订单已关闭' + (stopPolling ? '，停止轮询' : ''));
                return true; // 停止轮询

            case this.STATUS.FAIL:
                this._callCallback('onFailure', data);
                this._log('订单创建失败' + (stopPolling ? '，停止轮询' : ''));
                return true; // 停止轮询

            default:
                this._log('未知订单状态:', status);
                return false;
        }
    },

    /**
     * 调用回调函数
     */
    _callCallback(callbackName, ...args) {
        const callback = this._state.callbacks[callbackName];
        if (typeof callback === 'function') {
            try {
                callback(...args);
            } catch (error) {
                console.error(`回调函数 ${callbackName} 执行失败:`, error);
            }
        }
    },

    /**
     * 调试日志
     */
    _log(...args) {
        if (this.config.debug) {
            console.log('[PaymentSDK]', ...args);
        }
    }
};

// 自动初始化 - 如果页面已加载且有全局变量
if (typeof window !== 'undefined') {
    // 页面加载完成后自动初始化
    // if (document.readyState === 'loading') {
    //     document.addEventListener('DOMContentLoaded', () => {
    //         PaymentSDK._autoInit();
    //     });
    // } else {
    //     PaymentSDK._autoInit();
    // }

    // // 添加自动初始化方法
    // PaymentSDK._autoInit = function() {
    //     // 检查是否有全局orderInfo变量，且没有手动初始化
    //     if (typeof orderInfo !== 'undefined' && !this._state.isInitialized) {
    //         try {
    //             // 提供默认回调
    //             this.quickStart({
    //                 onSuccess: (data) => {
    //                     console.log('订单支付成功!', data);
    //                     alert('支付成功！');
    //                 },
    //                 onExpired: (data) => {
    //                     console.log('订单已过期', data);
    //                     alert('订单已过期，请重新下单');
    //                 },
    //                 onError: (error) => {
    //                     console.error('支付过程发生错误:', error);
    //                 }
    //             });
    //             this._log('自动初始化完成');
    //         } catch (error) {
    //             console.warn('自动初始化失败，请手动调用 PaymentSDK.init():', error.message);
    //         }
    //     }
    // };

    // 导出到全局
    window.PaymentSDK = PaymentSDK;
}

// 兼容模块导出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PaymentSDK;
} 