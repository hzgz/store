/**
 * 支付模块使用说明
 * ===================
 * 
 * 这个文件包含了所有支付相关模块的使用说明和最佳实践
 * 
 * 📁 文件结构:
 * ├── countdown-timer.js      - 倒计时功能模块
 * ├── order-status-validator.js - 订单状态检查模块  
 * ├── easy-pay.js            - 统一支付模块 (推荐使用)
 * ├── payment.js             - 原有支付逻辑 (兼容性)
 * ├── countdown-examples.js   - 使用示例
 * └── usage-examples.js      - 状态检查示例
 * 
 * 🚀 快速开始 (推荐用法)
 * =====================
 * 
 * 1. 最简单的方式 - 零配置使用:
 *    页面只需要包含必要的script标签，EasyPay会自动初始化
 * 
 *    <script src="countdown-timer.js"></script>
 *    <script src="order-status-validator.js"></script>
 *    <script src="easy-pay.js"></script>
 * 
 *    // 页面有全局orderInfo变量时，自动启动所有功能
 *    // 无需任何额外代码！
 * 
 * 2. 手动快速启动:
 *    EasyPay.quickStart(); // 使用默认配置
 * 
 * 3. 自定义配置启动:
 *    EasyPay.quickStart({
 *        config: { debug: true },
 *        callbacks: {
 *            onPaid: (data) => alert('支付成功！'),
 *            onExpired: () => alert('订单已过期')
 *        }
 *    });
 * 
 * 📚 详细使用方法
 * ===============
 * 
 * ## EasyPay 统一模块 (推荐)
 * 
 * ### 基本用法:
 * ```javascript
 * // 自动初始化 (推荐) - 什么都不用做
 * // EasyPay会检测全局orderInfo变量并自动启动
 * 
 * // 手动启动
 * EasyPay.quickStart();
 * 
 * // 完全自定义
 * EasyPay.init({
 *     orderInfo: {
 *         order_id: 'ORDER_123',
 *         expire_time: 1640995200,
 *         trade_amount: '9999'
 *     },
 *     elements: {
 *         countdown: '#order-expire-countdown',
 *         qrcode: '#order-qrcode',
 *         checkButton: '.check-status'
 *     },
 *     callbacks: {
 *         onPaid: (data) => console.log('支付成功'),
 *         onExpired: () => console.log('订单过期'),
 *         onError: (error) => console.error('错误')
 *     }
 * });
 * ```
 * 
 * ### 控制方法:
 * ```javascript
 * EasyPay.stop();           // 停止所有功能
 * EasyPay.restart();        // 重启所有功能
 * EasyPay.checkStatus();    // 手动检查订单状态
 * EasyPay.getStatus();      // 获取当前运行状态
 * ```
 * 
 * ## CountdownTimer 倒计时模块
 * 
 * ### 简单用法:
 * ```javascript
 * // 创建订单倒计时
 * const timer = CountdownTimer.createOrderCountdown(
 *     expireTime,              // 过期时间戳(秒)
 *     '#order-expire-countdown',           // 显示元素
 *     () => alert('已过期')    // 过期回调
 * );
 * 
 * // 控制倒计时
 * timer.start();    // 开始
 * timer.stop();     // 停止
 * timer.restart();  // 重启
 * ```
 * 
 * ### 高级用法:
 * ```javascript
 * const timer = CountdownTimer.create({
 *     expireTime: Math.floor(Date.now() / 1000) + 3600,
 *     targetElement: '#timer',
 *     format: {
 *         showDays: true,
 *         showHours: true,
 *         showMinutes: true,
 *         showSeconds: true
 *     },
 *     expiredText: '已过期',
 *     onUpdate: (timeData, timeString) => {
 *         console.log('剩余:', timeString);
 *     },
 *     onExpired: () => {
 *         console.log('倒计时结束');
 *     }
 * });
 * ```
 * 
 * ## OrderStatusValidator 状态检查模块
 * 
 * ### 单次检查:
 * ```javascript
 * // 简单检查并显示alert
 * await OrderStatusValidator.checkOrderStatus(orderId);
 * 
 * // 自定义处理
 * const result = await OrderStatusValidator.validateAndHandle(orderId, {
 *     onPaid: (data) => console.log('已支付'),
 *     onExpired: (data) => console.log('已过期'),
 *     showAlert: false
 * });
 * ```
 * 
 * ### 状态轮询:
 * ```javascript
 * const poller = OrderStatusValidator.startPolling(orderId, {
 *     onPaid: (data) => console.log('支付成功'),
 *     onExpired: (data) => console.log('订单过期'),
 *     onError: (error) => console.error('错误'),
 *     interval: 3000,        // 3秒检查一次
 *     maxAttempts: 100,      // 最多检查100次
 *     showAlert: false       // 不显示alert
 * });
 * 
 * // 停止轮询
 * poller.stop();
 * ```
 * 
 * ### 便捷方法:
 * ```javascript
 * // 检查是否已支付
 * const isPaid = await OrderStatusValidator.isPaid(orderId);
 * 
 * // 检查订单是否有效(未过期且未取消)
 * const isValid = await OrderStatusValidator.isValid(orderId);
 * ```
 * 
 * 🎯 实际项目使用建议
 * ===================
 * 
 * ## 1. 简单支付页面 (推荐用法)
 * ```javascript
 * // 在页面底部添加这一行即可
 * EasyPay.quickStart();
 * 
 * // 或者使用自定义配置
 * EasyPay.quickStart({
 *     callbacks: {
 *         onPaid: (data) => {
 *             alert('支付成功！');
 *             window.location.href = data.return_uri;
 *         }
 *     }
 * });
 * ```
 * 
 * ## 2. 复杂支付页面
 * ```javascript
 * EasyPay.init({
 *     orderInfo: myOrderData,
 *     elements: {
 *         countdown: '#my-timer',
 *         qrcode: '#my-qrcode',
 *         checkButton: '#check-btn'
 *     },
 *     callbacks: {
 *         onPaid: handlePaymentSuccess,
 *         onExpired: handlePaymentExpired,
 *         onError: handleError
 *     },
 *     config: {
 *         debug: true,
 *         pollInterval: 2000
 *     }
 * });
 * ```
 * 
 * ## 3. 移动端优化
 * ```javascript
 * const isMobile = /Mobile|Android|iPhone/i.test(navigator.userAgent);
 * 
 * EasyPay.quickStart({
 *     config: {
 *         pollInterval: isMobile ? 5000 : 3000, // 移动端减少轮询
 *         debug: false
 *     },
 *     callbacks: {
 *         onPaid: (data) => {
 *             if (navigator.vibrate) {
 *                 navigator.vibrate(200); // 震动反馈
 *             }
 *             window.location.href = data.return_uri;
 *         }
 *     }
 * });
 * ```
 * 
 * 🔧 配置选项
 * ===========
 * 
 * ## EasyPay 配置:
 * ```javascript
 * EasyPay.config = {
 *     pollInterval: 3000,      // 轮询间隔(毫秒)
 *     maxPollAttempts: 200,    // 最大轮询次数
 *     countdownInterval: 1000, // 倒计时更新间隔
 *     debug: false,            // 调试模式
 *     apiEndpoints: {          // API端点
 *         orderInfo: '/api/order/info',
 *         orderQrcode: '/api/order/qrcode',
 *         orderStatus: '/api/order/status'
 *     }
 * };
 * ```
 * 
 * ## 元素选择器:
 * ```javascript
 * elements: {
 *     countdown: '#order-expire-countdown',    // 倒计时显示元素
 *     qrcode: '#order-qrcode',     // 二维码图片元素
 *     checkButton: '.check-status' // 状态检查按钮
 * }
 * ```
 * 
 * ## 回调函数:
 * ```javascript
 * callbacks: {
 *     onPaid: (data) => {},        // 支付成功
 *     onExpired: (data) => {},     // 订单过期
 *     onCancelled: (data) => {},   // 订单取消
 *     onError: (error) => {}       // 错误处理
 * }
 * ```
 * 
 * 🐛 错误处理
 * ===========
 * 
 * ## 常见错误:
 * 
 * 1. **模块未加载错误**
 *    ```
 *    Error: CountdownTimer 模块未加载
 *    ```
 *    解决: 确保script标签正确引入了countdown-timer.js
 * 
 * 2. **全局变量未定义**
 *    ```
 *    Error: 全局变量 orderInfo 未定义
 *    ```
 *    解决: 确保页面定义了orderInfo变量，或使用手动初始化
 * 
 * 3. **元素不存在**
 *    倒计时仍会正常运行，但不会更新DOM元素
 *    在控制台查看警告信息
 * 
 * ## 调试模式:
 * ```javascript
 * EasyPay.config.debug = true;  // 开启调试模式
 * EasyPay.quickStart();
 * // 在控制台查看详细日志
 * ```
 * 
 * 💡 最佳实践
 * ===========
 * 
 * 1. **优先使用EasyPay**: 除非有特殊需求，否则推荐使用EasyPay统一模块
 * 
 * 2. **自动初始化**: 让EasyPay自动检测和初始化，减少手动代码
 * 
 * 3. **错误处理**: 始终提供onError回调处理异常情况
 * 
 * 4. **移动端优化**: 在移动设备上适当降低轮询频率
 * 
 * 5. **调试开发**: 开发时开启debug模式，生产环境关闭
 * 
 * 6. **优雅降级**: 模块加载失败时提供备用方案
 * 
 * 📞 技术支持
 * ===========
 * 
 * 如果遇到问题：
 * 1. 检查浏览器控制台是否有错误信息
 * 2. 开启debug模式查看详细日志
 * 3. 参考countdown-examples.js中的示例代码
 * 4. 确认所有必需的script标签都已正确引入
 * 
 * 更多示例请查看：
 * - countdown-examples.js - 倒计时使用示例
 * - usage-examples.js - 状态检查使用示例
 */

// 在控制台输出使用提示
if (typeof console !== 'undefined') {
    console.log(`
%c💰 支付模块使用说明 💰

🚀 快速开始:
   EasyPay.quickStart();

📚 查看示例:
   PaymentExamples.quickStart()     - 快速启动示例
   PaymentExamples.realWorld()      - 实际项目示例
   PaymentExamples.mobileOptimized() - 移动端示例

🔧 模块状态:
   EasyPay.getStatus()  - 查看当前状态
   EasyPay.config.debug = true  - 开启调试模式

📖 详细文档: 请查看 README.js 文件中的完整说明
    `, 'color: #4CAF50; font-weight: bold;');
} 