# PaymentSDK 使用说明

PaymentSDK 是一个统一的支付功能模块，整合了倒计时、状态检查、订单管理等功能，提供简化的API接口。

## 特性

- 🚀 **简单易用**: 只需要几行代码即可完成支付页面的所有功能
- 🔄 **自动轮询**: 自动检查订单支付状态
- ⏰ **倒计时功能**: 自动显示订单过期倒计时
- 📱 **二维码管理**: 自动获取和显示支付二维码
- 🎯 **回调机制**: 支持多种状态回调函数
- 🔧 **可配置**: 支持自定义配置选项

## 基本使用

### 1. 引入SDK

```html
<script src="js/payment-sdk.js"></script>
<script src="js/payment.js"></script>
```

### 2. 快速启动（推荐）

如果页面中有全局变量 `orderInfo`，可以使用快速启动模式：

```javascript
PaymentSDK.quickStart({
    // 订单支付成功回调
    onSuccess: (data) => {
        console.log('订单支付成功!', data);
        alert('支付成功！');
        if (data.return_uri) {
            window.location.href = data.return_uri;
        }
    },
    
    // 订单过期回调
    onExpired: (data) => {
        console.log('订单已过期', data);
        alert('订单已过期，请重新下单');
    },
    
    // 支付失败/订单取消回调
    onFailure: (data) => {
        console.log('订单已取消', data);
        alert('订单已取消，请重新下单');
    },
    
    // 二维码加载完成回调
    onQrCodeLoaded: (data) => {
        console.log('二维码加载完成', data);
    },
    
    // 错误处理回调
    onError: (error) => {
        console.error('支付过程发生错误:', error);
        alert('系统错误，请稍后重试');
    }
});
```

### 3. 完整初始化

如果需要更多控制，可以使用完整的初始化方法：

```javascript
PaymentSDK.init({
    // 订单信息 (必需)
    orderInfo: {
        order_id: 'ORDER_123456',
        expire_time: 1635724800 // 过期时间戳(秒)
    },
    
    // DOM元素选择器 (可选)
    elements: {
        countdown: '#order-expire-countdown',    // 倒计时显示元素
        qrcode: '#order-qrcode'     // 二维码显示元素
    },
    
    // 回调函数
    callbacks: {
        onSuccess: (data) => { /* 支付成功 */ },
        onExpired: (data) => { /* 订单过期 */ },
        onFailure: (data) => { /* 支付失败 */ },
        onQrCodeLoaded: (data) => { /* 二维码加载完成 */ },
        onError: (error) => { /* 错误处理 */ }
    }
});
```

## 回调函数说明

### onSuccess(data)
订单支付成功时触发
- `data`: 包含订单支付信息，可能包含 `return_uri` 字段用于跳转

### onExpired(data)  
订单超时时触发（倒计时结束或状态检查发现超时）
- `data`: 包含订单超时信息

### onFailure(data)
订单被关闭或创建失败时触发
- `data`: 包含订单状态信息

### onQrCodeLoaded(data)
二维码加载完成时触发
- `data`: 包含二维码相关信息

### onError(error)
发生错误时触发
- `error`: 错误信息

## 其他方法

### 手动检查状态
```javascript
PaymentSDK.checkStatus()
    .then(result => {
        console.log('状态检查结果:', result);
    })
    .catch(error => {
        console.error('检查失败:', error);
    });
```

### 停止所有功能
```javascript
PaymentSDK.stop();
```

### 获取SDK状态
```javascript
const status = PaymentSDK.getStatus();
console.log('SDK状态:', status);
```

## 配置选项

可以修改SDK的默认配置：

```javascript
PaymentSDK.config.debug = true;           // 开启调试模式
PaymentSDK.config.pollInterval = 5000;    // 状态轮询间隔(毫秒)
PaymentSDK.config.maxPollAttempts = 300;  // 最大轮询次数
```

## HTML结构要求

页面需要包含以下元素：

```html
<!-- 倒计时显示 -->
<span id="order-expire-countdown"></span>

<!-- 二维码显示 -->
<img id="order-qrcode" src="" alt="支付二维码">

<!-- 手动检查按钮 (可选) -->
<button onclick="checkOrderStatus()">检查状态</button>
```

## 兼容性

- 支持现代浏览器 (Chrome 60+, Firefox 55+, Safari 12+)
- 支持 ES6+ 语法
- 需要支持 fetch API

## 版本信息

当前版本: 1.0.0

## 注意事项

1. 确保页面已定义全局变量 `orderInfo`
2. 订单信息中必须包含 `order_id` 字段
3. 如果有 `expire_time` 字段，会自动启动倒计时
4. SDK会自动处理订单状态变化，无需手动管理
5. 所有网络请求失败都会触发 `onError` 回调 