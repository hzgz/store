---@diagnostic disable: undefined-global
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local PLUGIN = "pc_wechat_all_lz"
local PC_WECHAT_ALL_LZ = PLUGIN
local plugin = {}

local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

local function mergeOptions(ctx)
    ctx = ctx or {}
    local accountInfo = ctx.account_info or {}
    local options = {}
    for k, v in pairs(toTable(accountInfo.options)) do
        options[k] = v
    end
    for k, v in pairs(toTable(ctx.plugin_option)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.plugin_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.account_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    return options
end

-- 定义网关常量
local GATEWAY = {
    BASE = "https://payapp.wechatpay.cn",
    RECEIPT_MD = "https://payapp.wechatpay.cn/receiptmdmgr",
    RECEIPT_SJT = "https://payapp.wechatpay.cn/receiptsjtmgr",
    RECEIPT_WX = "https://payapp.wechatpay.cn/receiptwxmgr",
    SMALLBOOK = "https://smallbook.wxpapp.weixin.qq.com"
}

function plugin.pluginInfo()
    return {
        channels = {
            ["wxpay"] = {{
                label = 'PC自挂-微信-收款单-小账本',
                value = PC_WECHAT_ALL_LZ,
                report = 1,
                options = {
                    need_check_online = 1,
                    bind_client_name = 1,
                    use_add_amount = 1
                }
            } }
        },
        options = {
            detection_interval = 5,
            detection_type = "cron"
        }
    }
end

-- 获取form表单
function plugin.formItems(ctx)
    return {
        inputs = {
            {
                name = "pay_mode",
                label = "收款方式",
                type = "radio",
                default = "receipt",
                options = { tip = "收款单使用微信收款单接口，小账本使用微信小账本接口" },
                placeholder = "请选择收款方式",
                values = {
                    { label = "收款单", value = "receipt" },
                    { label = "小账本", value = "smallbook" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择收款方式" } }
            },
            {
                name = "sid",
                label = "SID",
                type = "input",
                default = "",
                options = { tip = "" },
                placeholder = "请输入Sid或等待上报"
            },
            {
                name = "account_list",
                label = "账号列表(一行一组)",
                type = "textarea",
                default = "",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                hidden_list = 1,
                placeholder = "清空后会重新获取",
                options = { tip = "清空后会点保存会重新获取,如需切换账号ID,可在此处复制到下面对应输入框替换" }
            },
            {
                name = "aid",
                label = "账号ID",
                type = "input",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                default = "",
                placeholder = "请输入账号ID",
                options = { tip = "请从账号列表选一组账号信息的账号ID填入此处" }
            },
            {
                name = "account_type",
                label = "账号类型",
                type = "input",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                default = "",
                placeholder = "请输入账号类型[1-3],不行就换下一个",
                options = { tip = "请从账号列表选一组账号信息的账号类型填入此处" }
            },
            {
                name = "shop_id",
                label = "店铺ID",
                type = "input",
                default = "",
                when = "this.formModel.options.sid && this.formModel.options.pay_mode !== 'smallbook'",
                options = { tip = "店铺ID保存/定时刷新，如果shop_id为空，就不要填写，否则会报错" },
                placeholder = "请输入商户ID"
            },
            {
                name = "report_type",
                label = "上报方式",
                type = "radio",
                default = "server",
                options = { tip = "客户端: 需要客户端监控上报, 服务器: 服务端主动监控上报 (此处客户端上报依然会有效)" },
                placeholder = "请选择上报方式",
                values = {
                    { label = "客户端上报", value = "client" },
                    { label = "服务器上报", value = "server" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = "scan_type",
                label = "订单检查方式",
                type = "radio",
                default = "order_or_amount",
                options = { tip = "" },
                placeholder = "请选择订单检查方式",
                values = {
                    { label = "订单号匹配不到则使用金额", value = "order_or_amount" },
                    { label = "订单号", value = "order" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            },
            {
                name = "order_temp_amount",
                label = "取消订单递增金额",
                type = "radio",
                default = "0",
                options = { tip = "<b>注意:</b>订单检查方式为订单号的时候才能选择[是]" },
                placeholder = "请选择订单检查方式",
                values = {
                    { label = "否", value = "0" },
                    { label = "是", value = "1" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入" } }
            }
        }
    }
end

-- 统一的错误响应处理
plugin._error_response = function(err_code, err_message)
    return {
        code = err_code,
        message = err_message,
        data = {}
    }
end

-- 统一的HTTP响应检查
plugin._check_http_response = function(resp, account_id, operation)
    if resp == nil then
        log.warning(string.format("[%s] (%s) %s请求失败", PLUGIN, account_id, operation))
        return false
    end

    if resp.status_code ~= 200 then
        log.warning(string.format("[%s] (%s) %s失败,状态码:%d", PLUGIN, account_id, operation,
            resp.status_code))
        return false
    end

    if resp.body == "" then
        log.warning(string.format("[%s] (%s) %s失败,返回数据为空", PLUGIN, account_id, operation))
        return false
    end

    local data = json.decode(resp.body)
    if not data or data.errcode ~= 0 then
        local errorDetail = data and (data.errmsg or data.err_message or data.message or data.msg) or resp.body
        log.warning(string.format("[%s] (%s) %s失败,错误码:%s,错误详情:%s", PLUGIN, account_id, operation,
            tostring(data and data.errcode or -1), tostring(errorDetail or "无")))
        return false
    end

    return true, data
end

plugin._get_pay_mode = function(options)
    if options and options.pay_mode == "smallbook" then
        return "smallbook"
    end
    return "receipt"
end

plugin._get_sid_type_from_report = function(extData)
    if not extData then
        return "receipt"
    end

    local sidType = extData.sid_type or extData.pay_mode or extData.type or extData.sidType or extData.sid_name or extData.sidName or ""
    if sidType == "smallbook" or sidType == "小账本" or sidType == "small_book" or sidType == "book" then
        return "smallbook"
    end
    if sidType == "receipt" or sidType == "收款单" then
        return "receipt"
    end

    if extData.smallbook_sid or extData.small_book_sid or extData.book_sid then
        return "smallbook"
    end
    return "receipt"
end

plugin._get_sid_from_report = function(extData, sidType)
    if not extData then
        return nil
    end
    if sidType == "smallbook" then
        return extData.sid or extData.smallbook_sid or extData.small_book_sid or extData.book_sid
    end
    return extData.sid or extData.receipt_sid or extData.receiptSid
end

-- 参数验证
plugin._validate_params = function(params, required_fields)
    for _, field in ipairs(required_fields) do
        if not params[field] or params[field] == "" then
            return false, string.format("缺少必要参数: %s", field)
        end
    end
    return true
end

-- 账号类型判断
plugin._get_gateway_by_account_type = function(account_type)
    account_type = tonumber(account_type) or account_type
    if account_type == 1 or account_type == "1" then
        return GATEWAY.RECEIPT_MD
    elseif account_type == 2 or account_type == "2" then
        return GATEWAY.RECEIPT_WX
    elseif account_type == 3 or account_type == "3" then
        return GATEWAY.RECEIPT_SJT
    end
    return nil
end

-- 创建订单
function plugin.create(ctx)
    local orderInfo = ctx.order_info
    local vAccountInfo = ctx.account_info or {}
    local options = ctx.account_options or json.decode(vAccountInfo.options or "{}") or {}
    local result

    if plugin._get_pay_mode(options) == "smallbook" then
        result = plugin._create_smallbook_order(orderInfo, options, vAccountInfo)
    else
        result = plugin._create_receipt_order(orderInfo, options, vAccountInfo)
    end

    if result.code then
        return result
    end
    return {
        code = 200,
        message = "success",
        data = result
    }
end

plugin._create_receipt_order = function(orderInfo, options, vAccountInfo)
    local valid, err_message = plugin._validate_params(options, {"sid", "aid"})
    if not valid then
        return plugin._error_response(500, err_message)
    end

    local gateway = plugin._get_gateway_by_account_type(options.account_type)
    if not gateway then
        return plugin._error_response(500, "不支持的账号类型")
    end

    local url = gateway .. "/receipt/create"
    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }
    local result

    if options.account_type == "1" or options.account_type == "2" or options.account_type == 1 or options.account_type == 2 then
        url = url .. "?miniprogram_version=3.15.9"
        url = url .. "&remark_pic_urls="
        url = url .. "&option_list=%5B%5D"
        url = url .. "&account_type=" .. options.account_type
        if options.shop_id and options.shop_id ~= "" then
            url = url .. "&shop_id=" .. options.shop_id
        end
        url = url .. "&remark=" .. orderInfo.order_id
        url = url .. "&account_id=" .. options.aid
        url = url .. "&sid=" .. options.sid
        url = url .. "&fee=" .. orderInfo.trade_amount

        log.info(string.format("(%s) %s(%s) 创建订单,url:%s", PLUGIN, vAccountInfo.name, vAccountInfo.id, url))
        result = http.get(url, { headers = headers })
    else
        url = url .. "?miniprogram_version=3.15.9"
        url = url .. "&account_id=" .. options.aid
        url = url .. "&account_type=" .. options.account_type
        url = url .. "&sid=" .. options.sid

        log.info(string.format("(%s) %s(%s) 创建订单,url:%s", PLUGIN, vAccountInfo.name, vAccountInfo.id, url))

        local body = {
            miniprogram_version = "3.15.9",
            fee = orderInfo.trade_amount,
            remark = orderInfo.order_id,
            remark_pic_urls = "",
            option_list = {},
            receipt_item_list = {},
            sid = options.sid
        }
        if options.shop_id and options.shop_id ~= "" then
            body.shop_id = tonumber(options.shop_id)
        end

        result = http.post(url, {
            headers = headers,
            body = json.encode(body)
        })
    end

    log.debug(string.format("[插件] (%s) 创建订单 GET %s", PLUGIN, result.body))

    if result.status_code ~= 200 then
        return plugin._error_response(500, string.format("请求失败,状态码:%d", result.status_code))
    end

    local response = json.decode(result.body)
    if not response then
        return plugin._error_response(500, "解析返回数据失败")
    end

    if not response.errcode or response.errcode ~= 0 then
        return plugin._error_response(500, response.msg or "创建订单失败")
    end

    local receipt_id
    if response.data and response.data.receipt then
        receipt_id = response.data.receipt.receipt_id
    end
    if not receipt_id then
        return plugin._error_response(500, "未获取到receipt_id")
    end

    url = gateway .. "/receipt/getwxacode"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&wxacode_path_type=1"
    url = url .. "&receipt_id=" .. receipt_id
    url = url .. "&account_id=" .. options.aid
    url = url .. "&account_type=" .. options.account_type
    url = url .. "&sid=" .. options.sid

    log.debug(string.format("[插件] (%s) 获取二维码 URL: %s", PLUGIN, url))

    result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    if result.status_code ~= 200 then
        return plugin._error_response(500, string.format("请求失败,状态码:%d", result.status_code))
    end

    response = json.decode(result.body)
    if not response then
        return plugin._error_response(500, "解析返回数据失败")
    end

    if not response.errcode or response.errcode ~= 0 then
        return plugin._error_response(500, response.msg or "获取二维码失败")
    end

    if not response.data then
        return plugin._error_response(500, "返回数据格式错误,缺少data字段")
    end

    local qrcode = response.data.qrcode
    if not qrcode then
        return plugin._error_response(500, "未获取到二维码")
    end

    if qrcode == "" then
        return plugin._error_response(500, "二维码内容为空")
    end

    local write, filePath = helper.save_image_cache_base64(qrcode)
    if not write then
        return plugin._error_response(500, "二维码保存失败")
    end

    log.info(string.format("(%s) %s(%s) 创建订单[%s] 二维码保存成功", PLUGIN, vAccountInfo.name,
        vAccountInfo.id, orderInfo.order_id))
    return { type = "qrcode", qrcode_file = filePath, url = "", content = "", out_trade_no = tostring(receipt_id) }
end

plugin._create_smallbook_order = function(orderInfo, options, vAccountInfo)
    local valid, err_message = plugin._validate_params(options, {"sid"})
    if not valid then
        return plugin._error_response(500, err_message)
    end

    local url = GATEWAY.SMALLBOOK .. "/qrappsl/profile/getpayqrcode"
    url = url .. "?sid=" .. options.sid
    url = url .. "&v=6.23.1"

    log.info(string.format("(%s) %s(%s) 创建小账本订单,url:%s", PLUGIN, vAccountInfo.name,
        vAccountInfo.id, url))

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx28be8489b7a36aaa/1061/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    if result.status_code ~= 200 then
        return plugin._error_response(500, string.format("请求失败,状态码:%d", result.status_code))
    end

    local response = json.decode(result.body)
    if not response then
        return plugin._error_response(500, "解析返回数据失败")
    end

    if not response.errcode or response.errcode ~= 0 then
        return plugin._error_response(500, response.msg or "获取小账本二维码失败")
    end

    if not response.data then
        return plugin._error_response(500, "返回数据格式错误,缺少data字段")
    end

    local qrcode = response.data.qrcode_content or response.data.qrcode
    if not qrcode or qrcode == "" then
        return plugin._error_response(500, "未获取到小账本二维码")
    end

    local write, filePath = helper.save_image_cache_base64(qrcode)
    if not write then
        return plugin._error_response(500, "二维码保存失败")
    end

    log.info(string.format("(%s) %s(%s) 小账本订单[%s] 二维码保存成功", PLUGIN, vAccountInfo.name,
        vAccountInfo.id, orderInfo.order_id))

    return { type = "qrcode", qrcode_file = filePath, url = "", content = "", out_trade_no = "" }
end

-- 支付回调
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = {
            response = ""
        }
    }
end

-- 获取账号列表
function plugin.getAccountList(sid)
    local url = GATEWAY.RECEIPT_WX .. "/account/list"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&sid=" .. sid

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    -- 判断返回状态
    if result.status_code ~= 200 then
        return nil, string.format("请求账号列表失败,状态码:%d", result.status_code)
    end

    print(result.body)

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return nil, "解析账号列表数据失败"
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return nil, response.msg or "获取账号列表失败"
    end

    -- 返回账号列表数据
    if response.data and response.data.account_list then
        return response.data.account_list, nil
    end

    return nil, "账号列表为空"
end

-- 心跳处理
function plugin.heartbeat(ctx)
    ctx = ctx or {}
    local accountInfo = ctx.account_info or {}
    local heartbeatData = ctx.heartbeat or {}

    if heartbeatData.ext_data == nil or heartbeatData.ext_data == "" then
        log.info(string.format("(%s) 心跳数据解析失败 account_id:%s", accountInfo.plugin_name or PLUGIN, accountInfo.id or ""))
        return { code = 500, message = "心跳数据解析失败", data = {} }
    end

    local extData = toTable(heartbeatData.ext_data)
    if next(extData) == nil then
        return { code = 500, message = "心跳扩展数据解析失败", data = {} }
    end

    local sidType = plugin._get_sid_type_from_report(extData)
    local sid = plugin._get_sid_from_report(extData, sidType)
    log.info(string.format("(%s) 心跳扩展数据 type:%s sid:%s verify:%s", accountInfo.plugin_name or PLUGIN, sidType, sid or "", extData.verify_only or "0"))

    if extData.verify_only == "1" or extData.verify_only == 1 then
        return { code = 200, message = "客户端验证成功", data = {} }
    end

    if sid == nil or sid == "" then
        return { code = 500, message = "SID为空", data = {} }
    end

    if accountInfo.id == nil or accountInfo.id == "" then
        log.info(string.format("(%s) 心跳未传入通道账号，返回SID给框架按client_name绑定保存", accountInfo.plugin_name or PLUGIN))
        return {
            code = 200,
            message = "心跳正常",
            data = {
                online = 1,
                options = {
                    pay_mode = sidType,
                    sid = sid,
                    [sidType .. "_sid"] = sid
                }
            }
        }
    end

    helper.channel_account_set_option(accountInfo.id, "pay_mode", sidType)
    helper.channel_account_set_option(accountInfo.id, "sid", sid)
    helper.channel_account_set_option(accountInfo.id, sidType .. "_sid", sid)
    helper.channel_account_set_option(accountInfo.id, "receipt_order_fail_count", "0")
    helper.channel_account_set_option(accountInfo.id, "smallbook_login_fail_count", "0")
    log.info(string.format("(%s) SID已更新 account_id:%s type:%s", accountInfo.plugin_name or PLUGIN, accountInfo.id, sidType))

    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
    end

    return { code = 200, message = "心跳正常", data = {} }
end

-- 验证账号并初始化
plugin._verify_and_init_account = function(accountInfo, options)
    if not options.sid or options.sid == "" then
        return false, "暂未填写sid"
    end

    if plugin._get_pay_mode(options) == "smallbook" then
        return true, ""
    end

    -- 账号列表为空或旧格式缺少shop_id时重新获取
    if options.account_list == "" or not string.find(options.account_list or "", "shop_id:", 1, true) then
        -- 获取账号列表
        local accountList, err = plugin.getAccountList(options.sid)
        if err then
            return false, err
        end

        -- 保存账号列表
        if accountList then
            local lines = {}
            local activatedAccounts = {}
            for _, account in ipairs(accountList) do
                if account.account_status == "ACTIVATED" then
                    account.shop_id = plugin._get_shop_id(options.sid, account.account_id, account.account_type) or ""
                    local line = string.format("账号ID:%s|账号类型:%s|商户名称:%s|shop_id:%s", account.account_id or "",
                        account.account_type or "", account.account_name or "", account.shop_id)
                    table.insert(lines, line)
                    table.insert(activatedAccounts, account)
                end
            end
            local accountListStr = table.concat(lines, "\n")
            helper.channel_account_set_option(accountInfo.id, "account_list", accountListStr)

            -- 如果只有一个账号，则自动选择第一个账号
            if #activatedAccounts > 0 then
                helper.channel_account_set_option(accountInfo.id, "aid", activatedAccounts[1].account_id)
                helper.channel_account_set_option(accountInfo.id, "account_type", activatedAccounts[1].account_type)
                options.aid = activatedAccounts[1].account_id
                options.account_type = tostring(activatedAccounts[1].account_type)
                if activatedAccounts[1].shop_id ~= "" then
                    helper.channel_account_set_option(accountInfo.id, "shop_id", activatedAccounts[1].shop_id)
                    options.shop_id = activatedAccounts[1].shop_id
                end

                log.info(string.format("(%s) 账号列表获取成功 自动选择账号ID:%s,账号类型:%s",
                    accountInfo.id, options.aid, options.account_type))
            end
        end
    end

    -- 判断用户是否选择了aid
    if options.aid == "" then
        return false, "请选择一个账号"
    end

    -- 判断account_type
    if options.account_type == "" then
        return false, "请选择一个账号类型"
    end

    if not options.shop_id or options.shop_id == "" then
        local shop_id = plugin._get_shop_id(options.sid, options.aid, options.account_type)
        if shop_id then
            helper.channel_account_set_option(accountInfo.id, "shop_id", shop_id)
            options.shop_id = shop_id
        end
    end

    return true, ""
end

-- 通道新增或修改
function plugin.onAccountChanged(ctx)
    local accountInfo, options
    if type(ctx) == "table" and ctx.account_info then
        accountInfo = ctx.account_info
        options = mergeOptions(ctx)
    else
        accountInfo = toTable(ctx)
        options = toTable(accountInfo.options)
    end

    if plugin._get_pay_mode(options) ~= "smallbook" and options.account_list == "" then
        helper.channel_account_set_option(accountInfo.id, "aid", "")
        helper.channel_account_set_option(accountInfo.id, "account_type", "")
        helper.channel_account_set_option(accountInfo.id, "shop_id", "")
        options.aid = ""
        options.account_type = ""
        options.shop_id = ""
    end

    if not options.sid or options.sid == "" then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end
        return { code = 200, message = "账号信息保存成功，请等待客户端上报SID", data = {} }
    end

    local success, err_message = plugin._verify_and_init_account(accountInfo, options)
    if not success then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end
        return { code = 200, message = "账号信息保存成功，待SID有效后自动更新：" .. err_message, data = {} }
    end

    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
    end

    return { code = 200, message = "账号验证成功", data = {} }
end

-- 定时任务
function plugin.cron(ctx)
    local accountInfo = ctx.account_info or {}
    local options = ctx.account_options or ctx.plugin_options or ctx.plugin_option or mergeOptions(ctx)

    if options.report_type == "client" then
        return { code = 200, message = "使用客户端处理,服务端无需干预", data = {} }
    end

    local success, err_message = plugin._verify_and_init_account(accountInfo, options)
    if not success then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end
        return { code = 500, message = err_message, data = {} }
    end

    local payMode = plugin._get_pay_mode(options)
    local failCountKey = payMode == "smallbook" and "smallbook_login_fail_count" or "receipt_order_fail_count"
    if accountInfo.online ~= 1 and tonumber(options[failCountKey] or 0) >= 5 then
        return { code = 200, message = "通道已离线，等待客户端重新上报SID", data = {} }
    end

    if payMode == "smallbook" then
        return plugin._handle_smallbook_orders(options, accountInfo)
    end

    -- 获取订单列表
    local orderList = plugin._get_order_list(options.account_type, options.aid, options.sid)
    if orderList == nil then
        local failCount = tonumber(options.receipt_order_fail_count or 0) + 1
        helper.channel_account_set_option(accountInfo.id, "receipt_order_fail_count", tostring(failCount))
        if failCount >= 5 then
            helper.channel_account_offline(accountInfo.id)
            log.warning(string.format("[%s] 收款单获取订单列表连续失败%d次,通道已设置离线", PLUGIN, failCount))
        end
        return { code = 500, message = "获取订单列表失败", data = {} }
    end

    if tonumber(options.receipt_order_fail_count or 0) > 0 then
        helper.channel_account_set_option(accountInfo.id, "receipt_order_fail_count", "0")
    end

    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
    end

    if not orderList or #orderList == 0 then
        return { code = 200, message = "暂无订单", data = {} }
    end

    -- 遍历订单列表处理
    for _, order in ipairs(orderList) do
        plugin._handle_order(order, options, accountInfo)
    end

    return { code = 200, message = "处理完成", data = {} }
end

-- 处理小账本订单
plugin._handle_smallbook_orders = function(options, accountInfo)
    local orderList, loginStateFailed = plugin._get_smallbook_order_list(options.sid)
    if orderList == nil then
        if loginStateFailed then
            local failCount = tonumber(options.smallbook_login_fail_count or 0) + 1
            helper.channel_account_set_option(accountInfo.id, "smallbook_login_fail_count", tostring(failCount))
            if failCount >= 5 then
                helper.channel_account_offline(accountInfo.id)
                log.warning(string.format("[%s] 小账本效验登录态连续失败%d次,通道已设置离线", PLUGIN, failCount))
            end
        elseif tonumber(options.smallbook_login_fail_count or 0) > 0 then
            helper.channel_account_set_option(accountInfo.id, "smallbook_login_fail_count", "0")
        end
        return { code = 500, message = "获取小账本订单列表失败", data = {} }
    end

    if tonumber(options.smallbook_login_fail_count or 0) > 0 then
        helper.channel_account_set_option(accountInfo.id, "smallbook_login_fail_count", "0")
    end

    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
    end

    if not orderList or #orderList == 0 then
        return { code = 200, message = "暂无小账本订单", data = {} }
    end

    for _, order in ipairs(orderList) do
        plugin._handle_smallbook_success_order(order, options, accountInfo)
    end

    return { code = 200, message = "小账本订单处理完成", data = {} }
end

plugin._handle_smallbook_success_order = function(order, options, accountInfo)
    if not plugin._is_order_exists(order, options, accountInfo) then
        plugin._insert_and_report_order(order, plugin._extract_order_id(order.payer_remark), options, accountInfo)
    end
end

-- 处理单个订单
plugin._handle_order = function(order, options, accountInfo)
    if order.state == "close" then
        plugin._handle_closed_order(order, options)
    elseif order.state == "receiving" then
        plugin._handle_receiving_order(order, options)
    elseif order.state == "success" then
        plugin._handle_success_order(order, options, accountInfo)
    end
end

-- 处理已关闭订单
plugin._handle_closed_order = function(order, options)
    local create_time = tonumber(order.create_time)
    local now = os.time()
    -- 超过一天则删除
    if now - create_time > 86400 then -- 一天 = 86400秒
        plugin._delete_receipt(options.account_type, options.aid, options.sid, order.receipt_id)
    end
end

-- 处理接收中订单
plugin._handle_receiving_order = function(order, options)
    local create_time = tonumber(order.create_time)
    local now = os.time()
    -- 超过10分钟则关闭
    if now - create_time > 600 then -- 10分钟 = 600秒
        plugin._close_order(options.account_type, options.aid, options.sid, order.receipt_id)
    end
end

-- 处理成功订单
plugin._handle_success_order = function(order, options, accountInfo)
        -- 提取外部订单号
        local out_order_id = plugin._extract_order_id(order.remark)
        -- 如果订单不存在则录入
        if not plugin._is_order_exists(order, options, accountInfo) then
            plugin._insert_and_report_order(order, out_order_id, options, accountInfo)
        end

    -- 关闭订单
    plugin._close_order(options.account_type, options.aid, options.sid, order.receipt_id)
end

-- 从备注中提取订单号
plugin._extract_order_id = function(remark)
    local out_order_id = ""
    if remark then
        remark = string.gsub(remark, "请勿添加备注-", "")
        local matched, matchGroups = helper.regexp_match_group(remark, "^(?<order_id>\\d{20})$")
        if matched then
            if type(matchGroups) == "string" then
                matchGroups = json.decode(matchGroups)
            end
            if matchGroups["order_id"] then
                out_order_id = matchGroups["order_id"][1]
                log.info(string.format("正则匹配订单号: %s", out_order_id))
            end
        end
    end
    return out_order_id
end

plugin._get_third_order_id = function(order)
    return order.receipt_id or order.trans_id or order.id_v3
end

plugin._get_third_account = function(options)
    if plugin._get_pay_mode(options) == "smallbook" then
        return options.sid
    end
    return options.aid
end

plugin._get_order_amount = function(order)
    return order.fee or order.money or 0
end

plugin._get_order_remark = function(order)
    return order.remark or order.payer_remark or ""
end

plugin._get_order_time = function(order)
    return tonumber(order.create_time or order.timestamp or os.time())
end

plugin._get_order_type_name = function(options)
    if plugin._get_pay_mode(options) == "smallbook" then
        return "小账本收款"
    end
    return "收款单收款"
end

-- 检查订单是否存在
plugin._is_order_exists = function(order, options, accountInfo)
    return orderPayHelper.third_order_exist({
        pay_type = "wxpay",
        channel_code = PC_WECHAT_ALL_LZ,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        third_account = plugin._get_third_account(options),
        third_order_id = plugin._get_third_order_id(order)
    })
end

-- 插入并上报订单
plugin._insert_and_report_order = function(order, out_order_id, options, accountInfo)
    local thirdOrderId = plugin._get_third_order_id(order)
    local amount = plugin._get_order_amount(order)

    -- 录入数据
    local insertId = orderPayHelper.third_order_insert({
        pay_type = "wxpay",
        channel_code = PC_WECHAT_ALL_LZ,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        buyer_id = "",
        buyer_name = order.payer_nick_name or "",
        third_order_id = thirdOrderId,
        third_account = plugin._get_third_account(options),
        amount = amount,
        remark = plugin._get_order_remark(order),
        trans_time = plugin._get_order_time(order),
        type = plugin._get_order_type_name(options),
        out_order_id = out_order_id
    })

    -- 流水录入成功后统一上报，由系统按订单号或金额匹配
    if insertId > 0 then
        local err_code, err_message = orderPayHelper.third_order_report(insertId)
        if err_code == 200 then
            log.info(string.format("订单上报成功: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
                err_message, thirdOrderId, out_order_id, amount))
        else
            log.warning(string.format("订单上报失败: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
                err_message, thirdOrderId, out_order_id, amount))
        end
    else
        log.warning(string.format("订单录入失败, 模式: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
            plugin._get_pay_mode(options), thirdOrderId, out_order_id, amount))
    end
end

-- 获取小账本订单列表
plugin._get_smallbook_order_list = function(sid)
    local url = "https://payapp.weixin.qq.com/qrappzd/user/incomelistflexible"
    url = url .. "?sid=" .. sid
    url = url .. "&v=5.132.6"

    local now = os.time()
    local startTime = now - (now % 3600)
    local body = {
        v = "5.132.6",
        sid = sid,
        start_time = startTime,
        end_time = now,
        page_size = 10,
        sort = "desc",
        is_first = true,
        last_create_time = 0,
        last_id = ""
    }

    local resp = http.post(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Referer"] = "https://servicewechat.com/wx28be8489b7a36aaa/1061/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        },
        body = json.encode(body)
    })

    if resp.status_code ~= 200 then
        log.warning(string.format("[%s] 获取小账本订单列表失败,状态码:%d", PLUGIN, resp.status_code))
        return nil
    end

    if resp.body == "" then
        log.warning(string.format("[%s] 获取小账本订单列表失败,返回数据为空", PLUGIN))
        return nil
    end

    local data = json.decode(resp.body)
    if not data or (data.errcode ~= 0 and data.retcode ~= 0) then
        local errMessage = data and (data.msg or data.errmsg or "") or ""
        log.warning(string.format("[%s] 获取小账本订单列表失败,错误码:%d,错误信息:%s", PLUGIN,
            data and (data.errcode or data.retcode) or -1, errMessage))
        return nil, errMessage == "效验登录态失败"
    end

    local list = {}
    if data.data and data.data.data_list then
        for _, item in ipairs(data.data.data_list) do
            local fee = tonumber(item.fee or 0)
            table.insert(list, {
                receipt_id = item.trans_id or item.id_v3,
                trans_id = item.trans_id,
                id_v3 = item.id_v3,
                fee = fee,
                money = fee,
                create_time = item.timestamp,
                timestamp = item.timestamp,
                remark = item.payer_remark or "",
                payer_remark = item.payer_remark or "",
                payer_nick_name = item.payer_user_name or ""
            })
        end
    end

    return list
end

-- 获取商户ID
plugin._get_shop_id = function(sid, account_id, account_type)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        return nil
    end

    local url = string.format(
        gateway .. "/account/get?miniprogram_version=3.15.10&account_id=%s&account_type=%s&sid=%s", account_id,
        account_type, sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }

    local resp = http.get(url, {
        headers = headers
    })

    local success, data = plugin._check_http_response(resp, account_id, "获取商户ID")
    if not success then
        return nil
    end

    if data.data and data.data.auth_shop_list and #data.data.auth_shop_list > 0 then
        return data.data.auth_shop_list[1].shop_id
    end

    return nil
end

-- 获取订单列表
plugin._get_order_list = function(account_type, account_id, sid)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 获取订单列表 不支持的账号类型:%s", PLUGIN,
            account_id, account_type))
        return nil
    end

    local url = string.format(gateway .. "/receipt/list?account_type=%s&account_id=%s&sid=%s", account_type, account_id,
        sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }

    local body = {
        miniprogram_version = "3.15.10",
        start_time = 0,
        end_time = 0,
        page_size = 10,
        state = {},
        shop_id_list = {},
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success, data = plugin._check_http_response(resp, account_id, "获取订单列表")
    if not success then
        return nil
    end

    if data.data and data.data.receipt then
        -- 过滤掉 fee > 0 的数据
        local filtered = {}
        for _, receipt in ipairs(data.data.receipt) do
            if not receipt.fee or receipt.fee > 0 then
                table.insert(filtered, receipt)
            end
        end
        return filtered
    end

    return nil
end

-- 关闭订单
plugin._close_order = function(account_type, account_id, sid, receipt_id)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 关闭订单 不支持的账号类型:%s", PLUGIN, account_id,
            account_type))
        return false
    end

    local url = string.format(gateway .. "/receipt/close?account_type=%s&account_id=%s&sid=%s", account_type,
        account_id, sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Mac MacWechat/WMPF MacWechat/3.8.7(0x13080712) UnifiedPCMacWechat(0xf2640006) XWEB/11500",
        ["Content-Type"] = "application/json",
        ["Accept"] = "*/*",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html"
    }

    local body = {
        miniprogram_version = "3.15.10",
        receipt_id = receipt_id,
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success = plugin._check_http_response(resp, account_id, "关闭订单")
    return success
end

-- 删除订单
plugin._delete_receipt = function(account_type, account_id, sid, receipt_id)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 删除订单 不支持的账号类型:%s", PLUGIN, account_id,
            account_type))
        return false
    end

    local url = string.format(gateway .. "/receipt/del?account_type=%s&account_id=%s&sid=%s", account_type, account_id,
        sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Mac MacWechat/WMPF MacWechat/3.8.7(0x13080712) UnifiedPCMacWechat(0xf2640006) XWEB/11500",
        ["Content-Type"] = "application/json",
        ["Accept"] = "*/*",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html"
    }

    local body = {
        miniprogram_version = "3.15.10",
        receipt_id = receipt_id,
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success = plugin._check_http_response(resp, account_id, "删除订单")
    return success
end

-- 统一处理订单关闭和删除
plugin._handle_order_close_and_delete = function(account_type, account_id, sid, receipt_id)
    -- 先关闭订单
    if plugin._close_order(account_type, account_id, sid, receipt_id) then
        -- 关闭成功后删除
        plugin._delete_receipt(account_type, account_id, sid, receipt_id)
        return true
    end
    return false
end

return plugin


