---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local PAY_CHANNEL_CODE_YUN_WECHAT_XD = "yun_wechat_xd"

---@param v any
---@return table
local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

---@param body string
---@return table|nil
local function decodeBody(body)
    if not body or body == "" then
        return nil
    end
    local ok, data = pcall(json.decode, body)
    if ok and type(data) == "table" then
        return data
    end
    return nil
end

---@param value any
---@return boolean
local function isBlank(value)
    return value == nil or value == ""
end

---@param accountOptions table
---@return string
local function getLoginUid(accountOptions)
    local bindTokenInfo = toTable(accountOptions.bind_token)
    if not isBlank(bindTokenInfo.uid) then
        return bindTokenInfo.uid
    end
    if not isBlank(accountOptions.uid) then
        return accountOptions.uid
    end
    return ""
end

-- @class types.plugin
local plugin = {}

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        channels = {
            ["wxpay"] = { {
                label = "微信-Window云端-XD",
                value = PAY_CHANNEL_CODE_YUN_WECHAT_XD,
                options = {
                    use_add_amount = 1,
                    use_qrcode_login = 1
                }
            } }
        },
        options = {
            crontab_list = { {
                crontab = "*/10 * * * * *",
                fun = "cron",
                args = "",
                name = "检查账号状态",
                scope = "account",
                options = {
                    has_wait_pay_order = 0
                }
            } }
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = "gateway",
                label = "选择网关",
                type = types.InputTypes.SELECT,
                default = "",
                options = {
                    tip = "请选择离您最近的网关地址！",
                    chose_gateway = 1
                },
                placeholder = "请选择网关",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择"
                } }
            },
            {
                name = "uid",
                label = "登录UID",
                type = types.InputTypes.INPUT,
                default = "登录后自动获取",
                placeholder = "登录返回UID",
                options = {
                    tip = "收款单免输/个人动态码绑定客户端名称请设置：返回的UID收款单或个人码"
                }
            },
            {
                name = "qrcode",
                label = "收款码地址",
                type = types.InputTypes.INPUT,
                default = "",
                options = {
                    tip = "",
                    append_deqrocde = 1
                },
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.type == 'qrcode'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "qrcode_file",
                label = "收款码图片",
                type = types.InputTypes.IMAGE,
                default = "",
                options = {
                    tip = ""
                },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.type == 'image'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "type",
                label = "收款码类型",
                type = types.InputTypes.SELECT,
                default = "qrcode",
                options = {
                    tip = "支持/个人码/经营码/赞赏码/商家码/额外通道【自挂店员/拉卡拉/易生/新生易】需自行添加自挂通道！"
                },
                placeholder = "请选择收款码类型",
                values = { {
                    label = "二维码",
                    value = "qrcode"
                }, {
                    label = "二维码图片",
                    value = "image"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择类型"
                } }
            },
            {
                name = "bind_token",
                label = "绑定的用户信息",
                type = types.InputTypes.INPUT,
                default = "",
                hidden = 1
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local options = ctx.account_options or {}

    if options.type == "image" then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = options.qrcode_file,
                url = "",
                content = "",
                out_trade_no = ""
            }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = " " .. (options.qrcode or "") .. " ",
            url = "",
            content = "",
            out_trade_no = ""
        }
    }
end

-- 定时任务
---@param ctx types.CronAccountParams
---@return table
function plugin.cron(ctx)
    local vAccountInfo = toTable(ctx.account_info)
    local vParams = toTable(ctx.account_options)
    local vAccountOptions = toTable(vAccountInfo.options)

    local uid = getLoginUid(vParams)
    if isBlank(uid) then
        uid = getLoginUid(vAccountOptions)
    end

    if isBlank(uid) then
        return {
            code = 500,
            message = "未登录",
            data = {}
        }
    end

    local gateway = vParams.gateway
    if isBlank(gateway) then
        gateway = vAccountOptions.gateway
    end

    local serverAddress = helper.channel_gateway_addr(gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    local apiUri = string.format("%s/WeChat_Pc/IsLoginStatus", serverAddress)
    local response, error_message = http.request("POST", apiUri, {
        query = string.format("uid=%s", uid),
        timeout = "30s",
    })
    if error_message ~= nil then
        helper.channel_account_offline(vAccountInfo.id)
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code == nil then
        helper.channel_account_offline(vAccountInfo.id)
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    if returnInfo.code ~= "1" then
        helper.channel_account_offline(vAccountInfo.id)
        helper.channel_account_set_option(vAccountInfo.id, "bind_token", "")

        if returnInfo.code == "0" then
            return { code = 201, message = "请扫描二维码登录", data = {} }
        end
        if returnInfo.code == "-1" then
            return { code = 500, message = "uid参数错误", data = {} }
        end
        if returnInfo.code == "-2" then
            return { code = 500, message = "没有找到Uid", data = {} }
        end

        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    if vAccountInfo.online ~= 1 then
        helper.channel_account_online(vAccountInfo.id)
    end

    return {
        code = 200,
        message = "在线",
        data = {}
    }
end

-- 二维码登录
---@param ctx table
---@return table
function plugin.login_qrcode(ctx)
    local vParams = toTable(ctx.params)
    local vUserInfo = toTable(ctx.user_info)
    local vAccountInfo = toTable(ctx.account_info)
    local vAccountOption = toTable(vAccountInfo.options)

    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    local site = ""
    if ctx.device then
        site = ctx.device.base_url or ctx.device.domain or ctx.device.host or ""
    end
    if site == "" then
        site = vParams.domain_url or ""
    end

    local apiUri = string.format("%s/WeChat_Pc/CreateID", serverAddress)
    local req = {
        data = helper.base64_encode(json.encode({
            site = site,
            pid = vUserInfo.id,
            key = vUserInfo.app_secret
        }))
    }

    local response, error_message = http.request("POST", apiUri, {
        query = funcs.table_http_query(req),
        timeout = "30s",
    })
    if error_message ~= nil then
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code == nil then
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or ""),
            data = {}
        }
    end
    if returnInfo.code ~= "1" then
        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    local uid = returnInfo.uid
    helper.channel_account_set_option(vAccountInfo.id, "uid", uid)

    apiUri = string.format("%s/WeChat_Pc/QRCode", serverAddress)
    response, error_message = http.request("POST", apiUri, {
        query = string.format("uid=%s", uid),
        timeout = "30s",
    })
    if error_message ~= nil then
        return {
            code = 500,
            message = string.format("请求获取登录二维码错误: %s", error_message),
            data = {}
        }
    end

    returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code ~= "1" then
        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            qrcode = returnInfo.url,
            options = json.encode({
                uid = uid
            })
        }
    }
end

-- 检查二维码登录状态
---@param ctx table
---@return table
function plugin.login_qrcode_check(ctx)
    local vParams = toTable(ctx.params)
    local vAccountInfo = toTable(ctx.account_info)
    local vAccountOption = toTable(vAccountInfo.options)

    local uid = vParams.uid
    if isBlank(uid) then
        uid = getLoginUid(vAccountOption)
    end

    if isBlank(uid) then
        return {
            code = 201,
            message = "请扫描二维码登录",
            data = {}
        }
    end

    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    local apiUri = string.format("%s/WeChat_Pc/IsLoginStatus", serverAddress)
    local response, error_message = http.request("POST", apiUri, {
        query = string.format("uid=%s", uid),
        timeout = "30s",
    })
    if error_message ~= nil then
        return {
            code = 500,
            message = string.format("请求错误: %s", error_message),
            data = {}
        }
    end

    local returnInfo = decodeBody(response.body)
    if not returnInfo or returnInfo.code == nil then
        return {
            code = 500,
            message = string.format("请求响应错误,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    if returnInfo.code ~= "1" then
        if returnInfo.code == "0" then
            return { code = 201, message = "请扫描二维码登录", data = {} }
        end
        if returnInfo.code == "-1" then
            return { code = 500, message = "uid参数错误", data = {} }
        end
        if returnInfo.code == "-2" then
            return { code = 500, message = "没有找到Uid", data = {} }
        end

        return {
            code = 500,
            message = string.format("返回错误状态码,响应内容: %s", response.body or ""),
            data = {}
        }
    end

    helper.channel_account_set_option(vAccountInfo.id, "uid", uid)
    helper.channel_account_set_option(vAccountInfo.id, "bind_token", json.encode({
        uid = uid
    }))

    return {
        code = 200,
        message = "登录成功",
        data = {}
    }
end

return plugin
