---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 微信-JSAPI
local PAY_WXPAY_JSAPI = "wxpay_jsapi"

-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["wxpay"] = { {
                label = '微信-JSAPI',
                value = PAY_WXPAY_JSAPI
            } }
        },
        options = {
            callback = 1,
            detection_interval = 0,
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'appid',
                label = '公众号ID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "公众号ID",
                options = {
                    tip = '如: wxxxxx'
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'app_secret',
                label = '公众号Secret',
                type = types.InputTypes.INPUT,
                hidden_list = 1,
                default = "",
                placeholder = "公众号Secret",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'mchid',
                label = '商户ID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "商户ID 或者服务商模式的 sp_mchid",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'serial_no',
                label = '证书序列号',
                type = types.InputTypes.INPUT,
                hidden_list = 1,
                default = "",
                placeholder = "商户API证书的证书序列号",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'api_v3_key',
                label = '商户APIV3Key',
                type = types.InputTypes.INPUT,
                default = "",
                hidden_list = 1,
                placeholder = "商户平台获取",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'private_key',
                label = '商户API证书私钥',
                type = types.InputTypes.TEXTAREA,
                default = "",
                hidden_list = 1,
                placeholder = "商户API证书下载后，私钥 apiclient_key.pem 读取后的字符串内容",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'public_key',
                label = '证书公钥',
                type = types.InputTypes.TEXTAREA,
                default = "",
                hidden_list = 1,
                placeholder = "商户API证书下载后，私钥 apiclient_key.pem 读取后的字符串内容",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'public_key_id',
                label = '微信支付公钥ID',
                type = 'input',
                default = "",
                hidden_list = 1,
                placeholder = "微信支付->API安全->微信支付公钥,前缀为:PUB_KEY_ID_",
                options = {
                    tip = '推荐填写,不填写的话是使用的平台证书,新账号请推荐填写',
                },
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options
    local vDeviceInfo = ctx.device

    if vDeviceInfo.is_mobile == false then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode = "/api/pay/toapp/" .. vOrderInfo.order_id,
                qrcode_use_short_url = 1,
                url = "",
                content = "",
                out_trade_no = "",
                options = {
                    to_app_create = 1
                }
            }
        }
    end

    if vDeviceInfo.is_wechat == false then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.HTML,
                options = {
                    to_app_create = 1
                }
            }
        }
    end

    if vOrderInfo.third_open_id == "" then
        return {
            code = 200,
            message = "需要授权获取OpenId",
            data = {
                type = types.PaymentResultTypes.JUMP,
                url = "/api/pay/toapp/" .. vOrderInfo.order_id,
                qrcode_use_short_url = 1,
                options = {
                    to_app_create = 1,
                    need_wechat_openid = 1,
                    use_wechat_self = 1,
                    wechat_app_id = vAccountOptions.appid,
                    wechat_app_secret = vAccountOptions.app_secret
                }
            }
        }
    end

    local err_code, err_message, result = orderPayHelper.wxpay_jsapi_create(vOrderInfo, vAccountOptions)

    if err_code ~= 200 then
        return {
            code = 500,
            message = err_message,
            data = {
                type = types.PaymentResultTypes.HTML
            }
        }
    elseif err_code == 200 then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.HTML,
                qrcode = "",
                qrcode_use_short_url = 0,
                url = "",
                content = plugin.buildHtml(vOrderInfo.order_id, result, vOrderInfo.return_url),
                out_trade_no = ""
            }
        }
    end

    return {
        code = 500,
        message = '创建支付失败',
        data = {
            type = types.PaymentResultTypes.HTML
        }
    }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    local vRequest = ctx.request
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local err_code, err_message, response = orderPayHelper.wxpay_jsapi_notify(vRequest, vOrderInfo, vAccountOptions)

    return {
        code = err_code,
        message = err_message,
        data = { response = response }
    }
end

-- 生成网页
---@param orderId string
---@param result string
---@param redirectUri string
---@return string
function plugin.buildHtml(orderId, result, redirectUri)
    return [[
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
    <title>微信支付手机版</title>
</head>
<body style="    text-align: center;">
<div class="bar bar-header bar-light" align-title="center">
	<h1 class="title">微信支付</h1>
</div>
<div class="has-header" style="padding: 5px;position: absolute;width: 100%;">
<div class="text-center" style="
    display: flex;
    align-items: center;
    flex-direction: column;">
<div class="text-center" style="font-size: 80px;
    background-color: #19ac1a;
    border-radius: 100%;
    width: 80px;
    height: 80px;
    display: flex;
    justify-content: center;
    text-align: center;
    color: white;
    align-items: center;">i</div><br>
<span>正在跳转...</span>

<script src="/plugins/pay/wxpay_jsapi/assets/js/jquery.min.js"></script>
<script src="/plugins/pay/wxpay_jsapi/assets/js/layer/layer.js"></script>
<script>
	document.body.addEventListener('touchmove', function (event) {
		event.preventDefault();
	},{ passive: false });
    //调用微信JS api 支付
	function jsApiCall()
	{
		WeixinJSBridge.invoke(
			'getBrandWCPayRequest',
			]] .. result .. [[,
			function(res){
				if(res.err_msg == "get_brand_wcpay_request:ok" ) {
		            loadmsg();
				}
				//WeixinJSBridge.log(res.err_msg);
				//alert(res.err_code+res.err_desc+res.err_msg);
			}
		);
	}

	function callpay()
	{
		if (typeof WeixinJSBridge == "undefined"){
		    if( document.addEventListener ){
		        document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
		    }else if (document.attachEvent){
		        document.attachEvent('WeixinJSBridgeReady', jsApiCall);
		        document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
		    }
		}else{
		    jsApiCall();
		}
	}
    // 检查是否支付完成
    function loadmsg() {
        $.ajax({
            type: "POST",
            dataType: "json",
            url: "/api/order/status",
            timeout: 10000, //ajax请求超时时间10s
            data: { order_id: "]] .. orderId .. [["}, //post数据
            success: function (data, textStatus) {
                //从服务器得到数据，显示数据并继续查询
                if (data.code == 200 && data.data.status == 2) {
					layer.msg('支付成功，正在跳转中...', {icon: 16,shade: 0.01,time: 15000});
                    window.location.href= data.data.return_uri;
                }else{
                    setTimeout("loadmsg()", 2000);
                }
            },
            //Ajax请求超时，继续查询
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (textStatus == "timeout") {
                    setTimeout("loadmsg()", 1000);
                } else { //异常
                    setTimeout("loadmsg()", 3000);
                }
            }
        });
    }
    window.onload = callpay();
</script>
</div>
</div>
</body>
</html>
    ]]
end

return plugin
