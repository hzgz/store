---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 支付宝-当面付
local PAY_ALIPAY_DMF = "alipay_dmf"

-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["alipay"] = { {
                label = '当面付',
                value = PAY_ALIPAY_DMF,
                options = {
                    qrcode_use_short_url = 0 -- 使用官方地址跳转
                }
            } }
        },
        options = {
            callback = 1,
            detection_interval = 0,
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'app_id',
                label = '应用ID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入应用ID",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'app_secret',
                label = '应用私钥',
                type = types.InputTypes.TEXTAREA,
                hidden_list = 1,
                default = "",
                placeholder = "请输入应用私钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'alipay_public',
                label = '支付宝公钥',
                type = types.InputTypes.TEXTAREA,
                hidden_list = 1,
                default = "",
                placeholder = "请输入支付宝公钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local err_code, err_message, result = orderPayHelper.alipay_dmf_create(vOrderInfo, vAccountOptions)

    if err_code ~= 200 then
        return {
            code = 500,
            message = err_message,
            data = {
                type = types.PaymentResultTypes.QRCODE
            }
        }
    elseif err_code == 200 then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode = result,
                scheme = "alipayqr://platformapi/startapp?saId=10000007&qrcode=" .. helper.url_encode(result),
                url = "",
                content = "",
                out_trade_no = ""
            }
        }
    end

    return {
        code = 500,
        message = '创建支付失败',
        data = {
            type = types.PaymentResultTypes.QRCODE
        }
    }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    local vRequest = ctx.request
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local err_code, err_message, response = orderPayHelper.alipay_dmf_notify(vRequest, vOrderInfo, vAccountOptions)

    return {
        code = err_code,
        message = err_message,
        data = { response = response }
    }
end

return plugin

