---@diagnostic disable: undefined-global
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")
local resp = response

---@class plugin
local plugin = {
    info = {
        channels = {
            storage = {
                {
                    label = "兰空图床",
                    value = "default",
                    info = "兰空图床 token 上传",
                    capabilities = { "server_upload", "delete" }
                }
            }
        },
        options = {
            support_server_upload = 1,
            support_client_direct = 0,
            support_delete = 1,
        }
    }
}

function plugin.pluginInfo()
    return plugin.info
end

function plugin.formItems(ctx)
    local _ = ctx
    return {
        inputs = {
            {
                name = "domain",
                label = "站点域名",
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "如 https://img.example.com (兰空站点根地址)",
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入兰空站点域名" } }
            },
            {
                name = "token",
                label = "接口Token",
                type = types.InputTypes.INPUT,
                default = "",
                hidden_list = 1,
                placeholder = "兰空后台生成的 API Token (不含 Bearer)",
                options = { tip = "在兰空后台 -> 接口 Tokens 生成" },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入接口Token" } }
            },
            {
                name = "strategy_id",
                label = "存储策略ID",
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "多策略或默认策略上传报错时必填, 如 1 (兰空 存储策略 页查看)",
                options = { tip = "兰空后台 -> 存储策略 里的ID; 部分站点不带会返回服务异常" }
            }
        }
    }
end

-- 去掉末尾斜杠
local function trim_slash(s)
    return (tostring(s or ""):gsub("/+$", ""))
end

--- 生成上传签名描述符(服务端上传)
function plugin.signUpload(ctx)
    if type(ctx) ~= "table" then
        return resp.error("ctx 必须为 table", 400)
    end
    local opt = ctx.plugin_options or {}
    local domain = trim_slash(opt.domain)
    local token = tostring(opt.token or "")
    if domain == "" or token == "" then
        return resp.error("兰空图床配置不完整(domain/token)", 500)
    end
    -- 部分兰空站点要求指定存储策略, 配置了才带
    local form_fields = {}
    local strategy_id = tostring(opt.strategy_id or "")
    if strategy_id ~= "" then
        form_fields["strategy_id"] = strategy_id
    end
    return resp.success({
        upload = {
            url = domain .. "/api/v1/upload",
            method = "POST",
            headers = {
                ["Authorization"] = "Bearer " .. token,
                ["Accept"] = "application/json"
            },
            body_field = "file",
            form_fields = form_fields,
            result_url_json_path = "data.links.url",
            result_key_json_path = "data.key"
        },
        public_url = ""
    }, "ok")
end

--- 生成删除签名描述符
function plugin.signDelete(ctx)
    if type(ctx) ~= "table" then
        return resp.error("ctx 必须为 table", 400)
    end
    local opt = ctx.plugin_options or {}
    local domain = trim_slash(opt.domain)
    local token = tostring(opt.token or "")
    local key = tostring(ctx.object_key or "")
    if domain == "" or token == "" or key == "" then
        return resp.error("删除参数不完整", 500)
    end
    return resp.success({
        delete = {
            url = domain .. "/api/v1/images/" .. key,
            method = "DELETE",
            headers = {
                ["Authorization"] = "Bearer " .. token,
                ["Accept"] = "application/json"
            }
        }
    }, "ok")
end

return plugin
