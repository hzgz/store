-- 监控插件 - 微信自挂
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

-- 唯一通道标识
local CHANNEL_CODE = "wxpay_app_monitor"

-- 二维码类型常量
local QRCODE_TYPES = {
    PERSONAL   = "personal",    -- 个人码
    ZANSHANG   = "zanshang",    -- 赞赏码
    CLERK      = "clerk",       -- 店员码
    BUSINESS   = "business",    -- 商业码
    RECEIPT    = "receipt",     -- 收款单
    OPERATE    = "operate",     -- 经营码
    WEWORK     = "wework",      -- 企业微信
}

local plugin = {}

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    local info = {
        channels = {
            wxpay = {
                {
                    label = '软件自挂',
                    value = CHANNEL_CODE,
                    report = 1,
                    parse_msg = 1,
                    options = {
                        use_add_amount = 1,
                        use_pay_codes = 1
                    }
                },
            }
        },
        options = {
            callback = 0,
            detection_interval = 0,
        }
    }
    return info
end

--- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    if ctx.pay_channel ~= CHANNEL_CODE then
        return {}
    end

    return {
        inputs = {
            {
                name = 'qrcode_type',
                label = '二维码类型',
                type = types.InputTypes.SELECT,
                default = QRCODE_TYPES.PERSONAL,
                placeholder = "请选择二维码类型",
                values = {
                    { label = '个人码',   value = QRCODE_TYPES.PERSONAL },
                    { label = '赞赏码',   value = QRCODE_TYPES.ZANSHANG },
                    { label = '店员码',   value = QRCODE_TYPES.CLERK },
                    { label = '商业码',   value = QRCODE_TYPES.BUSINESS },
                    { label = '收款单',   value = QRCODE_TYPES.RECEIPT },
                    { label = '经营码',   value = QRCODE_TYPES.OPERATE },
                    { label = '企业微信', value = QRCODE_TYPES.WEWORK },
                },
                rules = {
                    { required = true, trigger = { "change" }, message = "请选择二维码类型" }
                }
            },
            {
                name = 'type',
                label = '收款码类型',
                type = types.InputTypes.SELECT,
                default = "url",
                placeholder = "请选择收款码类型",
                when = "this.formModel.options.qrcode_type != 'zanshang'",
                values = {
                    { label = "地址", value = "url" },
                    { label = "图片", value = "image" },
                },
                rules = {
                    { required = true, trigger = { "change" }, message = "请选择" }
                }
            },
            {
                name = 'qrcode',
                label = '收款码地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.type == 'url' && this.formModel.options.qrcode_type != 'zanshang'",
                options = {
                    append_deqrocde = 1,
                    tip = ''
                },
                rules = {
                    { required = true, trigger = { "input", "blur" }, message = "请输入" }
                }
            },
            {
                name = 'qrcode_file',
                label = '收款码图片',
                type = types.InputTypes.IMAGE,
                default = "",
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.type == 'image' || this.formModel.options.qrcode_type == 'zanshang'",
                options = {
                    tip = ''
                },
                rules = {
                    { required = true, trigger = { "input", "blur" }, message = "请上传" }
                }
            },
        }
    }
end

--- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vAccountOptions = ctx.account_options

    if vAccountOptions['type'] == 'image' then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = vAccountOptions['qrcode_file'],
                url = "",
                content = "",
                out_trade_no = '',
            }
        }
    end

    local qrcode = vAccountOptions['qrcode']
    if qrcode == nil or qrcode == '' then
        return {
            code = 500,
            message = "收款码地址不能为空",
            data = { type = types.PaymentResultTypes.ERROR }
        }
    end

    -- 非http链接前后加空格
    if not string.match(qrcode, "^http") then
        qrcode = " " .. qrcode .. " "
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = qrcode,
            url = "",
            content = "",
            out_trade_no = '',
        }
    }
end

--- 支付回调
---@param ctx types.OrderNotifyParams
---@return types.OrderNotifyResp
function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = { response = "" }
    }
end

--- 解析上报数据
---@param msg string
---@return table
function plugin.parseMessage(msg)
    local Key_Config = {
        {
            title_reg = "微信收款助手|微信支付",
            content_reg = "^(?:\\[\\d+条\\]微信收款助手: )?微信支付收款(?<amount>[\\d\\.]+)元",
            channel_code = CHANNEL_CODE
        },
        {
            title_reg = "微信收款助手|微信支付",
            content_reg = "(?:二维码赞赏到账|\\[店员消息\\]收款到账|收款单到账)(?<amount>[\\d\\.]+)元",
            channel_code = CHANNEL_CODE
        },
        {
            title_reg = "微信支付|微信收款商业版",
            content_reg = "(?:个人收款码到账¥|收款(?:¥|￥|)?)(?<amount>[\\d\\.]+)",
            channel_code = CHANNEL_CODE
        },
        {
            title_reg = "收款通知",
            content_reg = "微信收款商业版: 收款(?<amount>[\\d\\.]+)元",
            channel_code = CHANNEL_CODE
        },
        {
            title_reg = "对外收款",
            content_reg = "^(?:\\[\\d+条\\])?收款通知：[\\s\\S]*?已收款(?<amount>[\\d\\.]+)元",
            channel_code = CHANNEL_CODE
        },
    }

    local reportApps = {
        ["com.tencent.mm"] = Key_Config,
        ["com.tencent.wework"] = Key_Config,
    }

    return message_parser.parse(msg, reportApps)
end

return plugin
