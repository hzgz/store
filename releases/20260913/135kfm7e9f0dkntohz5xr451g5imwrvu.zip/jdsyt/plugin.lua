---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

-- 渠道 京东收银台
-- @class plugin
local plugin = {}

PAY_BANK_JDSYT = "bank_jdsyt"

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["bank"] = { {
                label = '京东收银台',
                value = PAY_BANK_JDSYT,
                -- 绑定支付方式
                bind_pay_type = { "alipay", "wxpay", "bank" }
            } }
        },
        options = {
            -- 检查任务时间
            detection_interval = 3,
            -- 检查任务类型
            detection_type = "order" --- order 单订单检查 cron 定时执行任务
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'number',
                label = '设备ID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请填写京东收银台设备ID",
                options = {
                    append_deqrocde = 1, -- 增加解析二维码功能
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = plugin.getQrcode(vOrderInfo, vAccountOptions),
            url = "",
            content = "",
            out_trade_no = ''
        }
    }
end

-- 获取支付码
---@param orderInfo table
---@param pluginOptions table
---@return string
function plugin.getQrcode(orderInfo, pluginOptions)
    return string.format("https://order.duolabao.com/active/c?state=%s%%7C%s%%7C%.2f%%7C%%7CAPI",
        orderInfo["order_id"],
        pluginOptions['number'],
        orderInfo['trade_amount'] / 100)
end

-- 定期执行
function plugin.cron()
end

-- 检查单个订单
---@param ctx table 单订单检测上下文, 含 order_info / account_options
---@return string
function plugin.checkOrder(ctx)
    local orderInfo = ctx.order_info
    if orderInfo and orderInfo["out_pay_data"] then
        -- jdsyt_check 返回两个值: code(数字), message(字符串)
        local err_code, err_message = orderPayHelper.jdsyt_check(orderInfo, ctx.account_options)
        -- 引擎要求返回 table(映射为 PluginBaseRet{code,message,data}), 不能返回 json 字符串
        return {
            code = err_code,
            message = err_message
        }
    end
    return {
        code = 500,
        message = "暂不支持"
    }
end

return plugin
