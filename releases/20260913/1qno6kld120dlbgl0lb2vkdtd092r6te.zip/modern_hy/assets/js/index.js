(function () {
  'use strict';

  /* ======================================================
   * 工具函数
   * ====================================================== */
  /* 安全元素获取：独立页面（separate）缺少部分元素时返回隐藏空 div，
     避免 .hidden / .textContent / .classList 等操作抛异常 */
  var _safeEl = document.createElement('div');
  _safeEl.hidden = true;
  function $(id) { return document.getElementById(id) || _safeEl; }

  /* HTML 转义：防止后端返回的数据含恶意标签注入 innerHTML */
  function esc(str) {
    var d = document.createElement('div');
    d.textContent = String(str == null ? '' : str);
    return d.innerHTML;
  }

  /* 安全 decodeURIComponent：非法 % 编码（如 %ZZ）不抛异常，返回原值 */
  function safeDecode(s) {
    try { return decodeURIComponent(s); } catch (e) { return s; }
  }

  /* 安全跳转：过滤 javascript:/data:/vbscript: 等危险协议，防止移动端 XSS */
  function safeRedirect(url) {
    if (!url) return;
    if (/^\s*(javascript|data|vbscript):/i.test(url)) return;
    try { window.location.href = url; } catch (e) { /* 无效 URI 忽略 */ }
  }

  /* scheme 唤起（alipays:// / weixin:// 等）：
     用隐藏 iframe 加载 scheme URL，主页面不导航（不离开收银台），
     用户支付完返回浏览器仍是原始页面。
     避免了 window.location.href 方式导致浏览器暂停定时器的问题，
     也避免了 <a target="_blank"> 方式打开空白标签页的问题。 */
  /* 判断是否需要用 location.href 拉起 scheme（iframe 被拦截的环境）：
     iOS 全平台浏览器（共用 WebKit）+ macOS Safari 禁止 iframe 加载自定义 scheme，
     必须用 window.location.href 才能拉起 App。其他浏览器继续用 iframe，不离开收银台。 */
  function isSchemeLocationEnv() {
    var ua = navigator.userAgent;
    var isIOS = /iPhone|iPad|iPod/i.test(ua) ||
                (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    var isMacSafari = /Safari/i.test(ua) && !/Chrome|CriOS|Chromium|Edg|OPR|Android/i.test(ua);
    return isIOS || isMacSafari;
  }

  /* 唤起 scheme：iOS/Safari 用 location.href，其他浏览器用隐藏 iframe（不离开页面） */
  function launchScheme(url) {
    if (!url) return;
    if (/^\s*(javascript|data|vbscript):/i.test(url)) return;
    if (isSchemeLocationEnv()) { window.location.href = url; return; }
    var iframe = document.createElement('iframe');
    iframe.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:1px;height:1px;border:0;';
    iframe.src = url;
    document.body.appendChild(iframe);
    setTimeout(function () { if (iframe.parentNode) iframe.parentNode.removeChild(iframe); }, 3000);
  }

  var IS_MOBILE = navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i) != null;

  /* 演示模式：URL 带 ?demo，或本地环境（localhost / 127.0.0.1 / file 协议）时自动启用，使用模拟数据 */
  var IS_DEMO = (function () {
    try {
      if (new URLSearchParams(location.search).has('demo')) return true;
      if (location.protocol === 'file:') return true;
      return /^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname);
    } catch (e) { return false; }
  })();

  /* 复制文本到剪贴板（兼容旧浏览器） */
  function copyText(text) {
    return new Promise(function (resolve) {
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text || '').then(resolve, resolve);
          return;
        }
        var ta = document.createElement('textarea');
        ta.setAttribute('readonly', 'readonly');
        ta.value = text || '';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        resolve();
      } catch (e) { resolve(); }
    });
  }

  /* 秒数格式化为 "X天 X小时 X分 X秒" */
  function formatRemain(sec) {
    var d = Math.floor(sec / 86400);
    var h = Math.floor(sec % 86400 / 3600);
    var m = Math.floor(sec % 3600 / 60);
    var s = sec % 60;
    var out = '';
    if (d > 0) out += d + '天 ';
    if (h > 0 || d > 0) out += h + '小时 ';
    if (m > 0 || h > 0 || d > 0) out += m + '分 ';
    if (s > 0 || m > 0 || h > 0 || d > 0) out += s + '秒';
    return out.trim() || '0秒';
  }

  /* 分 → 元，拆分整数与小数部分 */
  function splitAmount(fen) {
    var yuan = (Number(fen || 0) / 100).toFixed(2);
    var idx = yuan.lastIndexOf('.');
    return { int: yuan.slice(0, idx), dec: yuan.slice(idx) };
  }

  /* ======================================================
   * Toast 轻提示
   * ====================================================== */
  var toastWrap = $('toastWrap');
  var ICON_CHECK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00b42a" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
  function toast(message, type) {
    var el = document.createElement('div');
    el.className = 'toast ' + (type || 'info');
    el.innerHTML = '<span class="dot"></span><span></span>';
    el.lastChild.textContent = message;
    toastWrap.appendChild(el);
    setTimeout(function () {
      el.classList.add('out');
      setTimeout(function () { el.remove(); }, 260);
    }, 2600);
  }

  /* ======================================================
   * API 封装（约定与官方模板一致：baseURL /api，POST JSON，带 token 与时间戳）
   * ====================================================== */
  function apiPost(path, data) {
    if (IS_DEMO) return demoApi(path, data);
    return fetch('/api' + path + '?_t=' + Date.now(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': localStorage.getItem('token') || ''
      },
      body: JSON.stringify(data || {})
    }).then(function (res) {
      if (res.status === 500) return { code: 500, message: '服务器异常', data: null };
      return parseJson(res);
    }).catch(function () {
      return Promise.reject(new Error('网络请求失败'));
    });
  }

  function apiGet(path) {
    if (IS_DEMO) return demoApi(path);
    return fetch('/api' + path + '?_t=' + Date.now(), {
      headers: {
        'Authorization': localStorage.getItem('token') || '',
        'X-Requested-With': 'XMLHttpRequest'
      }
    }).then(function (res) {
      if (res.status === 500) return { code: 500, message: '服务器异常', data: null };
      return parseJson(res);
    }).catch(function () {
      return Promise.reject(new Error('网络请求失败'));
    });
  }

  /* 安全解析 JSON：后端返回 HTML 错误页（如登录过期 401）时 res.json() 会抛异常，
     此时读取文本内容返回友好错误，避免被吞为"网络请求失败" */
  function parseJson(res) {
    return res.text().then(function (text) {
      try {
        return JSON.parse(text);
      } catch (e) {
        return { code: res.status, message: '服务异常（' + res.status + '）', data: null };
      }
    });
  }

  /* ======================================================
   * 演示模式模拟数据
   * ====================================================== */
  var DEMO_ORDER_ID = '2026082415203947268';
  var demoState = { payType: 'alipay', status: 1, qrMode: 'qrcode' };
  /* 演示用固定过期时间（每次 refreshAll 时重置），避免轮询每秒刷新导致倒计时不递减 */
  var demoExpireTime = Math.floor(Date.now() / 1000) + 1799;

  var DEMO_PAY_CONF = {
    alipay: { name: '支付宝',   amount: 12800,
      qr: { type: 'qrcode', qrcode: 'https://qr.alipay.com/demo-128-00', scheme: 'alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=https%3A%2F%2Fqr.alipay.com%2Ffkx1620528arg23cofoxnf6%3F_s%3Dweb-other' },
      pay_tip: '请使用 <b>支付宝</b> 扫码完成支付，转账时请勿备注任何敏感信息，支付成功后自动到账。',
      account_tip: '收款账户：支付宝（官方通道）｜支持余额、花呗、银行卡付款' },
    wxpay: { name: '微信支付', amount: 12800,
      qr: { type: 'qrcode', qrcode: 'wxp://f2f-demo-128-00' },
      pay_tip: '请使用 <b>微信</b> 扫码完成支付，支付成功后请耐心等待页面自动跳转，请勿重复付款。',
      account_tip: '收款账户：微信支付（官方通道）｜支持零钱、银行卡付款' },
    bank:   { name: '云闪付',   amount: 12800,
      qr: { type: 'qrcode', qrcode: 'https://qr.unionpay.com/demo-128-00' },
      pay_tip: '请使用 <b>云闪付</b> 或各大银行 App 扫码完成支付，单笔限额 5 万元。',
      account_tip: '收款账户：银联（官方通道）｜支持云闪付、银行 App 扫码' },
    qqpay:  { name: 'QQ钱包',   amount: 12800,
      qr: { type: 'qrcode', qrcode: 'https://qpay.qq.com/demo-128-00' },
      pay_tip: '请使用 <b>QQ</b> 扫码完成支付，付款时请确认收款方为本订单对应商户。',
      account_tip: '收款账户：QQ钱包（官方通道）｜支持 QQ 钱包余额付款' },
    usdt:   { name: 'USDT',     amount: 3520,
      qr: { type: 'qrcode', qrcode: 'TXk9fZq7Bm3RyW2eLpQ8dJ4cVn6XuH1sAo9mQ',
            actual_amount: '35.20', actual_account: 'TXk9fZq7Bm3RyW2eLpQ8dJ4cVn6XuH1sAo9mQ', actual_account_type: 'TRC20' },
      pay_tip: '请务必按 <b>应付金额</b> 转账（可多付不可少付），转账完成后一般 1-5 分钟内到账，请勿关闭本页面。',
      account_tip: '收款账户：USDT-TRC20｜请仔细核对网络类型，转错网络将无法到账' }
  };

  /* 演示回调地址：跳回本页并带 jumped 标记，便于演示"支付成功后自动跳转" */
  function demoReturnUri() {
    return window.location.origin + window.location.pathname + '?demo&jumped=1';
  }

  function demoApi(path) {
    return new Promise(function (resolve) {
      setTimeout(function () {
        if (path === '/config') {
          resolve({ code: 200, data: { web_title: '云品优选', web_service_qq: '8008208820' } });
        } else if (path === '/order/info') {
          var conf = DEMO_PAY_CONF[demoState.payType] || DEMO_PAY_CONF.alipay;
          resolve({ code: 200, data: {
            order_id: DEMO_ORDER_ID, out_order_id: 'SHOP202608241539',
            subject: '超级会员年卡（12个月）× 1',
            trade_amount: conf.amount, amount: conf.amount,
            status: demoState.status, pay_type: demoState.payType,
            pay_type_text: conf.name,
            service_qq: '',
            pay_tip: conf.pay_tip || '',
            pay_account_tip: { tip: conf.account_tip || '', tip_cover: 0 },
            expire_time: demoExpireTime,
            return_uri: demoReturnUri(), pay_payed_wait_time: 3,
            create_time: '2026-08-24 15:20:39'
          } });
        } else if (path === '/order/status') {
          resolve({ code: 200, data: { status: demoState.status, expire_time: demoExpireTime, return_uri: demoReturnUri(), pay_payed_wait_time: 3 } });
        } else if (path === '/order/audio') {
          resolve({ code: 200, data: { audio_enable: 1, audio_url: 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhAAQABAAgAZAB0A' } });
        } else if (path === '/order/qrcode') {
          var conf2 = DEMO_PAY_CONF[demoState.payType] || DEMO_PAY_CONF.alipay;
          var qr = {};
          for (var k in conf2.qr) qr[k] = conf2.qr[k];
          /* 演示二维码模式：qrcode(默认) / scheme(含唤起scheme) / jump(跳转支付) */
          if (demoState.qrMode === 'scheme') {
            qr.scheme = 'alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=' + encodeURIComponent(qr.qrcode || 'https://qr.alipay.com/demo');
          } else if (demoState.qrMode === 'jump') {
            /* 演示用本地 jump：标记 jumpToUri 显示加载层但不实际跳走 */
            qr = { type: 'jump', uri: demoReturnUri() + '&jumped=1' };
          }
          resolve({ code: 200, data: qr });
        } else if (path === '/pay/types') {
          resolve({ code: 200, data: [
            { value: 'alipay', label: '支付宝' },
            { value: 'wxpay',  label: '微信支付' },
            { value: 'bank',   label: '云闪付' },
            { value: 'qqpay',  label: 'QQ钱包' },
            { value: 'usdt',   label: 'USDT' }
          ] });
        } else if (path === '/order/chose-type') {
          resolve({ code: 200, data: null });
        } else {
          resolve({ code: 404, message: '演示模式无此接口', data: null });
        }
      }, 260);
    });
  }

  /* ======================================================
   * 品牌配色（根据 pay_type 推断主色，图标一律使用文字徽章）
   * ====================================================== */
  var BRANDS = {
    alipay: { color: '#1677ff', grad: 'linear-gradient(135deg, #3f9bff, #1677ff)', rgb: '22,119,255', char: '支', scheme: 'alipays://' },
    wxpay:  { color: '#07c160', grad: 'linear-gradient(135deg, #2ed573, #07c160)', rgb: '7,193,96',   char: '微', scheme: 'weixin://' },
    bank:   { color: '#e60012', grad: 'linear-gradient(135deg, #ff6b6e, #e60012)', rgb: '230,0,18',   char: '闪', scheme: 'upwallet://' },
    usdt:   { color: '#26a17b', grad: 'linear-gradient(135deg, #3fc397, #26a17b)', rgb: '38,161,123', char: '₮' },
    qqpay:  { color: '#12b7f5', grad: 'linear-gradient(135deg, #4ed0f7, #12b7f5)', rgb: '18,183,245', char: 'Q', scheme: 'mqq://' }
  };
  var BRAND_DEFAULT = { color: '#1677ff', grad: 'linear-gradient(135deg, #3f9bff, #1677ff)', rgb: '22,119,255', char: '付' };

  function getBrand(payType, payTypeText) {
    var t = String(payType || '').toLowerCase();
    for (var key in BRANDS) if (t.indexOf(key) !== -1) return BRANDS[key];
    /* 值匹配不到时，按支付方式名称关键词兜底匹配（覆盖系统自定义 value，如网银/银联通道） */
    var txt = String(payTypeText || '');
    if (/支付宝/.test(txt)) return BRANDS.alipay;
    if (/微信/.test(txt)) return BRANDS.wxpay;
    if (/云闪付|银联|网银|银行卡/.test(txt)) return BRANDS.bank;
    if (/QQ/i.test(txt)) return BRANDS.qqpay;
    if (/USDT/i.test(txt)) return BRANDS.usdt;
    return BRAND_DEFAULT;
  }

  /* 获取可用的 scheme：后端传的优先，否则用支付方式对应的默认 scheme（用于移动端唤起 App） */
  function getResolvedScheme() {
    var backend = (state.qrInfo || {}).scheme;
    if (backend) return backend;
    var brand = getBrand(state.orderInfo && state.orderInfo.pay_type, state.orderInfo && state.orderInfo.pay_type_text);
    return brand.scheme || '';
  }

  /* ======================================================
   * 状态映射
   * ====================================================== */
  /* 文案对齐 default 模板状态页：标题 + 按状态副标题 */
  var STATUS_META = {
    1: { title: '待支付', sub: '尚未支付完成', icon: 'timeout' },
    2: { title: '支付成功', sub: '欢迎下次光临', icon: 'success' },
    3: { title: '支付关闭', sub: '请重新支付', icon: 'error' },
    4: { title: '支付超时', sub: '订单支付超时，请重新支付', icon: 'timeout' },
    5: { title: '创建失败', sub: '请重新支付', icon: 'error' }
  };

  /* ======================================================
   * 页面状态
   * ====================================================== */
  var state = {
    orderId: '',
    pageType: 'cashier',   /* cashier=收银台 separate=选择支付方式 */
    viewMode: 'cashier',   /* cashier=收银台 separate=选择支付方式 */
    orderInfo: null,
    qrInfo: {},
    expireTimer: null,
    pollTimer: null,
    jumpTimer: null,
    loaded: false,          /* 订单信息已加载 */
    jumpToUri: false,       /* 正在跳转第三方 */
    audioEl: null,
    touchHandler: null,
    gestureUnlock: null,    /* 音频解锁监听器引用，便于清理 */
    isIOS: /i(Phone|P(o|a)d)/.test(navigator.userAgent),
    payTypes: [],           /* 可用支付方式列表 */
    chosePay: '',           /* 已选支付方式 */
    submitting: false
  };

  /* ======================================================
   * URL 解析：支持 /pay/{id}、/pay/separate/{id}、query 参数
   * ====================================================== */
  function getQueryValue(keys) {
    var search = window.location.search.replace(/^\?/, '');
    if (!search) return '';
    var pairs = search.split('&');
    for (var i = 0; i < pairs.length; i++) {
      if (!pairs[i]) continue;
      var kv = pairs[i].split('=');
      var key = safeDecode(kv[0] || '');
      if (keys.indexOf(key) !== -1) return safeDecode(kv.slice(1).join('=') || '');
    }
    return '';
  }

  function parseRoute() {
    var path = window.location.pathname;
    var sepMatch = path.match(/\/pay\/separate\/([^/?#]+)/);
    if (sepMatch && sepMatch[1]) return { orderId: safeDecode(sepMatch[1]), page: 'separate' };
    var q = getQueryValue(['order_id', 'trade_no']);
    if (q) return { orderId: q, page: 'cashier' };
    var m = path.match(/^\/pay\/([^/?#]+)/);
    if (m && m[1]) {
      var v = safeDecode(m[1]);
      /* /pay/status/{id} 已随状态页移除，统一回退收银台（收银台对已支付订单会跳 return_uri） */
      if (v !== 'separate') return { orderId: v, page: 'cashier' };
    }
    return { orderId: '', page: 'cashier' };
  }

  /* ======================================================
   * 视图切换 + 主题
   * ====================================================== */
  function switchView(mode) {
    state.viewMode = mode;
    $('cashierView').hidden = mode !== 'cashier';
    $('separateView').hidden = mode !== 'separate';
  }

  function applyBrand(brand) {
    var root = document.documentElement;
    root.style.setProperty('--brand', brand.color);
    root.style.setProperty('--brand-grad', brand.grad);
    root.style.setProperty('--brand-rgb', brand.rgb);
  }

  /* ======================================================
   * 收银台渲染
   * ====================================================== */
  function renderBrand() {
    var info = state.orderInfo || {};
    var brand = getBrand(info.pay_type, info.pay_type_text);
    applyBrand(brand);
    /* 图标固定使用文字徽章（不加载图片） */
    $('payLogo').textContent = brand.char;
    $('payName').textContent = info.pay_type_text || '收银台';
  }

  function renderAmount() {
    var info = state.orderInfo || {};
    var html;
    if (info.pay_type === 'usdt' && state.qrInfo.actual_amount) {
      html = '<span class="amount-num">' + esc(state.qrInfo.actual_amount) + '</span><span class="amount-unit">U</span>';
    } else {
      var amt = splitAmount(info.trade_amount);
      html = '<span class="yen">¥</span><span class="amount-num">' + amt.int + '</span><span class="amount-dec">' + amt.dec + '</span>';
    }
    $('amountWrap').innerHTML = html;
  }

  function renderGoods() {
    var info = state.orderInfo || {};
    if (info.subject) {
      $('goodsPill').hidden = false;
      $('goodsName').textContent = info.subject;
    } else {
      $('goodsPill').hidden = true;
    }
  }

  /* 订单信息 + 商户自定义提示（弹窗展示，用户点击关闭后解锁音频播放） */
  function renderOrderInfo() {
    var info = state.orderInfo || {};
    $('orderCreateTime').textContent = info.create_time || '-';
    /* 商户自定义提示改为弹窗展示（pay_tip + account_tip 合并） */
    if (state.pageType === 'cashier') {
      showTipPopup(info);
    }
  }

  /* 支付提示弹窗：合并 account_tip 和 pay_tip，用户点击"我知道了"关闭，
     该点击行为同时作为用户交互解锁音频自动播放 */
  function showTipPopup(info) {
    /* 仅未支付订单弹窗提示；已支付/已关闭/已超时/创建失败一律不打扰（覆盖刷新与轮询后场景） */
    if (info.status !== 1) return;
    var accountTip = (info.pay_account_tip && info.pay_account_tip.tip) ? info.pay_account_tip.tip : '';
    var payTip = info.pay_tip || '';
    if (!accountTip && !payTip) return;
    /* 两个 tip 分两行展示，各自带图标，避免拼接成一坨（tip 为后台配置，保留 HTML 加粗格式） */
    var html = '';
    if (accountTip) html += '<div class="tip-row">' + accountTip + '</div>';
    if (payTip) html += '<div class="tip-row">' + payTip + '</div>';
    /* 避免重复弹窗 */
    if (!$('tipOverlay').hidden) return;
    $('tipModalBody').innerHTML = html;
    $('tipOverlay').hidden = false;
  }

  /* 订单状态离开"待支付"（支付成功/关闭/超时/失败）时自动收起弹窗，
     避免提示浮层盖在支付结果视图上 */
  function closeTipPopup(onDone) {
    var overlay = $('tipOverlay');
    /* 状态页等无弹窗元素的页面直接跳过，避免空引用 */
    if (!overlay || overlay.hidden) return;
    overlay.classList.add('closing');
    var done = false;
    var finish = function () {
      if (done) return;
      done = true;
      overlay.classList.remove('closing');
      overlay.hidden = true;
      if (typeof onDone === 'function') onDone();
    };
    overlay.addEventListener('animationend', finish, { once: true });
    setTimeout(finish, 260);
  }

  /* USDT 收款信息卡 */
  function renderTransfer() {
    var qr = state.qrInfo || {};
    var show = qr.actual_account && state.loaded;
    $('transferCard').hidden = !show;
    /* USDT 视图：卡片标记 has-transfer，CSS 收紧间距保证一屏完整展示 */
    $('card').classList.toggle('has-transfer', !!show);
    if (!show) return;
    $('transferNet').textContent = qr.actual_account_type || '';
    $('transferAddr').textContent = qr.actual_account;
    var amtRow = !!qr.actual_amount;
    $('transferAmountRow').hidden = !amtRow;
    if (amtRow) $('transferAmount').textContent = qr.actual_amount + ' USDT';
  }

  /* 二维码提示文案 */
  function renderQrTip() {
    var info = state.orderInfo || {};
    var tip;
    if (info.pay_type === 'usdt') {
      /* 通道备注已含转账说明时，不再显示二维码下方冗余提示 */
      if (info.pay_tip) { $('qrTip').innerHTML = ''; return; }
      tip = '扫码或复制收款地址，按金额完成 USDT 转账';
    } else if (IS_MOBILE && getResolvedScheme()) {
      /* 移动端无法直接扫屏幕上的码，引导截图后点击下方唤起按钮从相册扫码 */
      tip = '请使用 <b>' + esc(info.pay_type_text || '对应 App') + '</b>「扫一扫」<br>截图后点击下方按钮支付';
    } else {
      tip = '请使用 <b>' + esc(info.pay_type_text || '对应 App') + '</b>「扫一扫」<br>扫描二维码完成支付';
    }
    $('qrTip').innerHTML = tip;
  }

  /* 结果状态页 */
  function renderResult() {
    var info = state.orderInfo || {};
    var meta = STATUS_META[info.status] || { title: '订单状态异常', sub: '请刷新页面后重试', icon: 'error' };
    var icons = {
      success: '<svg width="46" height="46" viewBox="0 0 52 52" fill="none"><circle class="check-circle" cx="26" cy="26" r="24" stroke="#00b42a" stroke-width="2.5"/><path class="check-mark" d="M15 27l7 7 15-16" stroke="#00b42a" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      timeout: '<svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="#fa8c16" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>',
      error: '<svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="#f53f3f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>'
    };
    var iconEl = $('resultIcon');
    iconEl.className = 'result-icon ' + meta.icon;
    iconEl.innerHTML = icons[meta.icon] || icons.error;
    $('resultTitle').textContent = meta.title;
    $('resultSub').textContent = meta.sub;

    /* 金额常驻展示（对齐 default 状态页：amount 优先，兼容 trade_amount） */
    var amtWrap = $('resultAmount');
    amtWrap.hidden = false;
    if (info.pay_type === 'usdt' && state.qrInfo.actual_amount) {
      amtWrap.innerHTML = '<span class="amount-num" style="font-size:24px">' + esc(state.qrInfo.actual_amount) + '</span><span class="amount-unit">USDT</span>';
    } else {
      var amt = splitAmount(info.amount != null ? info.amount : info.trade_amount);
      amtWrap.innerHTML = '<span class="yen">¥</span><span>' + amt.int + amt.dec + '</span>';
    }

    /* 订单信息 4 行（对齐 default 状态页） */
    $('resultOrderId').textContent = state.orderId || '-';
    $('resultOutOrderId').textContent = info.out_order_id || '-';
    $('resultCreateTime').textContent = info.create_time || '-';
    $('resultPayType').textContent = info.pay_type_text || '-';

    /* 重播描边动画 */
    var el = $('stateResult');
    el.classList.remove('play');
    void el.offsetWidth;
    el.classList.add('play');
  }

  /* 整体可见性切换 */
  function renderView() {
    var info = state.orderInfo || {};
    /* 收银台仅在非待支付时展示结果视图 */
    var showPay = state.loaded && !state.jumpToUri && info.status === 1;
    var showResult = state.loaded && !state.jumpToUri && info.status !== 1;
    $('statePending').hidden = !showPay;
    $('stateResult').hidden = !showResult;
    if (showResult) renderResult();

    /* 全屏加载层 */
    $('fullLoading').hidden = state.loaded && !state.jumpToUri;
    $('fullLoadingText').textContent = state.jumpToUri ? '正在跳转中' : '加载中';

    /* 唤起按钮：仅移动端显示（PC 端无 scheme handler 会报错，但后台 iframe 唤起不影响 JS）。
       scheme 取后端返回值，没有则用支付方式默认 scheme，都没有则不显示按钮。 */
    var scheme = getResolvedScheme();
    var safeScheme = scheme && !/^\s*(javascript|data|vbscript):/i.test(scheme) ? scheme : '';
    $('wakeBtn').hidden = !(showPay && IS_MOBILE && safeScheme);
    if (safeScheme) {
      $('wakeBtn').onclick = function (e) {
        e.preventDefault();
        launchScheme(safeScheme);
      };
    }
  }

  function renderAll() {
    renderBrand();
    renderAmount();
    renderGoods();
    renderOrderInfo();
    renderQrTip();
    renderTransfer();
    renderView();
  }

  /* ======================================================
   * 选择支付方式视图渲染
   * ====================================================== */
  function renderSepInfo() {
    var info = state.orderInfo || {};
    var amt = splitAmount(info.trade_amount);
    $('sepAmount').innerHTML =
      '<span class="yen">¥</span><span class="amount-num">' + amt.int + '</span><span class="amount-dec">' + amt.dec + '</span>';
    $('sepSubject').textContent = info.subject || '-';
    $('sepOutOrderId').textContent = info.out_order_id || '-';
    $('sepOrderId').textContent = state.orderId || '-';
    $('sepCreateTime').textContent = info.create_time || '-';
  }

  function renderPayTypes() {
    var wrap = $('payTypes');
    wrap.innerHTML = '';
    if (!state.payTypes.length) {
      wrap.innerHTML = '<div class="pay-type-item pay-type-empty">暂无可用支付方式</div>';
      $('payBtn').disabled = true;
      return;
    }
    for (var i = 0; i < state.payTypes.length; i++) {
      (function (item) {
        var brand = getBrand(item.value, item.label);
        var el = document.createElement('div');
        el.className = 'pay-type-item' + (state.chosePay === item.value ? ' chose' : '');
        /* 图标固定使用文字徽章（不加载图片）；label 用 textContent 防 XSS */
        el.innerHTML =
          '<div class="pt-logo" style="background:' + brand.grad + '"><span>' + brand.char + '</span></div>' +
          '<span class="pt-label"></span>' +
          '<span class="pt-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span>';
        el.querySelector('.pt-label').textContent = item.label;
        el.addEventListener('click', function () { chosePayType(item.value); });
        wrap.appendChild(el);
      })(state.payTypes[i]);
    }
    $('payBtn').disabled = !state.chosePay;
  }

  function chosePayType(value) {
    state.chosePay = value;
    /* 选中项品牌色同步到页面主题 */
    var item = null;
    for (var i = 0; i < state.payTypes.length; i++) {
      if (state.payTypes[i].value === value) { item = state.payTypes[i]; break; }
    }
    applyBrand(getBrand(value, item && item.label));
    renderPayTypes();
  }

  /* ======================================================
   * 倒计时 / 轮询 / 语音播报
   * ====================================================== */
  function startExpireTimer() {
    stopExpireTimer();
    /* 立即更新一次倒计时（占位符 → 实际时间），再每秒刷新 */
    var update = function () {
      if (!state.orderInfo) return;
      /* 状态已变更（支付成功/关闭/超时）时自动停止倒计时，防止覆盖支付成功状态 */
      if (state.orderInfo.status !== 1) { stopExpireTimer(); return; }
      var now = Date.now() / 1000;
      var exp = state.orderInfo.expire_time || 0;
      if (exp > 0) {
        var remain = exp - now;
        if (remain > 0) {
          $('countdownText').textContent = formatRemain(parseInt(remain));
          $('countdownBox').hidden = false;
        } else {
          $('countdownText').textContent = '已过期';
          state.orderInfo.status = 4;
          closeTipPopup();
          stopPollTimer();
          renderView();
        }
      } else {
        $('countdownBox').hidden = true;
      }
    };
    update();
    state.expireTimer = setInterval(update, 1000);
  }
  function stopExpireTimer() { if (state.expireTimer) { clearInterval(state.expireTimer); state.expireTimer = null; } }
  function stopPollTimer() { if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; } }
  function stopJumpTimer() { if (state.jumpTimer) { clearTimeout(state.jumpTimer); state.jumpTimer = null; } }
  function stopAllTimers() { stopExpireTimer(); stopPollTimer(); stopJumpTimer(); }

  /* 看门狗：scheme 唤起（iframe 方式）在某些浏览器仍可能短暂暂停定时器。
     requestAnimationFrame 在页面冻结时停止回调，恢复后检测到时间差 >2s
     说明被冻结过，自动重启倒计时和轮询，确保支付状态不丢失。 */
  var rafLast = Date.now();
  (function watchdog() {
    var now = Date.now();
    if (now - rafLast > 2000 && state.orderInfo && state.orderInfo.status === 1 && state.loaded) {
      if (!state.expireTimer && state.viewMode === 'cashier') startExpireTimer();
      if (!state.pollTimer) startPolling();
    }
    rafLast = now;
    requestAnimationFrame(watchdog);
  })();

  /* 页面可见性变化：从后台切回前台时立即重启定时器（比 rAF 漂移检测更及时，
     尤其 iOS Safari 从支付宝 App 返回时 rAF 恢复有延迟） */
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState !== 'visible') return;
    if (!state.orderInfo || state.orderInfo.status !== 1 || !state.loaded) return;
    if (state.viewMode === 'cashier' && !state.expireTimer) startExpireTimer();
    if (!state.pollTimer) startPolling();
  });

  /* 语音播报（页面打开即播放，提示用户付款金额避免付错）：
     - 桌面浏览器自动播放策略：muted 必须在插入 DOM 前设置，否则浏览器检测到非静音 audio 会拒绝播放
     - 静音播放成功后取消静音，用户即可听到语音
     - iOS Safari：必须用户触摸后才能播放，注册 touchstart 监听器
     - 微信内置浏览器：通过 WeixinJSBridgeReady 事件触发播放
     - 静音播放也失败的极端情况：注册 click/keydown 交互监听器兜底 */
  var wxBridgeListenerAdded = false;
  /* 用户首次交互后解锁音频播放（兜底：自动播放被浏览器策略拦截时）。
     保存 unlock 引用，便于 refreshAll 清理，避免监听器累积。 */
  function registerGestureUnlock() {
    if (state.gestureUnlock) return;  /* 已注册则不重复添加 */
    function unlock() {
      if (!state.audioEl) return;
      state.audioEl.muted = false;
      state.audioEl.play().catch(function () {});
      cleanupGestureUnlock();
    }
    state.gestureUnlock = unlock;
    document.addEventListener('click', unlock);
    document.addEventListener('keydown', unlock);
    document.addEventListener('touchstart', unlock);
  }
  function cleanupGestureUnlock() {
    if (!state.gestureUnlock) return;
    document.removeEventListener('click', state.gestureUnlock);
    document.removeEventListener('keydown', state.gestureUnlock);
    document.removeEventListener('touchstart', state.gestureUnlock);
    state.gestureUnlock = null;
  }
  function startAudio(url) {
    var el = document.createElement('audio');
    /* 关键：muted 必须在 appendChild 之前设置，
       否则元素插入 DOM 时浏览器检测到非静音 audio，会触发自动播放策略拦截 */
    el.muted = true;
    el.autoplay = true;
    el.setAttribute('playsinline', '');
    el.setAttribute('webkit-playsinline', '');
    el.style.display = 'none';
    el.src = url;
    document.body.appendChild(el);
    state.audioEl = el;
    /* 微信内置浏览器：WeixinJSBridgeReady 提供播放上下文，可直接非静音播放 */
    if (window.WeixinJSBridge) {
      el.muted = false;
      el.play().catch(function () { registerGestureUnlock(); });
      return;
    }
    if (!wxBridgeListenerAdded) {
      wxBridgeListenerAdded = true;
      document.addEventListener('WeixinJSBridgeReady', function () {
        if (state.audioEl) {
          state.audioEl.muted = false;
          state.audioEl.play().catch(function () { registerGestureUnlock(); });
        }
      }, false);
    }
    /* 先静音播放（浏览器总允许），成功后取消静音并重新播放；
       若取消静音后播放被自动播放策略拦截（如从外站首次跳转、MEI 不足），则等待用户交互解锁 */
    el.play().then(function () {
      el.muted = false;
      return el.play();
    }).then(function () {
      /* 非静音播放成功 */
    }).catch(function () {
      registerGestureUnlock();
    });
    /* iOS：用户首次触摸时取消静音并播放 */
    if (state.isIOS) {
      state.touchHandler = function () {
        el.muted = false;
        el.play().catch(function () {});
        if (state.touchHandler) {
          document.removeEventListener('touchstart', state.touchHandler);
          state.touchHandler = null;
        }
      };
      document.addEventListener('touchstart', state.touchHandler);
    }
  }

  /* ======================================================
   * 业务流程
   * ====================================================== */

  /* 查询订单信息（收银台与选择视图共用入口） */
  function queryOrder() {
    apiPost('/order/info', { order_id: state.orderId }).then(function (res) {
      if (res.code === 200 && res.data) {
        state.orderInfo = res.data;
        /* 选择支付方式页：仅展示订单信息 */
        if (state.pageType === 'separate') {
          renderSepInfo();
          $('fullLoading').hidden = true;
          return;
        }
        /* 收银台视图：未指定支付方式 → 跳转到选择支付方式页 */
        if (res.data.pay_type === '') {
          if (IS_DEMO) {
            switchView('separate');
            renderSepInfo();
            loadPayTypes();
            $('fullLoading').hidden = true;
            return;
          } else {
            safeRedirect('/pay/separate/' + state.orderId);
            return;
          }
        }
        if (res.data.status === 1) {
          /* 待支付：请求语音播报配置 + 启动倒计时与轮询 */
          apiPost('/order/audio', { order_id: state.orderId }).then(function (a) {
            if (a.code === 200 && a.data && a.data.audio_enable === 1 && a.data.audio_url) {
              startAudio(a.data.audio_url);
            }
          }).catch(function () {});
          startPolling();
        } else if (res.data.status === 2) {
          handlePaid(res.data);
        } else if (res.data.status === 3) {
          closeTipPopup();
          toast('订单已关闭', 'error');
        } else if (res.data.status === 4) {
          closeTipPopup();
          toast('订单支付已超时', 'error');
        } else if (res.data.status === 5) {
          closeTipPopup();
          toast('订单创建失败', 'error');
        }
      } else {
        toast(res.message || '订单查询失败', 'error');
        state.orderInfo = { status: 0 };
      }
      state.loaded = true;
      renderAll();
      if (state.orderInfo && state.orderInfo.status === 1 && state.viewMode === 'cashier') startExpireTimer();
    }).catch(function () {
      toast('网络请求失败，请刷新重试', 'error');
      state.loaded = true;
      state.orderInfo = { status: 0 };
      renderView();
    });
  }

  /* 已支付处理：收起可能还开着的提示弹窗（避免盖在支付成功视图上），有回调地址则倒计时跳转 */
  function handlePaid(data) {
    closeTipPopup();
    var wait = (data && data.pay_payed_wait_time) || 3;
    if (data && data.return_uri) {
      toast('订单支付完成,' + wait + '秒后自动跳转', 'success');
      stopJumpTimer();
      state.jumpTimer = setTimeout(function () { safeRedirect(data.return_uri); }, wait * 1000);
    } else {
      toast('订单支付完成', 'success');
    }
  }

  /* 轮询订单状态（每秒） */
  function startPolling() {
    stopPollTimer();
    state.pollTimer = setInterval(function () {
      if (!state.orderInfo) return;
      apiPost('/order/status', { order_id: state.orderId }).then(function (res) {
        if (res === undefined) return;
        if (res.code !== 200 || !res.data) {
          toast(res.message || '状态查询失败', 'error');
          stopPollTimer();
          return;
        }
        state.orderInfo.expire_time = res.data.expire_time;
        if (res.data.status !== state.orderInfo.status) {
          state.orderInfo.status = res.data.status;
          if (res.data.status === 2) {
            handlePaid(res.data);
            stopPollTimer();
            stopExpireTimer();
          } else if (res.data.status === 3) {
            closeTipPopup();
            toast('订单已关闭', 'error');
            stopPollTimer();
            stopExpireTimer();
          } else if (res.data.status === 4) {
            closeTipPopup();
            toast('订单支付已超时', 'error');
            stopPollTimer();
            stopExpireTimer();
          } else if (res.data.status !== 1) {
            /* status=5(创建失败) 或其他异常状态：关弹窗并停止轮询，避免空转与提示残留 */
            closeTipPopup();
            stopPollTimer();
            stopExpireTimer();
          }
          renderView();
        }
      }).catch(function () { /* 网络抖动时继续轮询 */ });
    }, 1000);
  }

  /* 获取支付二维码 */
  function getQrcode() {
    if (!state.orderId || state.viewMode !== 'cashier') return;
    $('qrSkeleton').hidden = false;
    $('qrImg').hidden = true;
    apiPost('/order/qrcode', { order_id: state.orderId }).then(function (res) {
      if (res.code === 200 && res.data) {
        state.qrInfo = res.data;
        /* showQrImage 不依赖订单信息，先显示二维码（queryOrder 未返回时也能展示码） */
        if (res.data.type === 'qrcode') {
          showQrImage(res.data);
        } else if (res.data.type === 'jump') {
          if (res.data.uri) {
            state.jumpToUri = true;
            renderView();
            /* http URL 用 location.href 跳转；scheme URL 用 iframe 唤起，不中断定时器 */
            var isScheme = !/^https?:/i.test(res.data.uri);
            if (isScheme) {
              launchScheme(res.data.uri);
            } else {
              safeRedirect(res.data.uri);
            }
          }
          return;
        } else if (res.data.type === 'html') {
          window.location.reload();
          return;
        } else if (res.data.type === 'text') {
          /* 文本转账信息 */
          $('textContent').hidden = false;
          $('qrFrame').hidden = true;
          $('textContentBody').textContent = res.data.content || '';
          $('copyTextContent').hidden = !res.data.content_copy;
        }
        /* scheme 唤起：用隐藏 iframe 加载，不中断主页面 JS 流（倒计时/轮询继续运行） */
        if (res.data.scheme) {
          launchScheme(res.data.scheme);
        }
        /* 关键：renderAmount/renderQrTip/renderTransfer/renderView 都依赖 state.orderInfo。
           若 getQrcode 比 queryOrder 先返回，orderInfo 仍为 null，此时渲染会显示
           ¥0.00、"对应 App"等错误占位。交由 queryOrder 返回后的 renderAll 统一渲染，
           避免与 queryOrder 竞态导致的金额/文案闪烁。 */
        if (state.orderInfo) {
          renderTransfer();
          renderAmount();
          renderQrTip();
          renderView();
        }
      } else if (res.message !== '未能找到订单信息或失效') {
        toast(res.message || '获取付款码失败', 'error');
        $('qrSkeleton').hidden = true;
      }
    }).catch(function () {
      toast('获取付款码失败，请刷新重试', 'error');
      $('qrSkeleton').hidden = true;
    });
  }

  /* 显示二维码图片 */
  function showQrImage(data) {
    var img = $('qrImg');
    var src = data.qrcode_data || (data.qrcode ? '/api/qrcode?text=' + encodeURIComponent(data.qrcode) : '');
    if (!src) { $('qrSkeleton').hidden = true; return; }
    if (IS_DEMO && !data.qrcode_data) {
      /* 演示模式：本地绘制伪二维码 */
      var brand = getBrand(state.orderInfo && state.orderInfo.pay_type);
      src = drawDemoQR(brand.color, brand.char);
    }
    img.onload = function () {
      $('qrSkeleton').hidden = true;
      img.hidden = false;
    };
    img.onerror = function () { $('qrSkeleton').hidden = true; };
    img.src = src;
  }

  /* 演示模式伪二维码（标准二维码外观：定位角 + 方块点阵 + 中心徽章；
     数据区为固定种子随机噪点，不含任何有效编码与纠错码字，
     扫码器解码必然失败，扫不出任何真实数据） */
  function drawDemoQR(brandColor, logoChar) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    var N = 33, cell = 6, pad = 8;
    var size = N * cell + pad * 2;
    canvas.width = size; canvas.height = size;
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, size, size);
    /* 固定种子伪随机，保证渲染稳定 */
    var seed = 20260824;
    function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
    var inFinder = function (x, y) { return (x < 7 && y < 7) || (x >= N - 7 && y < 7) || (x < 7 && y >= N - 7); };
    var inLogo = function (x, y) { return Math.abs(x - (N - 1) / 2) < 4.5 && Math.abs(y - (N - 1) / 2) < 4.5; };
    /* 数据区随机噪点：不构成有效编码，纠错校验必然失败 */
    ctx.fillStyle = '#22262e';
    for (var y = 0; y < N; y++) {
      for (var x = 0; x < N; x++) {
        if (inFinder(x, y) || inLogo(x, y)) continue;
        if (rnd() > 0.52) ctx.fillRect(pad + x * cell, pad + y * cell, cell, cell);
      }
    }
    /* 三个定位角（仅保留二维码外观特征） */
    function finder(fx, fy) {
      ctx.fillStyle = '#22262e';
      ctx.fillRect(pad + fx * cell, pad + fy * cell, 7 * cell, 7 * cell);
      ctx.fillStyle = '#fff';
      ctx.fillRect(pad + (fx + 1) * cell, pad + (fy + 1) * cell, 5 * cell, 5 * cell);
      ctx.fillStyle = '#22262e';
      ctx.fillRect(pad + (fx + 2) * cell, pad + (fy + 2) * cell, 3 * cell, 3 * cell);
    }
    finder(0, 0); finder(N - 7, 0); finder(0, N - 7);
    /* 中心品牌 Logo */
    var c = size / 2, r = 20;
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(c, c, r + 5, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(c - r, c - r, r * 2, r * 2, 7);
    else ctx.rect(c - r, c - r, r * 2, r * 2);
    ctx.fillStyle = brandColor; ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.font = '600 21px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(logoChar, c, c + 1);
    return canvas.toDataURL('image/png');
  }

  /* 获取可用支付方式列表 */
  function loadPayTypes() {
    apiPost('/pay/types', { order_id: state.orderId }).then(function (res) {
      if (res.code === 200) {
        state.payTypes = res.data || [];
        if (state.payTypes.length > 0 && !state.chosePay) {
          chosePayType(state.payTypes[0].value);
        } else {
          renderPayTypes();
        }
      } else {
        toast(res.message || '获取支付方式失败', 'error');
        renderPayTypes();
      }
    }).catch(function () {
      toast('获取支付方式失败', 'error');
      renderPayTypes();
    });
  }

  /* 选择支付方式视图数据加载 */
  function loadSepData() {
    queryOrder();
    loadPayTypes();
  }

  /* 提交选择的支付方式 */
  function submitPay() {
    if (state.submitting) return;
    if (!state.chosePay) { toast('请选择支付方式', 'info'); return; }
    state.submitting = true;
    $('payBtn').disabled = true;
    apiPost('/order/chose-type', { pay_type: state.chosePay, order_id: state.orderId }).then(function (res) {
      if (res.code === 200) {
        if (IS_DEMO) {
          /* 演示模式：跳转到收银台页面（通过 URL 切换，非 SPA 视图切换） */
          demoState.payType = state.chosePay;
          toast('已选择 ' + getPayLabel(state.chosePay) + '，正在进入支付...', 'success');
          setTimeout(function () {
            window.location.href = '/?demo';
          }, 600);
        } else {
          toast('正在进入支付...', 'success');
          safeRedirect('/pay/' + state.orderId);
        }
        state.submitting = false;
      } else {
        toast(res.message || '选择支付方式失败', 'error');
        state.submitting = false;
        $('payBtn').disabled = false;
      }
    }).catch(function () {
      toast('网络请求失败，请重试', 'error');
      state.submitting = false;
      $('payBtn').disabled = false;
    });
  }

  function getPayLabel(value) {
    for (var i = 0; i < state.payTypes.length; i++) {
      if (state.payTypes[i].value === value) return state.payTypes[i].label;
    }
    return value;
  }

  /* 演示模式整体刷新（切换支付方式 / 状态后调用） */
  function refreshAll() {
    stopAllTimers();
    if (state.audioEl) { state.audioEl.remove(); state.audioEl = null; }
    /* 清理音频相关监听器，避免多次切换后累积 */
    if (state.touchHandler) {
      document.removeEventListener('touchstart', state.touchHandler);
      state.touchHandler = null;
    }
    cleanupGestureUnlock();
    /* 重置演示过期时间，倒计时从满额重新开始递减 */
    if (IS_DEMO) demoExpireTime = Math.floor(Date.now() / 1000) + 1799;
    state.loaded = false;
    state.jumpToUri = false;
    state.qrInfo = {};
    state.chosePay = '';
    state.submitting = false;
    /* 重置二维码 / 文本区 UI（倒计时保持占位，避免布局跳动） */
    $('textContent').hidden = true;
    $('textContentBody').textContent = '';
    $('qrFrame').hidden = false;
    $('qrSkeleton').hidden = false;
    $('qrImg').hidden = true;
    $('countdownText').textContent = '--分 --秒';
    $('countdownBox').hidden = false;
    $('fullLoading').hidden = false;
    $('payBtn').disabled = true;
    /* 收银台页：重新查订单 + 取二维码；其他页面跳转回收银台 */
    if (state.pageType === 'cashier') {
      queryOrder();
      getQrcode();
    } else {
      window.location.href = '/?demo';
    }
  }

  /* ======================================================
   * 事件绑定
   * ====================================================== */

  /* 复制按钮（含"已复制"反馈） */
  function bindCopy(el, getText) {
    if (!el) return;
    el.addEventListener('click', function () {
      if (el.dataset.locked) return;  /* 反馈期间忽略重复点击 */
      copyText(typeof getText === 'function' ? getText() : getText).then(function () {
        toast('复制成功', 'success');
        el.dataset.locked = '1';
        var origin = el.innerHTML;
        el.classList.add('copied');
        el.innerHTML = ICON_CHECK + '已复制';
        setTimeout(function () {
          el.innerHTML = origin;
          el.classList.remove('copied');
          delete el.dataset.locked;
        }, 1600);
      });
    });
  }
  bindCopy($('copyAddr'), function () { return (state.qrInfo || {}).actual_account || ''; });
  bindCopy($('copyTransferAmount'), function () { return (state.qrInfo || {}).actual_amount || ''; });
  bindCopy($('copyTextContent'), function () { return (state.qrInfo || {}).content || ''; });
  bindCopy(document.querySelector('[data-copy-id="orderId"]'), function () { return state.orderId; });
  bindCopy($('amountWrap'), function () {
    var info = state.orderInfo || {};
    if (info.pay_type === 'usdt' && state.qrInfo.actual_amount) return state.qrInfo.actual_amount;
    return (Number(info.trade_amount || 0) / 100).toFixed(2);
  });

  /* 返回按钮 */
  $('resultBtn').addEventListener('click', function () {
    if (window.history.length > 1) window.history.back();
    else window.location.href = '/';
  });

  /* 立即支付按钮 */
  $('payBtn').addEventListener('click', submitPay);

  /* 支付提示弹窗关闭：点击"我知道了"隐藏弹窗，
     同时利用这次用户交互解锁音频播放（浏览器策略要求） */
  $('tipModalBtn').addEventListener('click', function () {
    closeTipPopup(function () {
      if (state.audioEl) {
        state.audioEl.muted = false;
        state.audioEl.play().catch(function () {});
      }
    });
  });

  /* ======================================================
   * 演示控制面板（仅演示模式）
   * ====================================================== */
  function setActiveSeg(segId, value) {
    var attrMap = { segPay: 'pay', segState: 'state', segQrMode: 'qrmode' };
    var attr = attrMap[segId] || 'state';
    var items = $(segId).querySelectorAll('.demo-btn');
    for (var i = 0; i < items.length; i++) {
      items[i].classList.toggle('active', items[i].getAttribute('data-' + attr) === value);
    }
  }

  function initDemoPanel() {
    if (!IS_DEMO) return;
    $('demoPanel').hidden = false;
    document.body.classList.add('demo');
    /* 支付成功自动跳转演示：跳回本页时提示 */
    if (getQueryValue(['jumped'])) {
      setTimeout(function () { toast('演示：已自动跳转到商户回调地址', 'success'); }, 600);
    }
    /* 支付方式切换 */
    $('segPay').addEventListener('click', function (e) {
      var btn = e.target.closest('.demo-btn');
      if (!btn) return;
      demoState.payType = btn.getAttribute('data-pay');
      setActiveSeg('segPay', demoState.payType);
      refreshAll();
    });
    /* 订单状态切换 */
    $('segState').addEventListener('click', function (e) {
      var btn = e.target.closest('.demo-btn');
      if (!btn) return;
      demoState.status = parseInt(btn.getAttribute('data-state'), 10);
      setActiveSeg('segState', String(demoState.status));
      refreshAll();
    });
    /* 二维码模式切换 */
    $('segQrMode').addEventListener('click', function (e) {
      var btn = e.target.closest('.demo-btn');
      if (!btn) return;
      demoState.qrMode = btn.getAttribute('data-qrmode');
      setActiveSeg('segQrMode', demoState.qrMode);
      refreshAll();
    });
  }

  /* ======================================================
   * 站点配置
   * ====================================================== */
  function loadConfig() {
    apiGet('/config').then(function (res) {
      if (res.code === 200 && res.data) {
        var title = res.data.web_title || '收银台';
        document.title = title + ' - 收银台';
        $('webTitle').textContent = title + ' · 收银台';
        $('sepTitle').textContent = title;
        /* 站点图标固定使用文字徽章（站点名首字） */
        $('sepLogo').textContent = title.charAt(0) || '店';
        var qq = res.data.web_service_qq;
        $('footerText').innerHTML = qq ? '如支付遇到问题，请联系客服：<b></b>' : '如支付遇到问题，请联系客服';
        if (qq) $('footerText').querySelector('b').textContent = qq;
      }
    }).catch(function () {});
  }

  /* ======================================================
   * 大屏等比放大（保持设计比例不变）
   * 以 390px 设计稿为基准，按视口宽高计算 zoom 系数整体缩放：
   *   宽度约束：页面不超视口
   *   高度约束：最长视图（USDT 含收款信息卡）不超视口
   *   上限 1.32，避免桌面端卡片过宽
   * ====================================================== */
  function applyScale() {
    var page = document.querySelector('.page');
    if (!page) return;
    var vw = window.innerWidth, vh = window.innerHeight;
    if (vw <= 640) { page.style.zoom = ''; return; }  /* 移动端保持原样 */
    var byW = (vw - 60) / 390;
    var byH = (vh - 40) / 750;
    var z = Math.min(byW, byH, 1.32);
    page.style.zoom = z < 1 ? '' : z.toFixed(3);
  }
  var scaleTimer = null;
  window.addEventListener('resize', function () {
    if (scaleTimer) clearTimeout(scaleTimer);
    scaleTimer = setTimeout(applyScale, 150);
  });

  /* ======================================================
   * 初始化
   * ====================================================== */
  function init() {
    var route = parseRoute();
    state.orderId = route.orderId;
    state.pageType = route.page || 'cashier';
    state.viewMode = state.pageType === 'separate' ? 'separate' : 'cashier';
    if (!state.orderId) {
      if (IS_DEMO) {
        state.orderId = DEMO_ORDER_ID;
      } else {
        toast('请求错误', 'error');
        $('fullLoading').hidden = true;
        return;
      }
    }
    $('orderIdText').textContent = state.orderId || '-';
    $('sepOrderId').textContent = state.orderId || '-';
    applyScale();
    loadConfig();
    initDemoPanel();
    if (state.pageType === 'separate') {
      /* 选择支付方式页：加载订单信息 + 支付方式列表 */
      loadSepData();
    } else {
      /* 收银台页：查订单 + 取二维码 */
      switchView('cashier');
      queryOrder();
      getQrcode();
    }
  }

  /* 页面卸载清理（pagehide 兼容 iOS Safari，beforeunload 在 iOS 不可靠） */
  function cleanupOnUnload() {
    stopAllTimers();
    if (state.touchHandler) {
      document.removeEventListener('touchstart', state.touchHandler);
      state.touchHandler = null;
    }
    cleanupGestureUnlock();
  }
  window.addEventListener('pagehide', cleanupOnUnload);
  window.addEventListener('beforeunload', cleanupOnUnload);

  init();
})();
