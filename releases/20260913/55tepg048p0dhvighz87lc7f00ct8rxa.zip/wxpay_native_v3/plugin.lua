---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
-- 极简自动载入 - 直接使用！
require("autoload")

-- 渠道 微信-NativeV3
local PAY_WXPAY_NATIVE_V3 = "wxpay_native_v3"

-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["wxpay"] = { {
                label = '微信-NativeV3',
                value = PAY_WXPAY_NATIVE_V3
            } }
        },
        options = {
            callback = 1,
            detection_interval = 0,
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'appid',
                label = '应用ID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "应用APPID是微信开放平台(移动应用)或微信公众平台(小程序、公众号)为开发者的应用程序提供的唯一标识。",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'mchid',
                label = '商户ID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "商户ID 或者服务商模式的 sp_mchid",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'serial_no',
                label = '证书序列号',
                type = types.InputTypes.INPUT,
                hidden_list = 1,
                default = "",
                placeholder = "商户API证书的证书序列号",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'api_v3_key',
                label = '商户APIV3Key',
                type = types.InputTypes.INPUT,
                default = "",
                hidden_list = 1,
                placeholder = "商户平台获取",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'private_key',
                label = '商户API证书私钥',
                type = types.InputTypes.TEXTAREA,
                default = "",
                hidden_list = 1,
                placeholder = "商户API证书下载后，私钥 apiclient_key.pem 读取后的字符串内容",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'public_key',
                label = '微信证书公钥',
                type = types.InputTypes.TEXTAREA,
                default = "",
                hidden_list = 1,
                placeholder = "微信支付->API安全->微信支付公钥中下载",
                options = {
                    tip = '推荐填写,不填写的话是使用的平台证书,新账号请推荐填写',
                },
            },
            {
                name = 'public_key_id',
                label = '微信支付公钥ID',
                type = 'input',
                default = "",
                hidden_list = 1,
                placeholder = "微信支付->API安全->微信支付公钥,前缀为:PUB_KEY_ID_",
                options = {
                    tip = '推荐填写,不填写的话是使用的平台证书,新账号请推荐填写',
                },
            },

        },
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local err_code, err_message, result = orderPayHelper.wxpay_native_v3_create(vOrderInfo, vAccountOptions)

    if err_code ~= 200 then
        return {
            code = 500,
            message = err_message,
            data = {
                type = types.PaymentResultTypes.QRCODE
            }
        }
    elseif err_code == 200 then
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode = result,
                url = "",
                content = "",
                out_trade_no = ""
            }
        }
    end

    return {
        code = 500,
        message = '创建支付失败',
        data = {
            type = types.PaymentResultTypes.QRCODE
        }
    }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    local vRequest = ctx.request
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local err_code, err_message, response = orderPayHelper.wxpay_native_v3_notify(vRequest, vOrderInfo, vAccountOptions)

    return {
        code = err_code,
        message = err_message,
        data = { response = response }
    }
end

return plugin

