---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

-- 渠道 银联前置
-- @class plugin
local plugin = {}

PAY_BANK_UNION = "bank_union"

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["bank"] = { {
                label = '银联前置-官方',
                value = PAY_BANK_UNION,
                bind_pay_type = { "alipay", "wxpay", "bank" },
                info = "银联前置-官方，教程待补充···"
            } }
        },
        options = {
            callback = 1,
            detection_interval = 0
        }
    }
end

--- 网关地址
plugin.gateway = "https://qra.95516.com/pay/gateway"

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'mch_id',
                label = '商户号',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入商户号",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'key',
                label = '商户密钥',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入商户密钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options
    print(json.encode(vAccountOptions), "账户参数")

    local requestData = {
        service = "unified.trade.native",
        mch_id = vAccountOptions.mch_id,
        out_trade_no = vOrderInfo.order_id,
        body = vOrderInfo.subject,
        total_fee = vOrderInfo.trade_amount,
        mch_create_ip = "127.0.0.1",
        notify_url = vOrderInfo.notify_url,
        time_start = helper.time_now_small_time(),
        time_expire = helper.time_now_small_time(5 * 60),
        nonce_str = helper.str_random(20)
    }
    local sign = plugin._getSign(requestData, "&key=" .. vAccountOptions.key)
    requestData.sign = string.upper(sign)
    
    local params = {
        query = "",
        body = funcs.table_to_xml_string("1.0", "utf-8", requestData),
        form = "",
        timeout = "30s",
        headers = {
            ["content-type"] = "application/xml"
        }
    }
    local response, error_message = http.request("POST", plugin.gateway, params)

    if response and response.body then
        local res = response.body
        print("返回数据", res)
        -- 解析xml
        local xmlParser = xml.newParser()
        local parsedXml = xmlParser:ParseXmlText(res)

        local code = parsedXml.xml.code_url:value()
        code = code:gsub("<!%[CDATA%[(.*)%]%]>", "%1")
        local status = parsedXml.xml.status:value()
        status = status:gsub("<!%[CDATA%[(.*)%]%]>", "%1")

        if status == '0' then
            if code ~= "" then
                return {
                    code = 200,
                    message = "success",
                    data = {
                        type = types.PaymentResultTypes.QRCODE,
                        qrcode = code,
                        url = "",
                        content = "",
                        out_trade_no = ''
                    }
                }
            end
        end
    end

    return {
        code = 500,
        message = '开发中',
        data = { type = "error" }
    }
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    local vRequest = ctx.request
    local vParams = ctx.params
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    -- 转为json处理
    local reqDataJson = helper.xml_to_json(vRequest['body_string'])
    if reqDataJson == "" then
        return {
            code = 500,
            message = "回调数据异常",
            data = { response = "" }
        }
    end

    local reqData = json.decode(reqDataJson)

    -- 获取签名内容
    local sign = plugin._getSign(reqData, "&key=" .. vAccountOptions['key']):upper()
    if sign == reqData['sign']:upper() then
        -- 签名校验成功
        if reqData['status'] ~= "0" then
            return {
                code = 500,
                message = "支付订单未完成",
                data = { response = "" }
            }
        end
        if reqData['pay_result'] ~= "0" then
            return {
                code = 500,
                message = "支付订单未完成2",
                data = { response = "" }
            }
        end

        -- 商户订单号
        local out_trade_no = reqData['out_trade_no']
        -- 外部系统订单号
        local trade_no = reqData['transaction_id']
        -- 避免精度有问题
        local money = math.floor((reqData['total_fee'] + 0.000005) * 1)

        -- 通知订单处理完成
        local err_code, err_message, response = orderHelper.notify_process(json.encode({
            out_trade_no = trade_no,
            trade_no = out_trade_no,
            amount = money
        }), json.encode(vParams), json.encode(vAccountOptions))

        return {
            code = err_code,
            message = err_message,
            data = { response = response }
        }
    else
        return {
            code = 500,
            message = "签名校验失败",
            data = { response = "" }
        }
    end
end

-- 签名
---@param param table
---@param key string
---@return string
function plugin._getSign(param, key)
    local signstr = ''
    local keys = {}

    for k, _ in pairs(param) do
        table.insert(keys, k)
    end
    table.sort(keys)

    for _, k in ipairs(keys) do
        local v = param[k]
        if k ~= "sign" and v ~= '' then
            signstr = signstr .. k .. '=' .. v .. '&'
        end
    end

    signstr = string.sub(signstr, 1, -2)
    signstr = signstr .. key
    local sign = helper.md5(signstr)
    return sign
end

return plugin
