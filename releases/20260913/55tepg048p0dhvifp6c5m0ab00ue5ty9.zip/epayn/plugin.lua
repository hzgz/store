---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

-- 渠道 易支付V2
-- @class plugin
local plugin = {}

--- 插件信息
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        -- 支持支付类型
        channels = {
            ["alipay"] = { {
                label = '易支付 V2',
                value = 'alipay_epayn'
            } },
            ["wxpay"] = { {
                label = '易支付 V2',
                value = 'wxpay_epayn'
            } },
            ["qqpay"] = { {
                label = '易支付 V2',
                value = 'qqpay_epayn'
            } },
            ["bank"] = { {
                label = '易支付 V2',
                value = 'bank_epayn'
            } }
        },
        options = {
            callback = 1,
            detection_interval = 0
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = 'host',
                label = '通讯地址',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入通讯地址",
                options = {
                    tip = '如: https://xxx.com/xpay/epay'
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'pid',
                label = '商户ID',
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "请输入商户ID",
                options = {
                    tip = '如: 10000'
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'private_key',
                label = '商户私钥',
                type = types.InputTypes.TEXTAREA,
                default = "",
                placeholder = "请输入商户私钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'public_key',
                label = '平台公钥',
                type = types.InputTypes.TEXTAREA,
                default = "",
                placeholder = "请输入平台公钥",
                options = {
                    tip = ''
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'method',
                label = '请求方式',
                type = types.InputTypes.SELECT,
                default = "POST",
                options = {
                    tip = ''
                },
                placeholder = "请选择请求方式",
                values = {
                    {
                        label = "GET",
                        value = "GET"
                    },
                    {
                        label = "POST",
                        value = "POST"
                    }
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'type',
                label = '接口类型',
                type = types.InputTypes.SELECT,
                default = "mapi",
                options = {
                    tip = ''
                },
                placeholder = "请选择接口类型",
                values = {
                    {
                        label = "mapi.php",
                        value = "mapi"
                    },
                    {
                        label = "submit.php",
                        value = "submit"
                    }
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            }
        }
    }
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    local host = vAccountOptions['host']
    local pid = vAccountOptions['pid']
    local private_key = vAccountOptions['private_key']
    -- 提交方式
    local method = vAccountOptions['method']
    -- 提交类型
    local submitType = vAccountOptions['type']

    -- 组装提交请求
    local req = {
        pid = pid,
        type = vOrderInfo['pay_type'],
        notify_url = vOrderInfo['notify_url'],
        return_url = vOrderInfo['return_url'],
        out_trade_no = vOrderInfo['order_id'],
        name = vOrderInfo['subject'],
        money = vOrderInfo['trade_amount'] / 100,
        clientip = vOrderInfo['client_ip'],
        device = vOrderInfo['device']
    }
    local res = ""
    local error_message
    local response = {}

    req["sign"] = plugin._getSign(req, private_key)
    req["sign_type"] = "RSA"

    -- 判断提交方式
    if submitType == 'mapi' then
        -- mapi
        local uri = host .. "/mapi.php"

        print("[插件] 请求内容" .. funcs.table_http_query(req))

        if method == "POST" then
            local params = {
                query = "",
                body = funcs.table_http_query(req),
                form = "",
                timeout = "30s",
                headers = {
                    ["content-type"] = "application/x-www-form-urlencoded"
                }
            }

            response, error_message = http.request("POST", uri, params)
            if response and response.body then
                res = response.body
            end
        else
            response, error_message = http.request(method, uri, {
                query = funcs.table_http_query(req),
                timeout = "30s",
                headers = {}
            })
            if response and response.body then
                res = response.body
            end
        end

        print("[插件] 返回内容" .. res)
        local returnInfo = json.decode(res)

        if returnInfo == nil then
            return {
                code = 500,
                message = '请求响应错误 返回内容:' .. res,
                data = { type = "error" }
            }
        end

        if returnInfo['code'] ~= 1 then
            return {
                code = 500,
                message = returnInfo['msg'] or returnInfo['message'],
                data = { type = "error" }
            }
        end

        if returnInfo['payurl'] then
            return {
                code = 200,
                message = "success",
                data = {
                    type = types.PaymentResultTypes.JUMP,
                    qrcode = '',
                    url = returnInfo["payurl"],
                    content = "",
                    out_trade_no = returnInfo['trade_no']
                }
            }
        end

        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode = returnInfo['qrcode'],
                url = returnInfo["payurl"],
                content = "",
                out_trade_no = returnInfo['trade_no']
            }
        }
    else
        -- submit 此方式为提交到外部也就按
        local uri = host .. "/submit.php"
        -- 处理发送内容
        if method == "POST" then
            local content = plugin._pagePay(req, uri, "正在跳转中,未跳转点击我")

            return {
                code = 200,
                message = "success",
                data = {
                    type = types.PaymentResultTypes.HTML,
                    qrcode = "",
                    url = "",
                    content = content
                }
            }
        end

        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.JUMP,
                qrcode = "",
                url = uri .. "?" .. funcs.table_http_query(req),
                content = ""
            }
        }
    end
end

-- 支付回调
---@param ctx types.OrderNotifyParams
function plugin.notify(ctx)
    local vRequest = ctx.request
    local vParams = ctx.params
    local vOrderInfo = ctx.order_info
    local vAccountOptions = ctx.account_options

    -- 判断请求方式
    local reqData = ""
    if vRequest['method'] == 'POST' then
        reqData = (vRequest['body'])
    else
        reqData = (vRequest['query'])
    end

    -- 获取签名内容
    local sign = plugin.checkNotifySign(reqData, reqData['sign'], vAccountOptions['public_key'])
    if sign == reqData['sign'] then
        -- 签名校验成功
        if reqData['pid'] ~= vAccountOptions['pid'] then
            return {
                code = 500,
                message = "交易商户号异常",
                data = { response = "" }
            }
        end

        if reqData['trade_status'] ~= "TRADE_SUCCESS" then
            return {
                code = 500,
                message = "交易未完成",
                data = { response = "" }
            }
        end

        -- 商户订单号
        local out_trade_no = reqData['out_trade_no']
        -- 外部系统订单号
        local trade_no = reqData['trade_no']
        -- 避免精度有问题
        local money = math.floor((reqData['money'] + 0.000005) * 100)

        -- 通知订单处理完成
        local err_code, err_message, response = orderHelper.notify_process(json.encode({
            out_trade_no = trade_no,
            trade_no = out_trade_no,
            amount = money
        }), json.encode(vParams), json.encode(vAccountOptions))

        return {
            code = err_code,
            message = err_message,
            data = { response = response }
        }
    else
        return {
            code = 500,
            message = "签名校验失败",
            data = { response = "" }
        }
    end
end

-- 发起支付（页面跳转）
---@param param table
---@param submit_url string
---@param button string
---@return string
function plugin._pagePay(param, submit_url, button)
    local html = '<form id="dopay" action="' .. submit_url .. '" method="post">'

    for k, v in pairs(param) do
        html = html .. '<input type="hidden" name="' .. k .. '" value="' .. v .. '"/>'
    end

    html = html .. '<input type="submit" value="' .. button .. '"></form><script>document.getElementById("dopay").submit();</script>'

    return html
end

-- 签名
---@param param table
---@param private_key string
---@return string
function plugin._getSign(param, private_key)
    local signstr = ''
    local keys = {}

    for k, _ in pairs(param) do
        table.insert(keys, k)
    end
    table.sort(keys)

    for _, k in ipairs(keys) do
        local v = param[k]
        if k ~= "sign" and k ~= "sign_type" and v ~= '' then
            signstr = signstr .. k .. '=' .. v .. '&'
        end
    end
    signstr = string.sub(signstr, 1, -2)

    local sign = helper.rsa_private_sign_base64(signstr, private_key, "SHA256")
    return sign
end

-- 验证回调签名
---@param param table
---@param sign string
---@param public_key string
---@return string
function plugin.checkNotifySign(param, sign, public_key)
    local signstr = ''
    local keys = {}

    for k, _ in pairs(param) do
        table.insert(keys, k)
    end
    table.sort(keys)

    for _, k in ipairs(keys) do
        local v = param[k]
        if k ~= "sign" and k ~= "sign_type" and v ~= '' then
            signstr = signstr .. k .. '=' .. v .. '&'
        end
    end
    signstr = string.sub(signstr, 1, -2)

    return helper.rsa_public_verify_sign_base64(signstr, sign, public_key, "SHA256")
end

return plugin
