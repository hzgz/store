---@diagnostic disable: undefined-global
-- 载入插件
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local funcs = funcs or require("funcs")
local http = http or require("http")
local json = json or require("json")
local helper = helper or require("helper")
local orderHelper = orderHelper or require("orderHelper")
local log = log or require("log")

local PAY_CHANNEL_CODE_YUN_WECHAT_CAR_HG = "yun_wechat_car_hg"

local GATEWAY = {
    API_BASE = "/api"
}

local DEFAULT_DEVICE_NAME = "慧根车机"

local _plugin_dir = "."
do
    local src = debug.getinfo(1, "S").source or ""
    src = src:gsub("^@", "")
    local pos = src:find("[/\\][^/\\]*$")
    if pos then
        _plugin_dir = src:sub(1, pos - 1)
    end
end
local _log_file = _plugin_dir .. "/plugin_login.log"

--- 安全序列化任意值，防止 json.encode 抛错
---@param v any
---@return string
local function safeJson(v)
    local ok, res = pcall(json.encode, v)
    if ok and res then
        return res
    end
    return tostring(v)
end

--- 追加写入同目录日志文件，用于排查框架是否调用插件回调
---@param tag string
---@param msg string
local function logToFile(tag, msg)
    pcall(function()
        local h = io.open(_log_file, "a")
        if h then
            local t = os.date("%Y-%m-%d %H:%M:%S")
            h:write(string.format("[%s] [%s] %s\n", t, tag, msg))
            h:close()
        end
    end)
end

---@param v any
---@return table
local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

---@param body string
---@return table|nil
local function decodeBody(body)
    if not body or body == "" then
        return nil
    end
    local ok, data = pcall(json.decode, body)
    if ok and type(data) == "table" then
        return data
    end
    return nil
end

---判断接口返回码是否为成功
---@param code any
---@return boolean
local function isSuccessCode(code)
    if code == nil then
        return true
    end
    if code == true then
        return true
    end
    if type(code) == "boolean" then
        return false
    end
    local num = tonumber(code)
    if num == nil then
        return false
    end
    return num == 0 or num == 1 or num == 200
end

---@param value any
---@return boolean
local function isBlank(value)
    return value == nil or value == ""
end

---URL 解码
---@param s string
---@return string
local function urlDecode(s)
    s = tostring(s or "")
    s = s:gsub("%+", " ")
    s = s:gsub("%%(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end)
    return s
end

---@param ctx table
---@return table
local function mergeOptions(ctx)
    ctx = ctx or {}
    local options = {}
    local accountInfo = toTable(ctx.account_info)
    local sources = {
        toTable(accountInfo.options),
        toTable(ctx.plugin_option),
        toTable(ctx.plugin_options),
        toTable(ctx.account_options)
    }
    for _, source in ipairs(sources) do
        for key, value in pairs(source) do
            if value ~= nil then
                options[key] = value
            end
        end
    end
    options.account_id = accountInfo.id
    return options
end

---@param proxy string
---@return string
local function encodeProxyCredentials(proxy)
    proxy = tostring(proxy or "")
    local prefix, userInfo, address = proxy:match("^([%w+.-]+://)([^@]+)@(.+)$")
    if not prefix then
        return proxy
    end
    local username, password = userInfo:match("^([^:]*):(.*)$")
    if not username then
        return proxy
    end
    return prefix .. helper.url_encode(username) .. ":" .. helper.url_encode(password) .. "@" .. address
end

---@param accountOptions table
---@return string
local function getProxy(accountOptions)
    accountOptions = accountOptions or {}
    local mode = accountOptions.proxy_mode or "no_proxy"
    if mode == "custom_proxy" then
        return encodeProxyCredentials(accountOptions.proxy or "")
    end
    if mode ~= "cloud_proxy" then
        return ""
    end

    local poolId = tonumber(accountOptions.proxy_pool_id or 0) or 0
    if poolId <= 0 then
        return ""
    end
    local itemId = tonumber(accountOptions.proxy_pool_item_id or 0) or 0
    local proxyItem = helper.proxy_pool_fetch(poolId, itemId)
    if proxyItem and proxyItem.proxy_url and proxyItem.proxy_url ~= "" then
        local proxyId = tonumber(proxyItem.proxy_id or 0) or 0
        if proxyId ~= itemId then
            accountOptions.proxy_pool_item_id = proxyId
            if accountOptions.account_id then
                helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", proxyId)
            end
        end
        return encodeProxyCredentials(proxyItem.proxy_url)
    end
    if itemId > 0 then
        helper.proxy_pool_release(itemId)
    end
    accountOptions.proxy_pool_item_id = 0
    if accountOptions.account_id then
        helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", "0")
    end
    return ""
end

---@param method string
---@param url string
---@param options table
---@return any, string|nil
local function request(method, url, options)
    return http.request(method, url, options or {})
end

---@param options table
---@return string
local function getPayMode(options)
    local mode = options and options.pay_mode or ""
    if mode == "receipt" or mode == "smallbook" then
        return mode
    end
    return "self"
end

---@param options table
---@return boolean
local function isSpecialPayMode(options)
    return getPayMode(options) == "receipt" or getPayMode(options) == "smallbook"
end

---@param errCode number
---@param errMessage string
---@return table
local function errorResponse(errCode, errMessage)
    return {
        code = errCode,
        message = errMessage,
        data = {}
    }
end

---@param options table
---@return string
local function getGatewayAddress(options)
    local gateway = options and options.gateway or ""
    if isBlank(gateway) then
        return ""
    end
    return helper.channel_gateway_addr(gateway)
end

---@param options table
---@return string
local function getGatewayBase(options)
    local serverAddress = getGatewayAddress(options)
    if serverAddress == "" then
        return ""
    end
    return serverAddress .. GATEWAY.API_BASE
end

---@param options table
---@return string
local function getWxid(options)
    return tostring(options and options.wxid or "")
end

---调用 m.js 网关接口，返回标准响应
---@param method string
---@param path string
---@param options table
---@param params table|nil
---@param query string|nil
---@return table|nil, string
local function mRequest(method, path, options, params, query)
    local base = getGatewayBase(options)
    if base == "" then
        return nil, "暂未配置支付网关"
    end
    local url = base .. path
    if query and query ~= "" then
        url = url .. "?" .. query
    end
    local reqOptions = {
        timeout = options and options.timeout or "30s",
        headers = {
            ["accept"] = "application/json",
            ["content-type"] = "application/json"
        }
    }
    if params ~= nil then
        reqOptions.body = json.encode(params)
    end
    local response, requestError = request(method, url, reqOptions)
    if requestError ~= nil or response == nil then
        return nil, string.format("调用%s失败: %s", path, requestError or "请求失败")
    end
    if response.status_code ~= 200 then
        return nil, string.format("调用%s失败,状态码:%s", path, tostring(response.status_code))
    end
    local data = decodeBody(response.body)
    if not data then
        logToFile("BIN", string.format("mRequest %s 响应解析失败，原始body长度=%d 前缀(hex)=%s",
            path, #tostring(response.body),
            tostring(response.body):sub(1, 16):gsub(".", function(c)
                return string.format("%02x", string.byte(c))
            end)))
        return nil, string.format("调用%s响应解析失败", path)
    end
    if data.Code ~= nil and not isSuccessCode(data.Code) then
        local errText = data.Text or data.Message or string.format("调用%s失败", path)
        logToFile("BIN", string.format("mRequest %s 网关返回错误Code=%s Text=%s 原始响应=%s",
            path, tostring(data.Code), tostring(errText), safeJson(data)))
        return nil, errText
    end
    if data.code ~= nil and not isSuccessCode(data.code) then
        local errText = data.msg or data.message or string.format("调用%s失败", path)
        logToFile("BIN", string.format("mRequest %s 网关返回错误code=%s msg=%s 原始响应=%s",
            path, tostring(data.code), tostring(errText), safeJson(data)))
        return nil, errText
    end
    return data, ""
end

---从响应中提取字符串字段
---@param value any
---@param depth integer
---@return string|nil
local function extractStringField(value, depth)
    depth = depth or 0
    if depth > 4 then
        return nil
    end
    if type(value) == "string" then
        if value == "" then
            return nil
        end
        local decoded = decodeBody(value)
        if decoded then
            return extractStringField(decoded, depth + 1)
        end
        return value
    end
    if type(value) ~= "table" then
        return nil
    end
    for _, key in ipairs({ "wxid", "Wxid", "uuid", "Uuid", "qrurl", "QrCodeUrl", "qrcode", "QrCode",
        "qrCode", "QRCode", "qrcode_url", "qr_url", "qrUrl", "qr_code", "Qrcode", "QrContent",
        "QrUrl", "code", "Code", "url", "Url", "content", "Content" }) do
        local field = value[key]
        if field ~= nil and tostring(field) ~= "" then
            return tostring(field)
        end
    end
    local nested = extractStringField(value.Data, depth + 1) or
        extractStringField(value.data, depth + 1) or
        extractStringField(value.Result, depth + 1) or
        extractStringField(value.result, depth + 1)
    if nested then
        return nested
    end
    for _, key in pairs(value) do
        if type(key) == "string" and key:lower():find("qrcode") then
            local field = value[key]
            if field ~= nil and tostring(field) ~= "" then
                return tostring(field)
            end
        end
    end
    return nil
end

---@param options table
---@return table|string
local function getProxyInfo(options)
    options = options or {}
    local proxy = getProxy(options)
    if proxy == "" then
        return nil
    end
    local host, port, username, password
    -- 支持 socks5://user:pass@host:port 格式
    local userPart = proxy:match("^socks5://([^@]+)@(.+)$")
    if userPart then
        username, password = userPart:match("^([^:]*):(.*)$")
        host, port = proxy:match("^socks5://[^@]+@([^:]+):(%d+)$")
    else
        host, port = proxy:match("^socks5://([^:]+):(%d+)$")
    end
    if not host or not port then
        return nil
    end
    return {
        ProxyIp = host .. ":" .. port,
        ProxyUser = username or "",
        ProxyPassword = password or ""
    }
end

---@param params table
---@param requiredFields string[]
---@return boolean, string
local function validateParams(params, requiredFields)
    for _, field in ipairs(requiredFields) do
        if isBlank(params[field]) then
            return false, string.format("缺少必要参数: %s", field)
        end
    end
    return true, ""
end

-- @class types.plugin
local plugin = {}

--- 插件信息
---@return types.PluginInfo
function plugin.pluginInfo()
    ---@type types.PluginInfo
    return {
        channels = {
            ["wxpay"] = { {
                label = "微信-车载_慧根",
                value = PAY_CHANNEL_CODE_YUN_WECHAT_CAR_HG,
                options = {
                    use_add_amount = 1,
                    use_qrcode_login = 1
                },
                info = "微信 车载方式登录"
            } }
        },
        options = {
            crontab_list = { {
                crontab = "*/2 * * * * *",
                fun = "cron",
                args = "",
                name = "检查账号状态",
                scope = "account",
                options = {
                    has_wait_pay_order = 0
                }
            }, {
                crontab = "*/2 * * * * *",
                fun = "pollReceipt",
                args = "",
                name = "高频拉取收款消息",
                scope = "account",
                options = {
                    has_wait_pay_order = 0,
                    disable_random = 1
                }
            } }
        }
    }
end

-- 获取form表单
---@param ctx types.FormContext
---@return types.FormResponse
function plugin.formItems(ctx)
    ---@type types.FormResponse
    return {
        inputs = {
            {
                name = "gateway",
                label = "选择网关",
                type = types.InputTypes.SELECT,
                default = "",
                options = {
                    tip = "",
                    chose_gateway = 1
                },
                placeholder = "请选择网关",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择"
                } }
            },
            {
                name = "pay_mode",
                label = "收款方式",
                type = types.InputTypes.RADIO,
                default = "self",
                options = {
                    tip = "收款单和小账本会通过车载登录态自动获取wxid"
                },
                placeholder = "请选择收款方式",
                values = { {
                    label = "个人上传",
                    value = "self"
                }, {
                    label = "收款单",
                    value = "receipt"
                }, {
                    label = "小账本",
                    value = "smallbook"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择收款方式"
                } }
            },
            {
                name = "wxapp_account_name",
                label = "收款商户",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt'",
                options = {
                    tip = "已选中的收款账号商户名,由小程序直连自动探测并缓存,可手动修改"
                },
                placeholder = "自动探测并缓存"
            },
            {
                name = "wxapp_aid",
                label = "收款账号ID",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt'",
                options = {
                    tip = "account_id,由小程序直连自动缓存,保存后下单直接复用不再重新拉账号"
                },
                placeholder = "自动探测并缓存"
            },
            {
                name = "wxapp_account_type",
                label = "账号类型",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt'",
                options = {
                    tip = "account_type 1/2/3,由小程序直连自动缓存"
                },
                placeholder = "自动探测并缓存"
            },
            {
                name = "wxapp_sid",
                label = "收款SID",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt'",
                options = {
                    tip = "小程序登录后的会话SID,由小程序直连自动缓存"
                },
                placeholder = "自动探测并缓存"
            },
            {
                name = "wxapp_shop_id",
                label = "店铺ID",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt'",
                options = {
                    tip = "shop_id,创建收款单必填,由 account/get 自动缓存"
                },
                placeholder = "自动探测并缓存"
            },
            {
                name = "smallbook_sid",
                label = "小账本SID",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'smallbook'",
                options = {
                    tip = "小账本小程序登录会话SID,由小程序直连自动缓存,保存后下单直接复用不再重新登录"
                },
                placeholder = "自动探测并缓存"
            },
            {
                name = "wxid",
                label = "wxid",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.pay_mode == 'receipt' || this.formModel.options.pay_mode == 'smallbook' || this.formModel.options.pay_mode == 'self'",
                options = {
                    tip = "登录车载微信后通过扫码登录自动获取，也可手动填写"
                },
                placeholder = "自动获取或手动输入wxid"
            },
            {
                name = "qrcode",
                label = "收款码地址",
                type = types.InputTypes.INPUT,
                default = "",
                options = {
                    append_deqrocde = 1,
                    tip = ""
                },
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.pay_mode == 'self' && this.formModel.options.type == 'url'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "qrcode_file",
                label = "收款码图片",
                type = types.InputTypes.IMAGE,
                default = "",
                options = {
                    tip = ""
                },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.pay_mode == 'self' && this.formModel.options.type == 'image'",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "type",
                label = "收款码类型",
                type = types.InputTypes.SELECT,
                default = "url",
                options = {
                    tip = ""
                },
                placeholder = "请选择收款码类型",
                when = "this.formModel.options.pay_mode == 'self'",
                values = { {
                    label = "地址",
                    value = "url"
                }, {
                    label = "图片",
                    value = "image"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请输入"
                } }
            },
            {
                name = "proxy_mode",
                label = "代理模式",
                type = types.InputTypes.SELECT,
                default = "no_proxy",
                options = { tip = "选择代理使用模式" },
                placeholder = "请选择代理模式",
                values = { {
                    label = "不使用代理",
                    value = "no_proxy"
                }, {
                    label = "使用自定义代理",
                    value = "custom_proxy"
                }, {
                    label = "使用本站代理池",
                    value = "cloud_proxy"
                } },
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择代理模式"
                } }
            },
            {
                name = "proxy",
                label = "Socks5代理地址",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.proxy_mode == 'custom_proxy'",
                options = { tip = "格式：socks5://IP:端口，或 socks5://用户名:密码@IP:端口" },
                placeholder = "例如：socks5://127.0.0.1:1080"
            },
            {
                name = "proxy_pool_id",
                label = "绑定代理池",
                type = "chose_proxy_pool",
                default = "-1",
                when = "this.formModel.options.proxy_mode == 'cloud_proxy'",
                options = { tip = "请选择绑定的代理池" },
                placeholder = "请选择代理池",
                rules = { {
                    required = true,
                    trigger = { "input", "blur" },
                    message = "请选择代理池"
                } }
            },
            {
                name = "proxy_pool_item_id",
                label = "绑定代理",
                type = types.InputTypes.INPUT,
                default = "0",
                hidden = 1
            }
        }
    }
end

---@param response any
---@return boolean
function plugin._is_wxid_invalid_response(response)
    if type(response) == "string" then
        return string.find(response, "登录态", 1, true) ~= nil or
            string.find(response, "登录失效", 1, true) ~= nil or
            string.find(response, "登录过期", 1, true) ~= nil or
            string.find(response, "未登录", 1, true) ~= nil or
            string.find(response, "session", 1, true) ~= nil
    end
    if type(response) ~= "table" then
        return false
    end
    return plugin._is_wxid_invalid_response(response.msg) or
        plugin._is_wxid_invalid_response(response.errmsg) or
        plugin._is_wxid_invalid_response(response.message) or
        plugin._is_wxid_invalid_response(response.text) or
        plugin._is_wxid_invalid_response(response.Text) or
        plugin._is_wxid_invalid_response(response.data)
end

---@param accountInfo table
---@param options table
---@return boolean, string
function plugin._verify_special_account(accountInfo, options)
    if isBlank(getWxid(options)) then
        return false, "请先扫码登录车载微信账号"
    end
    if getGatewayAddress(options) == "" then
        return false, "暂未配置支付网关"
    end
    return true, ""
end

-- 实验:cron 节流触发「小程序直连」探测,便于观察车载 wxid 能否进收款单/小账本小程序并拉账号
-- 仅在 receipt/smallbook 模式启用;程序默认间隔内只探测一次;成功后缓存账号
-- 返回 boolean(是否已触发探测)
function plugin._maybe_wxapp_probe(accountInfo, accountOptions)
    local mode = getPayMode(accountOptions)
    if mode ~= "receipt" and mode ~= "smallbook" then return false end
    if isBlank(getWxid(accountOptions)) then return false end

    local now = os.time()
    local lastAt = tonumber(accountOptions.wxapp_probe_at or 0) or 0
    if now - lastAt < 120 then return false end

    helper.channel_account_set_option(accountInfo.id, "wxapp_probe_at", tostring(now))

    if mode == "smallbook" then
        -- 小账本仅需 sid,经 JSLogin 换小账本 code→登录→sid 后缓存 smallbook_sid
        local fresh = plugin._wxapp_probe_smallbook(accountOptions)
        if fresh then
            local ssid = tostring(fresh.sid or "")
            if not isBlank(ssid) then
                helper.channel_account_set_option(accountInfo.id, "smallbook_sid", ssid)
            end
        end
        return true
    end

    local account = plugin._wxapp_probe_mini_entry(accountOptions)
    if account then
        if not isBlank(account.sid) then
            helper.channel_account_set_option(accountInfo.id, "wxapp_sid", tostring(account.sid))
        end
        if not isBlank(account.aid) then
            helper.channel_account_set_option(accountInfo.id, "wxapp_aid", tostring(account.aid))
        end
        if not isBlank(account.account_type) then
            helper.channel_account_set_option(accountInfo.id, "wxapp_account_type", tostring(account.account_type))
        end
        if not isBlank(account.account_name) then
            helper.channel_account_set_option(accountInfo.id, "wxapp_account_name", tostring(account.account_name))
        end
    end
    -- 探测返回通常不带 shop_id,这里主动经 account/get 解析并缓存,避免下单时重复拉取
    -- 注意:本函数定义早于小程序助手(local 声明靠后),不能直接引用 wxappGatewayByAccountType 等,
    -- 统一委托给靠后定义、作用域完整的 plugin._wxapp_resolve_shop_id 处理。
    if account then
        pcall(plugin._wxapp_resolve_shop_id, accountInfo, account)
    end
    return true
end

-- 创建订单
---@param ctx types.OrderCreateParams
---@return types.OrderCreateResp
function plugin.create(ctx)
    local orderInfo = ctx.order_info or {}
    local accountInfo = toTable(ctx.account_info)
    local accountOptions = mergeOptions(ctx)

    if getPayMode(accountOptions) == "self" then
        local qrcodeType = tostring(accountOptions.type or "url")
        local configured = (qrcodeType == "image" and not isBlank(accountOptions.qrcode_file)) or
            (qrcodeType ~= "image" and not isBlank(accountOptions.qrcode))
        if not configured then
            local err = string.format("未配置收款码%s", qrcodeType == "image" and "图片" or "地址")
            logToFile("PAY", "create self模式配置缺失: " .. err)
            return errorResponse(500, err)
        end
    else
        local ok, verifyError = plugin._verify_special_account(accountInfo, accountOptions)
        if not ok then
            logToFile("PAY", "create _verify_special_account 失败: " .. tostring(verifyError))
            return errorResponse(500, verifyError)
        end
    end

    return plugin._create_pay_qrcode(orderInfo, accountOptions)
end

---通过 m.js 网关 TenPay 接口生成收款二维码
---@param orderInfo table
---@param options table
---@return table
function plugin._create_pay_qrcode(orderInfo, options)
    local mode = getPayMode(options)
    if mode == "self" then
        return plugin._create_self_pay_qrcode(orderInfo, options)
    end

    -- 收款单/小账本一律走「小程序直连」拉账号出码,绕开云端 TenPay 账户匹配(-17)
    if mode == "receipt" then
        return plugin._wxapp_create_receipt(orderInfo, options)
    end
    if mode == "smallbook" then
        return plugin._wxapp_create_smallbook(orderInfo, options)
    end

    local wxid = getWxid(options)
    local valid, errMessage = validateParams(options, { "wxid" })
    if not valid then
        logToFile("PAY", "_create_pay_qrcode wxid校验失败: " .. tostring(errMessage))
        return errorResponse(500, errMessage)
    end

    local apiPath
    local params = {
        Wxid = wxid,
        Money = tostring(orderInfo.trade_amount or 0),
        Name = tostring(orderInfo.order_id or "")
    }
    if mode == "receipt" then
        apiPath = "/TenPay/GeMaSkdPayQCode"
        params.Remark = tostring(orderInfo.remark or orderInfo.order_id or "")
    elseif mode == "smallbook" then
        apiPath = "/TenPay/SjSkdPayQCode"
        params.Remark = tostring(orderInfo.remark or orderInfo.order_id or "")
    else
        apiPath = "/TenPay/GeMaPayQCode"
    end

    local data, mErr = mRequest("POST", apiPath, options, params)
    if not data then
        logToFile("PAY", "_create_pay_qrcode mRequest失败: " .. tostring(mErr))
        return errorResponse(500, mErr)
    end

    local qrcode = extractStringField(data.Data) or extractStringField(data.data)
    if isBlank(qrcode) then
        logToFile("PAY", "_create_pay_qrcode 响应无二维码: " .. safeJson(data))
        return errorResponse(500, string.format("%s未返回二维码", apiPath))
    end

    if qrcode:find("^data:image") or qrcode:find("^[%w%+/=]+$") then
        local written, filePath = helper.save_image_cache_base64(qrcode)
        if not written then
            return errorResponse(500, "收款二维码保存失败")
        end
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = filePath,
                qrcode = "",
                url = "",
                content = "",
                out_trade_no = tostring(orderInfo.order_id or "")
            }
        }
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = qrcode,
            url = "",
            content = "",
            out_trade_no = tostring(orderInfo.order_id or "")
        }
    }
end

-- ============ 小程序直连收款实验模块(实验) ============
-- 思路:car 车载登录态通过 m.js 网关 /Wxapp/JSLogin 换取「微信收款单小程序」的 code,
--      再直连微信官方收款后台 account/list 拉取收款账号(aid/account_type),最后
--      receipt/create + receipt/getwxacode 出码,绕开慧根云端 TenPay 的账户匹配(-17)。
-- 每一跳均保留原始响应日志,便于按实际返回适配。
local WXAPP_EXP = {
    RECEIPT = {
        app_id = "wx264e9b6d4d484f51",
        login_url = "https://payapp.wechatpay.cn/receiptwxmgr/account/list?miniprogram_version=3.15.9&js_code=",
        referer = "https://servicewechat.com/wx264e9b6d4d484f51/187/page-frame.html"
    },
    SMALLBOOK = {
        app_id = "wx28be8489b7a36aaa",
        login_url = "https://smallbook.wxpapp.weixin.qq.com/qrapp/user/login?js_code=",
        referer = "https://servicewechat.com/wx28be8489b7a36aaa/1181/page-frame.html"
    }
}

-- 账号类型 -> 收款单网关
local function wxappGatewayByAccountType(accountType)
    local t = tonumber(accountType) or accountType
    if t == 1 then return "https://payapp.wechatpay.cn/receiptmdmgr" end
    if t == 2 then return "https://payapp.wechatpay.cn/receiptwxmgr" end
    if t == 3 then return "https://payapp.wechatpay.cn/receiptsjtmgr" end
    return nil
end

-- 从任意响应中提取小程序登录 code/sid 类字段(先深搜常见字段)
-- 注意:顶层业务码常是数字(如 Code=0),而真实 js_code 是 32 位字母数字串,
-- 故优先返回「非纯数字」候选,避免把业务状态码当成登录 code。
local function wxappSearchField(data, keys)
    local function isPureNumeric(v)
        local s = tostring(v)
        return s:match("^%d+$") ~= nil
    end
    if type(data) == "string" then
        local ok, decoded = pcall(json.decode, data)
        if ok then return wxappSearchField(decoded, keys) end
        return nil
    end
    if type(data) ~= "table" then return nil end

    -- 第一遍:只取非纯数字候选(优先命中真实 code)
    local numericFallback
    local stack = { data }
    while #stack > 0 do
        local t = table.remove(stack)
        if type(t) == "table" then
            for _, key in ipairs(keys) do
                local v = t[key]
                if v ~= nil and tostring(v) ~= "" then
                    if isPureNumeric(v) then
                        if numericFallback == nil then numericFallback = tostring(v) end
                    else
                        return tostring(v)
                    end
                end
            end
            for _, sub in ipairs({ t.data, t.result, t.Data, t.Result }) do
                if type(sub) == "table" then table.insert(stack, sub) end
            end
        end
    end
    return numericFallback
end

-- 显式按已知路径提取(JSON 结构从日志确认: {Code, Data={...}} ),避免模糊深搜误判
local function wxappField(data, path)
    if not data then return nil end
    if type(data) == "string" then
        local ok, d = pcall(json.decode, data)
        if not ok then return nil end
        data = d
    end
    if type(data) ~= "table" then return nil end
    local cur = data
    for _, k in ipairs(path) do
        if type(cur) ~= "table" then return nil end
        cur = cur[k]
    end
    if cur == nil then return nil end
    local s = tostring(cur)
    return (s == "") and nil or s
end

-- 直连微信官方收款单小程序的 GET 请求(带小程序 UA/Referer)
local function wxappDirectGet(url, referer)
    return request("GET", url, {
        timeout = "30s",
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = referer,
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })
end

-- 解析直连响应体为 table,若 HTTP/JSON 失败返回 nil,error
local function wxappDecode(resp)
    if not resp then return nil, "请求失败" end
    if resp.status_code ~= 200 then return nil, string.format("HTTP状态码:%s", tostring(resp.status_code)) end
    if not resp.body or resp.body == "" then return nil, "响应为空" end
    local ok, decoded = pcall(json.decode, resp.body)
    if not ok or type(decoded) ~= "table" then return nil, "响应解析失败:" .. tostring(resp.body) end
    return decoded, ""
end

-- 探测拿到账号后,主动经 account/get 解析并缓存该账号的 shop_id(店铺ID),避免下单重复拉取。
-- 本函数靠后定义,可访问 wxappGatewayByAccountType/wxappDirectGet/wxappDecode/WXAPP_EXP 等助手,
-- 由靠前定义的 plugin._maybe_wxapp_probe 通过 plugin. 委托调用(避免 local 作用域越界)。
function plugin._wxapp_resolve_shop_id(accountInfo, account)
    if not account then return end
    local shop_id = tostring(account.shop_id or "")
    if shop_id ~= "" then
        if not isBlank(accountInfo.id) then
            helper.channel_account_set_option(accountInfo.id, "wxapp_shop_id", tostring(shop_id))
        end
        return
    end
    if isBlank(account.aid) or isBlank(account.account_type) then
        return
    end
    local gateway = wxappGatewayByAccountType(account.account_type)
    if not gateway then
        return
    end
    local agUrl = gateway .. "/account/get?miniprogram_version=3.15.10"
    agUrl = agUrl .. "&account_id=" .. helper.url_encode(account.aid)
    agUrl = agUrl .. "&account_type=" .. tostring(account.account_type)
    agUrl = agUrl .. "&sid=" .. helper.url_encode(account.sid)
    local agResp = wxappDirectGet(agUrl, WXAPP_EXP.RECEIPT.referer)
    local agData = wxappDecode(agResp)
    if agData and agData.data and agData.data.auth_shop_list
        and type(agData.data.auth_shop_list) == "table"
        and #agData.data.auth_shop_list > 0 then
        shop_id = tostring(agData.data.auth_shop_list[1].shop_id or "")
    end
    if not isBlank(shop_id) and not isBlank(accountInfo.id) then
        helper.channel_account_set_option(accountInfo.id, "wxapp_shop_id", tostring(shop_id))
    end
end

-- 通用:m.js /Wxapp 系列接口用车载 wxid 换取指定小程序的 code,并在该小程序自家登录接口换 sid。
-- 返回 sid, err(仅供直连探测/下单共用)
function plugin._wxapp_resolve_sid(options, app)
    local wxid = getWxid(options)
    if isBlank(wxid) then return nil, "缺少wxid" end

    -- 1) 授权小程序:期望返回可换 sid 的 code
    local jslogin, jsErr = mRequest("POST", "/Wxapp/JSLogin", options, {
        Appid = app.app_id,
        Wxid = wxid
    })
    if not jslogin then
        return nil, "JSLogin失败:" .. tostring(jsErr or "")
    end
    local code = wxappField(jslogin, { "Data", "code" })
        or wxappField(jslogin, { "data", "code" })
        or wxappSearchField(jslogin, { "code", "js_code", "authCode", "auth_code" })

    -- 2) 获取小程序支付 sessionid(m.js 直出 sid 的更直接路径,优先尝试)
    local sidFromSession
    local sidResp, sidErr = mRequest("POST", "/Wxapp/JSGetSessionid", options, {
        Appid = app.app_id,
        Wxid = wxid
    })
    if sidResp then
        sidFromSession = wxappField(sidResp, { "Data", "Sessionid" })
            or wxappField(sidResp, { "Data", "sessionid" })
            or wxappField(sidResp, { "data", "Sessionid" })
            or wxappSearchField(sidResp,
                { "sid", "Sid", "Sessionid", "receipt_sid", "sessionid", "session_id", "SessionId", "jsessionid" })
        local sessionCode = wxappField(sidResp, { "Data", "code" })
            or wxappField(sidResp, { "data", "code" })
            or wxappSearchField(sidResp, { "code", "Code", "js_code" })
        if (not code or code == "") and sessionCode then code = sessionCode end
    end

    -- 3) 取 sid:js_code 登录是 yyb 验证过的正道(真正发 code),失败再退回 JSGetSessionid 的 Sessionid
    local sid
    if code and code ~= "" then
        local loginResp = wxappDirectGet(app.login_url .. helper.url_encode(code), app.referer)
        local loginData, lerr = wxappDecode(loginResp)
        if not loginData then
            return nil, "js_code 换 sid 失败:" .. tostring(lerr)
        end
        sid = wxappField(loginData, { "Data", "sid" })
            or wxappField(loginData, { "data", "sid" })
            or wxappField(loginData, { "sid" })
            or wxappSearchField(loginData, { "sid", "Sid", "receipt_sid", "receiptSid" })
    end
    if (not sid or sid == "") and sidFromSession and sidFromSession ~= "" then
        sid = sidFromSession
    end
    if (not sid or sid == "") then
        return nil, "未能取得小程序 sid/code,请查看 WXAPP 日志按返回适配"
    end

    return sid, ""
end

-- 尝试用 m.js /Wxapp 系列接口取得车载 wxid 进入收款单小程序的能力(实验)
-- 返回 data, err
function plugin._wxapp_probe_mini_entry(options)
    local wxid = getWxid(options)
    if isBlank(wxid) then return nil, "缺少wxid" end

    local app = WXAPP_EXP.RECEIPT

    -- 1)-3) 换 sid(复用通用逻辑)
    local sid, resolveErr = plugin._wxapp_resolve_sid(options, app)
    if not sid then
        return nil, resolveErr
    end

    -- 4) 拉取收款账号列表(关键:这就是"获取相关账号")
    local listResp = wxappDirectGet(
        "https://payapp.wechatpay.cn/receiptwxmgr/account/list?miniprogram_version=3.15.10&sid=" .. helper.url_encode(sid),
        app.referer)
    local listData, lerr2 = wxappDecode(listResp)
    if not listData then
        return nil, "account/list失败:" .. tostring(lerr2)
    end

    local accounts = listData.data and listData.data.account_list or listData.account_list or {}
    if type(accounts) ~= "table" then accounts = {} end
    local selected
    for _, acct in ipairs(accounts) do
        if acct.account_status == "ACTIVATED" then
            selected = acct
            break
        end
    end
    if not selected then
        if #accounts == 0 then
            return nil, "account/list 无账号列表:" .. safeJson(listData)
        end
        selected = accounts[1]
    end

    return {
        sid = sid,
        aid = tostring(selected.account_id or selected.aid or ""),
        account_type = tostring(selected.account_type or ""),
        account_name = tostring(selected.account_name or selected.name or ""),
        shop_id = tostring(selected.shop_id or ""),
        raw = safeJson(listData)
    }, ""
end

-- 小账本小程序直连:仅需换小账本专属 sid(不需要账号列表/aid/店铺)。
-- 返回 { sid=... }, err
function plugin._wxapp_probe_smallbook(options)
    local wxid = getWxid(options)
    if isBlank(wxid) then return nil, "缺少wxid" end

    local app = WXAPP_EXP.SMALLBOOK
    local sid, resolveErr = plugin._wxapp_resolve_sid(options, app)
    if not sid then
        return nil, resolveErr
    end
    return { sid = sid }, ""
end

-- 小账本小程序直连出码(实验):复用缓存 smallbook_sid,缺失时经 JSLogin 换小账本 code→登录→sid,
-- 再直连 smallbook.../qrappsl/profile/getpayqrcode 出码,绕开云端 TenPay -17。
-- 返回 types.PaymentResult 兼容结构
function plugin._wxapp_create_smallbook(orderInfo, options)
    local sid = tostring(options.smallbook_sid or "")
    if isBlank(sid) then
        local fresh, acctErr = plugin._wxapp_probe_smallbook(options)
        if not fresh then
            return errorResponse(500, "获取小账本会话失败:" .. tostring(acctErr))
        end
        sid = tostring(fresh.sid or "")
        local accId = options.account_id or (options.accountInfo and options.accountInfo.id)
        if accId and not isBlank(sid) then
            helper.channel_account_set_option(accId, "smallbook_sid", sid)
        end
    end
    if isBlank(sid) then
        return errorResponse(500, "小账本会话sid为空,请查看 WXAPP 日志按返回适配")
    end

    local app = WXAPP_EXP.SMALLBOOK
    -- 与 yyb_xd 已验证一致:小账本 getpayqrcode 只需 sid + v,返回商户固定收款码(免挂模式)
    local qrUrl = "https://smallbook.wxpapp.weixin.qq.com/qrappsl/profile/getpayqrcode"
    qrUrl = qrUrl .. "?sid=" .. helper.url_encode(sid)
    qrUrl = qrUrl .. "&v=6.23.1"

    local qrResp = wxappDirectGet(qrUrl, app.referer)
    local qrData, qrErr = wxappDecode(qrResp)
    if not qrData then
        return errorResponse(500, "获取小账本二维码失败:" .. tostring(qrErr))
    end
    if qrData.errcode ~= nil and qrData.errcode ~= 0 then
        return errorResponse(500, "获取小账本二维码失败:" .. tostring(qrData.msg or qrData.errmsg or ""))
    end

    local qrcode = (qrData.data and qrData.data.qrcode_content)
        or (qrData.data and qrData.data.qrcode)
        or wxappSearchField(qrData, { "qrcode_content", "qrcode" })
    if not qrcode or qrcode == "" then
        return errorResponse(500, "未获取到小账本二维码:" .. safeJson(qrData))
    end

    local written, filePath = helper.save_image_cache_base64(qrcode)
    if not written then
        return errorResponse(500, "小账本二维码保存失败")
    end
    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode_file = filePath,
            qrcode = "",
            url = "",
            content = "",
            out_trade_no = tostring(orderInfo.order_id or "")
        }
    }
end

-- 基于已获取的 sid/aid/account_type 在小程序直连收款并出码(实验)
-- 返回 types.PaymentResult 兼容结构
function plugin._wxapp_create_receipt(orderInfo, options)
    -- 优先复用已缓存的账号信息,避免每次下单都重新走小程序登录拉账号
    local account = {
        sid = tostring(options.wxapp_sid or ""),
        aid = tostring(options.wxapp_aid or ""),
        account_type = tostring(options.wxapp_account_type or ""),
        account_name = tostring(options.wxapp_account_name or ""),
        shop_id = tostring(options.wxapp_shop_id or ""),
    }
    if isBlank(account.sid) or isBlank(account.aid) or isBlank(account.account_type) then
        -- 缓存账号不全,重新走小程序登录拉账号
        local fresh, acctErr = plugin._wxapp_probe_mini_entry(options)
        if not fresh then
            return errorResponse(500, "获取收款账号失败:" .. tostring(acctErr))
        end
        account = fresh
        -- 回写缓存,便于下次复用
        local accId = options.account_id or (options.accountInfo and options.accountInfo.id)
        if accId then
            if not isBlank(account.sid) then
                helper.channel_account_set_option(accId, "wxapp_sid", tostring(account.sid))
            end
            if not isBlank(account.aid) then
                helper.channel_account_set_option(accId, "wxapp_aid", tostring(account.aid))
            end
            if not isBlank(account.account_type) then
                helper.channel_account_set_option(accId, "wxapp_account_type", tostring(account.account_type))
            end
            if not isBlank(account.account_name) then
                helper.channel_account_set_option(accId, "wxapp_account_name", tostring(account.account_name))
            end
            if not isBlank(account.shop_id) then
                helper.channel_account_set_option(accId, "wxapp_shop_id", tostring(account.shop_id))
            end
        end
    end
    if isBlank(account.aid) or isBlank(account.account_type) then
        return errorResponse(500, "收款账号信息不全,请查看 WXAPP 日志按返回适配")
    end

    local gateway = wxappGatewayByAccountType(account.account_type)
    if not gateway then
        return errorResponse(500, "不支持的账号类型:" .. tostring(account.account_type))
    end

    -- 门店id 缺失时通过 account/get 拉取(微信创建收款单要求 shop_id 必填)
    local shop_id = account.shop_id
    if (not shop_id or shop_id == "") then
        local agUrl = gateway .. "/account/get?miniprogram_version=3.15.10"
        agUrl = agUrl .. "&account_id=" .. helper.url_encode(account.aid)
        agUrl = agUrl .. "&account_type=" .. tostring(account.account_type)
        agUrl = agUrl .. "&sid=" .. helper.url_encode(account.sid)
        local agResp = wxappDirectGet(agUrl, WXAPP_EXP.RECEIPT.referer)
        local agData = wxappDecode(agResp)
        if agData and agData.data and agData.data.auth_shop_list
            and type(agData.data.auth_shop_list) == "table"
            and #agData.data.auth_shop_list > 0 then
            shop_id = tostring(agData.data.auth_shop_list[1].shop_id or "")
        else
            shop_id = nil
        end
        account.shop_id = shop_id or ""
        if shop_id and shop_id ~= "" then
            local accId = options.account_id or (options.accountInfo and options.accountInfo.id)
            if accId then
                helper.channel_account_set_option(accId, "wxapp_shop_id", tostring(shop_id))
            end
        end
    end

    local fee = tostring(orderInfo.trade_amount or 0)
    local remark = tostring(orderInfo.remark or orderInfo.order_id or "")

    -- 创建收款单
    local createUrl = gateway .. "/receipt/create?miniprogram_version=3.15.9"
    createUrl = createUrl .. "&remark_pic_urls="
    createUrl = createUrl .. "&option_list=%5B%5D"
    createUrl = createUrl .. "&account_type=" .. tostring(account.account_type)
    if shop_id and shop_id ~= "" then
        createUrl = createUrl .. "&shop_id=" .. tostring(shop_id)
    end
    createUrl = createUrl .. "&remark=" .. helper.url_encode(remark)
    createUrl = createUrl .. "&account_id=" .. helper.url_encode(account.aid)
    createUrl = createUrl .. "&sid=" .. helper.url_encode(account.sid)
    createUrl = createUrl .. "&fee=" .. fee

    local createResp = wxappDirectGet(createUrl, WXAPP_EXP.RECEIPT.referer)
    local createData, createErr = wxappDecode(createResp)
    if not createData then
        return errorResponse(500, "创建收款单失败:" .. tostring(createErr))
    end
    if createData.errcode ~= nil and createData.errcode ~= 0 then
        return errorResponse(500, "创建收款单失败:" .. tostring(createData.msg or createData.errmsg or ""))
    end

    local receiptId
    if createData.data and createData.data.receipt then
        receiptId = createData.data.receipt.receipt_id
    end
    receiptId = receiptId or wxappSearchField(createData, { "receipt_id", "receiptId" })
    if not receiptId or receiptId == "" then
        return errorResponse(500, "未获取到 receipt_id:" .. safeJson(createData))
    end

    -- 出码
    local qrUrl = gateway .. "/receipt/getwxacode?miniprogram_version=3.15.10"
    qrUrl = qrUrl .. "&wxacode_path_type=1"
    qrUrl = qrUrl .. "&receipt_id=" .. helper.url_encode(receiptId)
    qrUrl = qrUrl .. "&account_id=" .. helper.url_encode(account.aid)
    qrUrl = qrUrl .. "&account_type=" .. tostring(account.account_type)
    qrUrl = qrUrl .. "&sid=" .. helper.url_encode(account.sid)

    local qrResp = wxappDirectGet(qrUrl, WXAPP_EXP.RECEIPT.referer)
    local qrData, qrErr = wxappDecode(qrResp)
    if not qrData then
        return errorResponse(500, "获取收款单二维码失败:" .. tostring(qrErr))
    end
    if qrData.errcode ~= nil and qrData.errcode ~= 0 then
        return errorResponse(500, "获取收款单二维码失败:" .. tostring(qrData.msg or qrData.errmsg or ""))
    end

    local qrcode = (qrData.data and qrData.data.qrcode) or wxappSearchField(qrData, { "qrcode" })
    if not qrcode or qrcode == "" then
        return errorResponse(500, "未获取到二维码:" .. safeJson(qrData))
    end

    local written, filePath = helper.save_image_cache_base64(qrcode)
    if not written then
        return errorResponse(500, "二维码保存失败")
    end
    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode_file = filePath,
            qrcode = "",
            url = "",
            content = "",
            out_trade_no = tostring(orderInfo.order_id or "")
        }
    }
end

-- 个人上传收款码模式：直接返回账号配置的收款码，不调用云端生成
---@param orderInfo table
---@param options table
---@return table
function plugin._create_self_pay_qrcode(orderInfo, options)
    local qrcodeType = tostring(options.type or "url")
    if qrcodeType == "image" then
        local qrcodeFile = tostring(options.qrcode_file or "")
        if isBlank(qrcodeFile) then
            return errorResponse(500, "未配置收款码图片")
        end
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = qrcodeFile,
                qrcode = "",
                url = "",
                content = "",
                out_trade_no = tostring(orderInfo.order_id or "")
            }
        }
    end

    local qrcode = tostring(options.qrcode or "")
    if isBlank(qrcode) then
        return errorResponse(500, "未配置收款码地址")
    end
    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = " " .. qrcode .. " ",
            url = "",
            content = "",
            out_trade_no = tostring(orderInfo.order_id or "")
        }
    }
end

local function handleCronLoginFailure(accountInfo, accountOptions, message)
    local failCount = tonumber(accountOptions.cron_login_fail_count or 0) + 1
    helper.channel_account_set_option(accountInfo.id, "cron_login_fail_count", tostring(failCount))

    if failCount < 3 then
        return {
            code = 200,
            message = "登录状态检查失败，等待重试",
            data = {}
        }
    end

    helper.channel_account_offline(accountInfo.id)
    return {
        code = 500,
        message = message,
        data = {}
    }
end

-- 定时任务
---@param ctx types.CronAccountParams
---@return table
function plugin.cron(ctx)
    local accountInfo = toTable(ctx.account_info)
    local accountOptions = mergeOptions(ctx)

    if accountInfo.online ~= 1 then
        local lastSeen = tonumber(accountOptions.last_seen_online or -1) or -1
        if lastSeen ~= 0 then
            helper.channel_account_set_option(accountInfo.id, "last_seen_online", "0")
            accountOptions.last_seen_online = "0"
        end
        return {
            code = 200,
            message = "账号已离线，跳过定时检查",
            data = {}
        }
    end

    local wxid = getWxid(accountOptions)
    if isBlank(wxid) then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end
        return {
            code = 500,
            message = "未登录",
            data = {}
        }
    end

    if getGatewayBase(accountOptions) == "" then
        return {
            code = 500,
            message = "暂未配置支付网关",
            data = {}
        }
    end

    local now = os.time()
    local lastBeatAt = tonumber(accountOptions.last_heartbeat_at or 0) or 0
    local heartbeatData, heartbeatErr
    local beatDue = now - lastBeatAt >= 30
    if beatDue then
        heartbeatData, heartbeatErr = mRequest("POST", "/Login/HeartBeat", accountOptions, nil,
            string.format("wxid=%s", helper.url_encode(wxid)))
        if heartbeatData then
            helper.channel_account_set_option(accountInfo.id, "last_heartbeat_at", tostring(now))
            accountOptions.last_heartbeat_at = tostring(now)
        end
    end

    -- 只有「本次确实发送了心跳且网关无返回数据」才算失败；
    -- 注意 mRequest 成功时返回的 err 为空串而非 nil，不能用 heartbeatErr~=nil 判断失败。
    if beatDue and heartbeatData == nil then
        local hitInvalid = plugin._is_wxid_invalid_response(heartbeatErr)
        local failCount = tonumber(accountOptions.cron_login_fail_count or 0) + 1
        logToFile("BEAT", string.format("心跳失败 累计第%d次 hitInvalid=%s online=%s err=%s",
            failCount, tostring(hitInvalid), tostring(accountInfo.online), tostring(heartbeatErr)))
        if hitInvalid then
            logToFile("CRON", "心跳响应命中登录失效(登录态/未登录/session),立即置离线")
            helper.channel_account_offline(accountInfo.id)
        end
        return handleCronLoginFailure(accountInfo, accountOptions,
            string.format("心跳保活失败: %s", heartbeatErr or "请求失败"))
    end

    if heartbeatData ~= nil then
        if tonumber(accountOptions.cron_login_fail_count or 0) > 0 then
            helper.channel_account_set_option(accountInfo.id, "cron_login_fail_count", "0")
            accountOptions.cron_login_fail_count = "0"
        end

        if accountInfo.online ~= 1 then
            helper.channel_account_online(accountInfo.id)
            accountInfo.online = 1
        end

        if tonumber(accountOptions.last_seen_online or -1) ~= 1 then
            helper.channel_account_set_option(accountInfo.id, "last_seen_online", "1")
            accountOptions.last_seen_online = "1"
        end
    end

    if isSpecialPayMode(accountOptions) then
        -- 实验:小程序直连收款,定时节流探测第一跳,便于观察是否能拉取账号
        local probed = pcall(plugin._maybe_wxapp_probe, accountInfo, accountOptions)
        if not probed then
            logToFile("WXAPP", "cron 小程序探测调用异常,忽略继续心跳")
        end

        local ok, verifyError = plugin._verify_special_account(accountInfo, accountOptions)
        if not ok then
            return {
                code = 200,
                message = "car在线，特殊收款初始化失败: " .. verifyError,
                data = {}
            }
        end
        return {
            code = 200,
            message = "在线，支付结果依赖car消息上报",
            data = {}
        }
    end

    return {
        code = 200,
        message = "在线，消息由网关内部处理",
        data = {}
    }
end

-- 拉取 /Msg/Sync 新消息并交给 parseMsg 解析上报收款(高频任务专用,与保活心跳解耦)
function plugin._syncPayMsgs(accountInfo, accountOptions)
    local wxid = getWxid(accountOptions)
    if isBlank(wxid) then
        return
    end

    local syncData, syncErr = mRequest("POST", "/Msg/Sync", accountOptions, {
        Scene = 0,
        Synckey = "",
        Wxid = wxid
    })
    if syncData then
        local dataInfo = toTable(syncData.Data) or toTable(syncData.data)
        local messages = toTable(dataInfo.AddMsgs) or toTable(dataInfo.addMsgs) or {}
        local processedIds = {}
        for _, message in ipairs(messages) do
            local messageInfo = toTable(message)
            local ok, handled = pcall(plugin.parseMsg, accountInfo.id, accountInfo.uid, messageInfo)
            if ok and handled and messageInfo.id ~= nil then
                table.insert(processedIds, messageInfo.id)
            elseif not ok then
                log.error("解析car消息失败", handled)
            end
        end
        if #processedIds > 0 then
            log.debug("car消息处理完成", json.encode(processedIds))
        end
    elseif syncErr ~= nil then
        logToFile("SYNC", "/Msg/Sync 拉取失败: " .. tostring(syncErr))
        log.error("拉取car消息失败", syncErr)
    end
end

-- 高频轮询任务:专门拉取收款消息,保障到账通知更及时
function plugin.pollReceipt(ctx)
    local accountInfo = toTable(ctx.account_info)
    local accountOptions = mergeOptions(ctx)

    if accountInfo.online ~= 1 then
        return {
            code = 200,
            message = "账号离线，跳过消息轮询",
            data = {}
        }
    end

    if isBlank(getWxid(accountOptions)) or getGatewayBase(accountOptions) == "" then
        return {
            code = 200,
            message = "未登录或未配置网关，跳过消息轮询",
            data = {}
        }
    end

    pcall(plugin._syncPayMsgs, accountInfo, accountOptions)
    return {
        code = 200,
        message = "消息轮询完成",
        data = {}
    }
end

---@param accountId any
---@param uid any
---@param msg table
function plugin.parseMsg(accountId, uid, msg)
    local contentInfo = toTable(msg.content)
    if next(contentInfo) == nil then
        contentInfo = toTable(msg.Content)
    end
    local rawContent = contentInfo.string or contentInfo.str or contentInfo
    local msgData = type(rawContent) == "string" and rawContent or ""
    if msgData == "" then
        return true
    end

    local appMsg = msgData:match("<appmsg([%W%w]+)</appmsg>") or ""
    local description = appMsg:match("<des>%s*<!%[CDATA%[([%W%w]-)%]%]>%s*</des>") or ""
    local remark = description:match("收款说明%s*[:：]?%s*(%d+)") or
        description:match("收款方备注%s*[:：]?%s*(%d+)")
    local title = msgData:match("<appname><!%[CDATA%[(.*)%]%]><%/appname>")
    local content = msgData:match("<title><!%[CDATA%[(.*)%]%]><%/title>%s+<des")

    if isBlank(title) or isBlank(content) then
        return true
    end

    local rules = { {
        TitleReg = "微信收款助手|微信支付",
        ContentReg = "^(?:\\[\\d+条\\]微信收款助手: )?微信支付收款(?<amount>[\\d\\.]+)元( )?(?!.*消费)[\\s\\S]*"
    }, {
        TitleReg = "微信支付",
        ContentReg = "个人收款码到账¥(?<amount>[\\d\\.]+)"
    }, {
        TitleReg = "微信收款助手",
        ContentReg = "\\[店员消息\\]收款到账(?<amount>[\\d\\.]+)元"
    }, {
        TitleReg = "微信支付",
        ContentReg = "二维码赞赏到账(?<amount>[\\d\\.]+)元"
    }, {
        TitleReg = "微信收款商业版",
        ContentReg = "收款(?:¥|￥|)(?<amount>[\\d.]+)"
    }, {
        TitleReg = "收款通知",
        ContentReg = "微信收款商业版: 收款(?<amount>[\\d\\.]+)元"
    }, {
        TitleReg = "微信收款助手",
        ContentReg = "收款单到账(?<amount>[\\d\\.]+)元"
    }, {
        TitleReg = "微信收款助手|微信支付",
        ContentReg = "^(?:\\[\\d+条\\]微信收款助手: )?微信支付收款(?<amount>[\\d\\.]+)元( )?(?!.*朋友|到店)(\\((老顾客第\\d+次|新顾客)?消费\\))"
    }, {
        TitleReg = "对外收款",
        ContentReg = "^(?:\\[\\d+条\\])?收款通知：[\\s\\S]*?已收款(?<amount>[\\d\\.]+)元"
    } }

    for _, rule in ipairs(rules) do
        local titleMatched = helper.regexp_match(title, rule.TitleReg)
        if titleMatched then
            local matched, matchGroups = helper.regexp_match_group(content, rule.ContentReg)
            local groups = matchGroups or {}
            if matched and groups.amount and #groups.amount > 0 then
                local amount = tonumber(groups.amount[1])
                if amount then
                    local amountInCents = math.floor((amount + 0.000005) * 100)
                    local payTime = tostring(msg.CreateTime or msg.create_time or msg.Time or "")
                    local reported = orderHelper.report({
                        id = accountId,
                        uid = uid
                    }, {
                        amount = amountInCents,
                        pay_type = "wxpay",
                        channel_code = PAY_CHANNEL_CODE_YUN_WECHAT_CAR_HG,
                        pay_time = payTime,
                        out_order_id = remark
                    })
                    if reported == false then
                        return false
                    end
                    return true
                end
            end
        end
    end
    return true
end

-- 二维码登录
---@param ctx table
---@return table
function plugin.login_qrcode(ctx)
    local accountInfo = toTable(ctx.account_info)
    local accountOption = toTable(accountInfo.options)
    accountOption.account_id = accountInfo.id

    local deviceId = tostring(accountOption.device_id or "")
    local data, mErr = mRequest("POST", "/Login/LoginGetQRCar", accountOption, {
        DeviceID = deviceId,
        DeviceName = DEFAULT_DEVICE_NAME,
        LoginType = "",
        Proxy = getProxyInfo(accountOption)
    })
    if not data then
        logToFile("ERROR", "LoginGetQRCar 请求失败: " .. tostring(mErr))
        return {
            code = 500,
            message = string.format("请求获取登录二维码错误: %s", mErr or "请求失败"),
            data = {}
        }
    end

    local respDeviceId = data.DeviceId or data.deviceId or data.DeviceID or ""
    if not isBlank(respDeviceId) then
        helper.channel_account_set_option(accountInfo.id, "device_id", tostring(respDeviceId))
    end

    log.error("【login_qrcode】获取登录二维码成功", json.encode(data))
    local payload = data.Data or data.data or data.Result or data.result or {}
    local qrcode = tostring(payload.qrcode or payload.QrCode or payload.qrCode or payload.Qrcode or
        payload.QrUrl or payload.qrUrl or payload.QRUrl or payload.QrImage or
        payload.url or payload.QrBase64 or payload.qrBase64 or payload.qrcode_base64 or "")
    local uuid = tostring(payload.ticket_id or payload.TicketId or payload.ticketId or
        payload.uuid or payload.Uuid or payload.ticket or payload.Ticket or
        payload.token or payload.Token or "")

    local qrData = tostring(payload.qrData or payload.QrData or payload.qrcode_data or payload.QRData or "")
    if isBlank(qrData) then
        qrData = tostring(payload.data or payload.Data or "")
    end

    if isBlank(qrcode) and not isBlank(qrData) then
        qrcode = qrData
    end

    if qrcode:find("create-qr-code", 1, true) then
        local _, _, dataParam = qrcode:find("data=([^&]+)")
        if dataParam then
            qrcode = urlDecode(dataParam)
            log.error("【login_qrcode】从二维码服务地址中提取到登录链接: %s", tostring(qrcode))
        end
    end

    if isBlank(qrcode) then
        log.error("未获取到登录二维码，原始响应", json.encode(data))
        return {
            code = 500,
            message = string.format("未获取到登录二维码，响应: %s", json.encode(data)),
            data = {}
        }
    end

    if qrcode:match("^/api/qrcode%?text=") then
        local _, _, encoded = qrcode:find("text=(.+)$")
        if encoded then
            local decoded = urlDecode(encoded)
            log.error("【login_qrcode】识别到 /api/qrcode 二维码，解码后 text 前缀: %s，长度: %d",
                tostring(decoded:sub(1, 24)), #decoded)
            if decoded:find("^data:") then
                local written, filePath = helper.save_image_cache_base64(decoded)
                log.error("【login_qrcode】save_image_cache_base64 → written=%s filePath=%s",
                    tostring(written), tostring(filePath))
                if not written then
                    return {
                        code = 500,
                        message = "登录二维码图片保存失败",
                        data = {}
                    }
                end
                if not isBlank(uuid) then
                    helper.channel_account_set_option(accountInfo.id, "uuid", uuid)
                end
                return {
                    code = 200,
                    message = "success",
                    data = {
                        qrcode = filePath,
                        options = json.encode({
                            uuid = uuid
                        })
                    }
                }
            end
        end
    end

    if qrcode:sub(1, 1) == "/" then
        local serverAddress = getGatewayAddress(accountOption)
        if serverAddress ~= "" then
            qrcode = serverAddress .. qrcode
            log.debug("二维码图片地址", qrcode)
        end
    end

    if not isBlank(uuid) then
        helper.channel_account_set_option(accountInfo.id, "uuid", uuid)
    end

    log.error("【login_qrcode】最终返回 qrcode 前缀: %s，完整值: %s",
        tostring(qrcode:sub(1, 60)), tostring(qrcode))

    return {
        code = 200,
        message = "success",
        data = {
            qrcode = qrcode,
            options = json.encode({
                uuid = uuid
            })
        }
    }
end

-- 检查二维码登录状态
---@param ctx table
---@return table
function plugin.login_qrcode_check(ctx)
    local params = toTable(ctx.params)
    local accountInfo = toTable(ctx.account_info)
    local accountOption = toTable(accountInfo.options)
    accountOption.account_id = accountInfo.id

    local uuid = params.uuid or accountOption.uuid
    if isBlank(uuid) then
        log.error("登录轮询uuid为空，无法检测登录状态")
        return {
            code = 201,
            message = "等待扫码",
            data = {}
        }
    end

    local data, mErr = mRequest("POST", "/Login/LoginCheckQR", accountOption, nil,
        string.format("uuid=%s", helper.url_encode(uuid)))
    if not data then
        if mErr and (mErr:find("等待") or mErr:find("扫码") or mErr:find("scan") or mErr:find("wait")
            or mErr:find("未扫") or mErr:find("确认")) then
            log.debug("等待扫码，uuid=%s，网关返回: %s", uuid, mErr or "")
            return {
                code = 201,
                message = "等待扫码",
                data = {}
            }
        end
        if plugin._is_wxid_invalid_response(mErr) then
            helper.channel_account_offline(accountInfo.id)
        end
        return {
            code = 500,
            message = string.format("请求错误: %s", mErr or "请求失败"),
            data = {}
        }
    end

    log.debug("检查二维码登录状态，uuid=%s，响应=%s", uuid, json.encode(data))
    local resultData = data.Data or data.data or {}
    local acctSectResp = toTable(resultData.acctSectResp)
    local wxid = resultData.wxid or resultData.Wxid or
        acctSectResp.userName or acctSectResp.wxid or acctSectResp.Wxid or
        extractStringField(data.Wxid) or extractStringField(data.wxid) or
        getWxid(accountOption)
    local state = tonumber(resultData.state or resultData.State)
    if (state ~= nil and state ~= 2) or (state == nil and isBlank(wxid)) then
        return {
            code = 201,
            message = "等待扫码",
            data = {}
        }
    end

    if isBlank(wxid) then
        return {
            code = 500,
            message = "登录成功但未获取到wxid",
            data = {}
        }
    end

    helper.channel_account_set_option(accountInfo.id, "wxid", wxid)
    helper.channel_account_set_option(accountInfo.id, "cron_login_fail_count", "0")
    accountOption.wxid = wxid
    accountOption.cron_login_fail_count = "0"

    local successMessage = string.format("登录成功 %s",
        tostring(resultData.nick_name or resultData.NickName or acctSectResp.nickName or wxid))

    local initData, initErr = mRequest("POST", "/Login/LoginTwiceAutoAuth", accountOption, nil,
        string.format("wxid=%s", helper.url_encode(wxid)))
    if initData then
        local newinitData, newinitErr = mRequest("POST", "/Login/Newinit", accountOption, nil,
            string.format("wxid=%s", helper.url_encode(wxid)))
        if newinitData then
            successMessage = successMessage .. "，已初始化"
        else
            log.error("初始化Newinit失败", newinitErr or "unknown")
            successMessage = successMessage .. "，初始化失败: " .. (newinitErr or "unknown")
        end
    else
        log.error("二次登录失败", initErr or "unknown")
        successMessage = successMessage .. "，二次登录失败: " .. (initErr or "unknown")
    end

    helper.channel_account_online(accountInfo.id)

    return {
        code = 200,
        message = successMessage,
        data = {
            can_bind_token = false
        }
    }
end

-- 通道新增或修改
---@param ctx table
---@return table
function plugin.onAccountChanged(ctx)
    local accountInfo = toTable(ctx.account_info or ctx)
    local options = mergeOptions(ctx.account_info and ctx or { account_info = accountInfo })
    if not isSpecialPayMode(options) then
        return {
            code = 200,
            message = "账号保存成功",
            data = {}
        }
    end

    if isBlank(getWxid(options)) then
        return {
            code = 200,
            message = "账号保存成功，请扫码登录car微信账号",
            data = {}
        }
    end
    local initialized, initError = plugin._verify_special_account(accountInfo, options)
    return {
        code = 200,
        message = initialized and "账号保存成功，特殊收款已初始化" or
            ("账号保存成功，特殊收款待初始化: " .. initError),
        data = {}
    }
end

return plugin
