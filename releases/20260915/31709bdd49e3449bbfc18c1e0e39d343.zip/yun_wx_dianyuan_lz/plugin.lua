---@diagnostic disable: undefined-global
package.path = package.path .. ";" .. luaCommonPath .. "/?.lua"
require("autoload")

local PLUGIN = "yun_wx_dianyuan_lz"
local YUN_WECHAT_DIANYUAN_LZ = PLUGIN
local CLOUD_GATEWAY = "https://yund.973700.xyz"
local plugin = {}

local function toTable(v)
    if type(v) == "table" then
        return v
    end
    if type(v) == "string" and v ~= "" then
        local ok, data = pcall(json.decode, v)
        if ok and type(data) == "table" then
            return data
        end
    end
    return {}
end

local function firstNonBlank(...)
    for i = 1, select("#", ...) do
        local value = select(i, ...)
        if value ~= nil and tostring(value) ~= "" then
            return tostring(value)
        end
    end
    return ""
end

local function truthy(value)
    local text = tostring(value or ""):lower()
    return value == true or text == "1" or text == "true" or text == "yes" or text == "on"
end

local function urlEncode(value)
    local text = tostring(value or "")
    if helper and type(helper.url_encode) == "function" then
        return helper.url_encode(text)
    end
    return funcs.encode_url(text)
end

local function buildQuery(params)
    local parts = {}
    for key, value in pairs(params or {}) do
        if value ~= nil and tostring(value) ~= "" then
            table.insert(parts, urlEncode(key) .. "=" .. urlEncode(value))
        end
    end
    return table.concat(parts, "&")
end

local function encodeProxyCredentials(proxy)
    proxy = tostring(proxy or "")
    local prefix, userInfo, address = proxy:match("^([%w+.-]+://)([^@]+)@(.+)$")
    if not prefix then return proxy end
    local username, password = userInfo:match("^([^:]*):(.*)$")
    if not username then return proxy end
    return prefix .. urlEncode(username) .. ":" .. urlEncode(password) .. "@" .. address
end

local function getProxy(accountOptions)
    accountOptions = accountOptions or {}
    local mode = accountOptions.proxy_mode or "no_proxy"
    if mode == "custom_proxy" then return encodeProxyCredentials(accountOptions.proxy or "") end
    if mode ~= "cloud_proxy" then return "" end

    local poolId = tonumber(accountOptions.proxy_pool_id or 0) or 0
    if poolId <= 0 then return "" end
    local itemId = tonumber(accountOptions.proxy_pool_item_id or 0) or 0
    local proxyItem = helper.proxy_pool_fetch(poolId, itemId)
    if proxyItem and proxyItem.proxy_url and proxyItem.proxy_url ~= "" then
        local proxyId = tonumber(proxyItem.proxy_id or 0) or 0
        if proxyId ~= itemId then
            accountOptions.proxy_pool_item_id = proxyId
            if accountOptions.account_id then
                helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", proxyId)
            end
        end
        return encodeProxyCredentials(proxyItem.proxy_url)
    end
    if itemId > 0 then helper.proxy_pool_release(itemId) end
    accountOptions.proxy_pool_item_id = 0
    if accountOptions.account_id then
        helper.channel_account_set_option(accountOptions.account_id, "proxy_pool_item_id", "0")
    end
    return ""
end

local function mergeOptions(ctx)
    ctx = ctx or {}
    local accountInfo = ctx.account_info or {}
    local options = { account_id = accountInfo.id }
    for k, v in pairs(toTable(accountInfo.options)) do
        options[k] = v
    end
    for k, v in pairs(toTable(ctx.plugin_option)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.plugin_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    for k, v in pairs(toTable(ctx.account_options)) do
        if v ~= nil and v ~= "" then options[k] = v end
    end
    return options
end

local function amountToFen(value)
    local text = tostring(value or ""):gsub("￥", ""):gsub("¥", ""):gsub(",", "")
    if text == "" then return 0 end
    if helper and type(helper.amount_str2int) == "function" then
        local ok, amount = pcall(helper.amount_str2int, text)
        if ok and tonumber(amount) and tonumber(amount) > 0 then
            return tonumber(amount)
        end
    end
    local number = tonumber(text)
    if not number or number <= 0 then return 0 end
    return math.floor(number * 100 + 0.5)
end

local function timeToTimestamp(value)
    local text = tostring(value or "")
    if text == "" then return os.time() end
    local number = tonumber(text)
    if number and number > 0 then
        if number > 10000000000 then
            return math.floor(number / 1000)
        end
        return math.floor(number)
    end
    if helper and type(helper.datetime_to_timestamp) == "function" then
        local ok, timestamp = pcall(helper.datetime_to_timestamp, text)
        if ok and tonumber(timestamp) and tonumber(timestamp) > 0 then
            return tonumber(timestamp)
        end
    end
    return os.time()
end

function plugin.pluginInfo()
    return {
        channels = {
            ["wxpay"] = { {
                label = "新微信店员云端-靓仔",
                value = YUN_WECHAT_DIANYUAN_LZ,
                options = {
                    need_check_online = 1,
                    use_qrcode_login = 1,
                    use_add_amount = 1
                }
            } }
        },
        options = {
            detection_interval = 5,
            detection_type = "cron"
        }
    }
end

function plugin.formItems(ctx)
    return {
        inputs = {
            {
                name = "login_protocol",
                label = "登录协议",
                type = types.InputTypes.RADIO,
                default = "yyb",
                options = { tip = "切换协议后需要重新扫码登录" },
                placeholder = "请选择登录协议",
                values = {
                    { label = "应用宝", value = "yyb" },
                    { label = "手游助手", value = "app" },
                    { label = "电脑管家", value = "pc_tool" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择登录协议" } }
            },
            {
                name = "type",
                label = "收款码类型",
                type = types.InputTypes.SELECT,
                default = "qrcode",
                placeholder = "请选择收款码类型",
                values = {
                    { label = "二维码", value = "qrcode" },
                    { label = "图片", value = "image" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择收款码类型" } }
            },
            {
                name = "qrcode",
                label = "收款码地址",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.type == 'qrcode'",
                options = {
                    tip = "上传二维码时会解析并保存二维码内容",
                    append_deqrocde = 1
                },
                placeholder = "请输入或上传解析后的收款码地址",
                rules = { { required = true, trigger = { "input", "blur" }, message = "请输入收款码地址" } }
            },
            {
                name = "qrcode_file",
                label = "收款码图片",
                type = types.InputTypes.IMAGE,
                default = "",
                when = "this.formModel.options.type == 'image'",
                options = { tip = "图片模式不解析二维码，直接展示原图" },
                placeholder = "请上传收款码图片",
                rules = { { required = true, trigger = { "input", "blur" }, message = "请上传收款码图片" } }
            },
            {
                name = "clerk_jscode",
                label = "店员jscode",
                type = types.InputTypes.INPUT,
                default = "",
                options = { tip = "通常留空；云端无法自动授权店员助手时，可临时填写小程序 wx.login 的 jscode" },
                placeholder = "可选，成功换取SID后可清空"
            },
            {
                name = "clerk_sid",
                label = "店员SID",
                type = types.InputTypes.INPUT,
                default = "",
                hidden = 1
            },
            {
                name = "shop_list",
                label = "店员店铺列表",
                type = types.InputTypes.TEXTAREA,
                default = "",
                hidden_list = 1,
                placeholder = "扫码登录后自动获取",
                options = { tip = "清空后保存或等待定时任务会重新获取；需要切换店铺时复制商户号和门店ID到下方" }
            },
            {
                name = "mch_id",
                label = "商户号",
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "扫码后自动选择第一个店员店铺",
                options = { tip = "来自店员助手店铺列表的 mch_id" }
            },
            {
                name = "shop_id",
                label = "门店ID",
                type = types.InputTypes.INPUT,
                default = "",
                placeholder = "扫码后自动选择第一个店员店铺",
                options = { tip = "来自店员助手店铺列表的 shop_id" }
            },
            {
                name = "scan_type",
                label = "订单检查方式",
                type = types.InputTypes.RADIO,
                default = "order_or_amount",
                placeholder = "请选择订单检查方式",
                values = {
                    { label = "订单号匹配不到则使用金额", value = "order_or_amount" },
                    { label = "订单号", value = "order" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择订单检查方式" } }
            },
            {
                name = "order_temp_amount",
                label = "取消订单递增金额",
                type = types.InputTypes.RADIO,
                default = "0",
                options = { tip = "<b>注意:</b>订单检查方式为订单号的时候才能选择[是]" },
                placeholder = "请选择订单检查方式",
                values = {
                    { label = "否", value = "0" },
                    { label = "是", value = "1" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择订单检查方式" } }
            },
            {
                name = "bill_lookback_seconds",
                label = "账单回看秒数",
                type = types.InputTypes.INPUT,
                default = "600",
                options = { tip = "每次轮询只处理最近这段时间的店员助手账单，避免翻太多历史页" },
                placeholder = "默认600"
            },
            {
                name = "proxy_mode",
                label = "代理模式",
                type = types.InputTypes.SELECT,
                default = "no_proxy",
                options = { tip = "选择代理使用模式" },
                placeholder = "请选择代理模式",
                values = {
                    { label = "不使用代理", value = "no_proxy" },
                    { label = "使用自定义代理", value = "custom_proxy" },
                    { label = "使用本站代理池", value = "cloud_proxy" }
                },
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择代理模式" } }
            },
            {
                name = "proxy",
                label = "Socks5代理地址",
                type = types.InputTypes.INPUT,
                default = "",
                when = "this.formModel.options.proxy_mode == 'custom_proxy'",
                options = { tip = "格式：socks5://IP:端口，或 socks5://用户名:密码@IP:端口" },
                placeholder = "例如：socks5://127.0.0.1:1080"
            },
            {
                name = "proxy_pool_id",
                label = "绑定代理池",
                type = types.InputTypes.CHOSE_PROXY_POOL,
                default = "-1",
                when = "this.formModel.options.proxy_mode == 'cloud_proxy'",
                options = { tip = "请选择绑定的代理池" },
                placeholder = "请选择代理池",
                rules = { { required = true, trigger = { "input", "blur" }, message = "请选择代理池" } }
            },
            {
                name = "proxy_pool_item_id",
                label = "绑定代理",
                type = types.InputTypes.INPUT,
                default = "0",
                hidden = 1
            },
            {
                name = "bind_token",
                label = "绑定的用户信息",
                type = types.InputTypes.INPUT,
                hidden = 1
            },
            {
                name = "uid",
                label = "云端UID",
                type = types.InputTypes.INPUT,
                hidden = 1
            },
            {
                name = "bound_login_protocol",
                label = "当前登录协议",
                type = types.InputTypes.INPUT,
                hidden = 1
            }
        }
    }
end

plugin._error_response = function(err_code, err_message)
    return {
        code = err_code,
        message = err_message,
        data = {}
    }
end

plugin._cloud_token = function()
    return "jiaowoliangzai"
end

plugin._get_cloud_gateway = function(options)
    return CLOUD_GATEWAY, nil
end

plugin._request_wechat_gateway = function(method, serverAddress, path, params, timeout)
    local apiUri = string.format("%s%s", serverAddress, path)
    local response, error_message = http.request(method or "POST", apiUri, {
        query = buildQuery(params or {}),
        timeout = timeout or "30s"
    })
    if error_message ~= nil then
        return nil, string.format("请求错误: %s", error_message)
    end
    if not response or not response.body or response.body == "" then
        return nil, "请求响应为空"
    end
    local data = json.decode(response.body)
    if not data then
        return nil, string.format("请求响应解析失败,响应内容: %s", response.body)
    end

    if response.status_code and tonumber(response.status_code) and tonumber(response.status_code) ~= 200 then
        if tostring(data.code or "") == "0" then
            return data, nil
        end
        return nil, string.format("请求失败,状态码:%s,响应:%s", tostring(response.status_code), response.body)
    end

    return data, nil
end

plugin._get_bound_uid = function(options)
    if not options then return nil end
    if options.bind_token and options.bind_token ~= "" then
        local bindInfo = json.decode(options.bind_token)
        if bindInfo and bindInfo.uid and bindInfo.uid ~= "" then
            return bindInfo.uid
        end
    end
    if options.uid and options.uid ~= "" then
        return options.uid
    end
    return nil
end

plugin._get_protocol_prefix = function(options)
    local protocol = options and options.login_protocol or "yyb"
    if protocol == "app" then
        return "/WeChat_APP"
    end
    if protocol == "pc_tool" then
        return "/WeChat_Pc_Tool"
    end
    return "/WeChat_YYB"
end

plugin._clerk_query = function(options, extra)
    local query = {
        uid = plugin._get_bound_uid(options),
        token = plugin._cloud_token()
    }
    for k, v in pairs(extra or {}) do
        query[k] = v
    end
    return query
end

plugin._check_gateway_login_status = function(accountInfo, options)
    local uid = plugin._get_bound_uid(options)
    if not uid then
        return false, "请先扫码登录微信网关"
    end

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return false, gatewayErr
    end

    local data, requestErr = plugin._request_wechat_gateway(
        "POST",
        serverAddress,
        plugin._get_protocol_prefix(options) .. "/IsLoginStatus",
        plugin._clerk_query(options),
        "30s"
    )
    if requestErr then
        return false, requestErr
    end
    if data.code ~= "1" and data.code ~= 200 then
        return false, data.msg or "微信网关登录状态异常"
    end
    return true, ""
end

plugin._sync_clerk_assistant_sid = function(accountInfo, options)
    local uid = plugin._get_bound_uid(options)
    if not uid then
        return false, "请先扫码登录微信网关"
    end

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return false, gatewayErr
    end

    local query = plugin._clerk_query(options)
    if options.clerk_jscode and options.clerk_jscode ~= "" then
        query.jscode = options.clerk_jscode
    end

    local data, requestErr = plugin._request_wechat_gateway(
        "POST",
        serverAddress,
        plugin._get_protocol_prefix(options) .. "/GetClerkAssistantSid",
        query,
        "60s"
    )
    if requestErr then
        return false, requestErr
    end
    if data.code ~= "1" and data.code ~= 200 then
        return false, data.msg or "获取店员助手SID失败"
    end

    local payload = data.data or data
    local sid = firstNonBlank(payload.sid, payload.Sid, payload.clerk_sid, payload.clerkSid)
    if sid == "" then
        return false, "云端未返回店员助手SID"
    end

    helper.channel_account_set_option(accountInfo.id, "clerk_sid", sid)
    helper.channel_account_set_option(accountInfo.id, "clerk_jscode", "")
    options.clerk_sid = sid
    options.clerk_jscode = ""
    return true, ""
end

plugin._format_shop_line = function(shop)
    return string.format(
        "商户号:%s|门店ID:%s|门店名称:%s|店员:%s",
        firstNonBlank(shop.mch_id, shop.mchId),
        firstNonBlank(shop.shop_id, shop.shopId),
        firstNonBlank(shop.shop_name, shop.shopName),
        truthy(shop.is_assistant) and "是" or "否"
    )
end

plugin._sync_clerk_shops = function(accountInfo, options)
    local uid = plugin._get_bound_uid(options)
    if not uid then
        return false, "请先扫码登录微信网关"
    end

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return false, gatewayErr
    end

    local data, requestErr = plugin._request_wechat_gateway(
        "POST",
        serverAddress,
        plugin._get_protocol_prefix(options) .. "/GetClerkAssistantShops",
        plugin._clerk_query(options),
        "60s"
    )
    if requestErr then
        return false, requestErr
    end
    if data.code ~= "1" and data.code ~= 200 then
        return false, data.msg or "获取店员助手店铺列表失败"
    end

    local payload = data.data or data
    local shops = payload.shops or payload.shop_list or {}
    if type(shops) ~= "table" or #shops == 0 then
        return false, "店员助手店铺列表为空"
    end

    local lines = {}
    local selected = nil
    for _, shop in ipairs(shops) do
        table.insert(lines, plugin._format_shop_line(shop))
        if not selected or (not truthy(selected.is_assistant) and truthy(shop.is_assistant)) then
            selected = shop
        end
    end

    helper.channel_account_set_option(accountInfo.id, "shop_list", table.concat(lines, "\n"))
    options.shop_list = table.concat(lines, "\n")

    if (not options.mch_id or options.mch_id == "") and selected then
        local mchId = firstNonBlank(selected.mch_id, selected.mchId)
        helper.channel_account_set_option(accountInfo.id, "mch_id", mchId)
        options.mch_id = mchId
    end
    if (not options.shop_id or options.shop_id == "") and selected then
        local shopId = firstNonBlank(selected.shop_id, selected.shopId)
        helper.channel_account_set_option(accountInfo.id, "shop_id", shopId)
        options.shop_id = shopId
    end

    return true, ""
end

plugin._verify_and_init_account = function(accountInfo, options)
    local _, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return false, gatewayErr
    end

    local loginOk, loginErr = plugin._check_gateway_login_status(accountInfo, options)
    if not loginOk then
        return false, loginErr
    end

    if not options.clerk_sid or options.clerk_sid == "" then
        local sidOk, sidErr = plugin._sync_clerk_assistant_sid(accountInfo, options)
        if not sidOk then
            return false, sidErr
        end
    end

    if not options.shop_list or options.shop_list == "" or not options.mch_id or options.mch_id == "" or
        not options.shop_id or options.shop_id == "" then
        local shopOk, shopErr = plugin._sync_clerk_shops(accountInfo, options)
        if not shopOk then
            return false, shopErr
        end
    end

    if not options.mch_id or options.mch_id == "" then
        return false, "缺少店员助手商户号"
    end
    if not options.shop_id or options.shop_id == "" then
        return false, "缺少店员助手门店ID"
    end

    return true, ""
end

function plugin.create(ctx)
    local vAccountInfo = ctx.account_info or {}
    local options = toTable(ctx.account_options)
    if next(options) == nil then
        options = toTable(vAccountInfo.options)
    end

    if options.type == "image" then
        if not options.qrcode_file or options.qrcode_file == "" then
            return plugin._error_response(500, "请上传收款码图片")
        end
        return {
            code = 200,
            message = "success",
            data = {
                type = types.PaymentResultTypes.QRCODE,
                qrcode_file = options.qrcode_file,
                qrcode = "",
                url = "",
                content = "",
                out_trade_no = ""
            }
        }
    end

    if not options.qrcode or options.qrcode == "" then
        return plugin._error_response(500, "请输入或上传解析收款码地址")
    end

    return {
        code = 200,
        message = "success",
        data = {
            type = types.PaymentResultTypes.QRCODE,
            qrcode = options.qrcode,
            url = "",
            content = "",
            out_trade_no = ""
        }
    }
end

function plugin.notify(ctx)
    return {
        code = 500,
        message = "暂不支持",
        data = {
            response = ""
        }
    }
end

function plugin.login_qrcode(ctx)
    local vParams = toTable(ctx.params)
    if next(vParams) == nil then vParams = toTable(ctx.plugin_option) end
    if next(vParams) == nil then vParams = toTable(ctx.plugin_options) end
    local userInfo = ctx.user_info or {}
    local accountInfo = ctx.account_info or {}
    local options = mergeOptions(ctx)

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return plugin._error_response(500, gatewayErr)
    end

    local configuredSite = vParams.domain_url or ""
    local deviceSite = (ctx.device and ctx.device.base_url) or ""
    local site = configuredSite:lower():match("^https://") and configuredSite
        or (deviceSite:lower():match("^https://") and deviceSite)
        or (configuredSite ~= "" and configuredSite)
        or deviceSite
    site = site:gsub("/+$", "")

    local req = {
        data = helper.base64_encode(json.encode({
            site = site,
            pid = tonumber(userInfo.id) or 0,
            key = userInfo.app_secret or "",
            token = plugin._cloud_token(),
            proxy = getProxy(options)
        }))
    }

    local data, requestErr = plugin._request_wechat_gateway(
        "POST",
        serverAddress,
        plugin._get_protocol_prefix(options) .. "/CreateID",
        req,
        "60s"
    )
    if requestErr then
        return plugin._error_response(500, requestErr)
    end
    if data.code ~= "1" and data.code ~= 200 then
        return plugin._error_response(500, data.msg or "微信网关创建登录会话失败")
    end

    local uid = data.uid
    helper.channel_account_set_option(accountInfo.id, "bind_token", json.encode({ uid = uid }))
    helper.channel_account_set_option(accountInfo.id, "uid", uid)
    helper.channel_account_set_option(accountInfo.id, "bound_login_protocol", options.login_protocol or "yyb")
    helper.channel_account_set_option(accountInfo.id, "clerk_sid", "")
    helper.channel_account_set_option(accountInfo.id, "shop_list", "")

    data, requestErr = plugin._request_wechat_gateway(
        "POST",
        serverAddress,
        plugin._get_protocol_prefix(options) .. "/QRCode",
        plugin._clerk_query({ uid = uid, login_protocol = options.login_protocol }),
        "30s"
    )
    if requestErr then
        return plugin._error_response(500, requestErr)
    end
    if data.code ~= "1" and data.code ~= 200 then
        return plugin._error_response(500, data.msg or "获取微信登录链接失败")
    end

    local qrCode = firstNonBlank(data.url, data.qrcode, data.QRCode, data.qr_url, data.qrcode_url, data.login_qrcode)
    if qrCode == "" then
        return plugin._error_response(500, "微信登录二维码为空")
    end

    return {
        code = 200,
        message = "success",
        data = {
            qrcode = qrCode,
            options = json.encode({ uid = uid })
        }
    }
end

function plugin.login_qrcode_check(ctx)
    local params = toTable(ctx.params)
    if next(params) == nil then params = toTable(ctx.plugin_option) end
    if next(params) == nil then params = toTable(ctx.plugin_options) end
    local accountInfo = ctx.account_info or {}
    local options = mergeOptions(ctx)

    local uid = params.uid or plugin._get_bound_uid(options)
    if not uid or uid == "" then
        return plugin._error_response(500, "缺少微信登录UID")
    end

    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return plugin._error_response(500, gatewayErr)
    end

    local data, requestErr = plugin._request_wechat_gateway(
        "POST",
        serverAddress,
        plugin._get_protocol_prefix(options) .. "/IsLoginStatus",
        plugin._clerk_query({ uid = uid, login_protocol = options.login_protocol }),
        "60s"
    )
    if requestErr then
        return plugin._error_response(500, requestErr)
    end
    if data.code ~= "1" and data.code ~= 200 then
        if data.code == "0" then
            return plugin._error_response(201, data.msg or "请扫描二维码登录")
        end
        return plugin._error_response(500, data.msg or "微信登录状态检查失败")
    end

    helper.channel_account_set_option(accountInfo.id, "bind_token", json.encode({
        uid = uid,
        pid = data.pid
    }))
    helper.channel_account_set_option(accountInfo.id, "uid", uid)

    options.uid = uid
    options.bind_token = json.encode({ uid = uid, pid = data.pid })

    local sidOk, sidErr = plugin._sync_clerk_assistant_sid(accountInfo, options)
    if not sidOk then
        return plugin._error_response(500, sidErr)
    end

    local shopOk, shopErr = plugin._sync_clerk_shops(accountInfo, options)
    if not shopOk then
        return plugin._error_response(500, shopErr)
    end

    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
    end

    return {
        code = 200,
        message = "登录成功，店员助手已授权",
        data = {}
    }
end

function plugin.onAccountChanged(ctx)
    local accountInfo, options
    if type(ctx) == "table" and ctx.account_info then
        accountInfo = ctx.account_info
        options = mergeOptions(ctx)
    else
        accountInfo = toTable(ctx)
        options = toTable(accountInfo.options)
    end

    local selectedProtocol = options.login_protocol or "yyb"
    local boundProtocol = options.bound_login_protocol
    if (not boundProtocol or boundProtocol == "") and plugin._get_bound_uid(options) then
        boundProtocol = "yyb"
    end
    if boundProtocol and boundProtocol ~= "" and boundProtocol ~= selectedProtocol then
        helper.channel_account_offline(accountInfo.id)
        for _, key in ipairs({ "bind_token", "uid", "clerk_sid", "shop_list", "mch_id", "shop_id", "bound_login_protocol" }) do
            helper.channel_account_set_option(accountInfo.id, key, "")
            options[key] = ""
        end
        return { code = 200, message = "登录协议已切换，通道已离线，请重新扫码登录", data = {} }
    end

    local _, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return { code = 500, message = gatewayErr, data = {} }
    end

    if (not options.shop_list or options.shop_list == "") and plugin._get_bound_uid(options) then
        local ok, err = plugin._sync_clerk_shops(accountInfo, options)
        if not ok then
            return { code = 200, message = "账号保存成功，请扫码登录或重新授权店员助手：" .. err, data = {} }
        end
    end

    return { code = 200, message = "账号保存成功，请扫码登录微信网关并授权店员助手", data = {} }
end

function plugin.heartbeat(ctx)
    return {
        code = 200,
        message = "无需上报",
        data = {}
    }
end

plugin._third_account = function(options)
    return firstNonBlank(options.mch_id, "") .. ":" .. firstNonBlank(options.shop_id, "")
end

plugin._get_clerk_bills = function(options)
    local serverAddress, gatewayErr = plugin._get_cloud_gateway(options)
    if gatewayErr then
        return nil, gatewayErr
    end

    local now = os.time()
    local lookback = tonumber(options.bill_lookback_seconds or 600) or 600
    if lookback < 60 then lookback = 60 end
    if lookback > 86400 then lookback = 86400 end

    local data, requestErr = plugin._request_wechat_gateway(
        "POST",
        serverAddress,
        plugin._get_protocol_prefix(options) .. "/GetClerkAssistantBills",
        plugin._clerk_query(options, {
            mch_id = options.mch_id,
            shop_id = options.shop_id,
            end_time = "0",
            page_size = "20",
            last_id = "",
            window_start = now - lookback,
            window_end = now + 60
        }),
        "60s"
    )
    if requestErr then
        return nil, requestErr
    end
    if data.code ~= "1" and data.code ~= 200 then
        return nil, data.msg or "获取店员助手账单失败"
    end

    local payload = data.data or data
    local items = payload.items or {}
    if type(items) ~= "table" then
        return nil, "店员助手账单响应格式错误"
    end
    return items, nil
end

plugin._extract_order_id = function(text)
    text = tostring(text or "")
    if text == "" then return "" end
    text = string.gsub(text, "请勿添加备注%-", "")
    local matched, matchGroups = helper.regexp_match_group(text, "^(?<order_id>\\d{20})$")
    if matched then
        if type(matchGroups) == "string" then
            matchGroups = json.decode(matchGroups)
        end
        if matchGroups and matchGroups["order_id"] then
            return matchGroups["order_id"][1]
        end
    end
    return ""
end

plugin._bill_trade_no = function(item)
    return firstNonBlank(item.trade_no, item.third_order_no, item.transaction_id, item.trans_id, item.bill_id, item.id)
end

plugin._bill_pay_time = function(item)
    return firstNonBlank(item.pay_time, item.payTimeText, item.pay_succ_time, item.time, item.timestamp)
end

plugin._bill_remark = function(item)
    return firstNonBlank(item.source, item.title, item.remark, "店员助手")
end

plugin._is_order_exists = function(item, options, accountInfo)
    return orderPayHelper.third_order_exist({
        pay_type = "wxpay",
        channel_code = YUN_WECHAT_DIANYUAN_LZ,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        third_account = plugin._third_account(options),
        third_order_id = plugin._bill_trade_no(item)
    })
end

plugin._insert_and_report_bill = function(item, options, accountInfo)
    local thirdOrderId = plugin._bill_trade_no(item)
    if thirdOrderId == "" then
        log.warning(string.format("[%s] 店员助手账单缺少交易号，已跳过", PLUGIN))
        return
    end

    local amount = amountToFen(firstNonBlank(item.amount, item.money, item.total_amount))
    if amount <= 0 then
        log.warning(string.format("[%s] 店员助手账单金额无效，交易号:%s", PLUGIN, thirdOrderId))
        return
    end

    if plugin._is_order_exists(item, options, accountInfo) then
        return
    end

    local remark = plugin._bill_remark(item)
    local outOrderId = plugin._extract_order_id(remark)
    local insertId = orderPayHelper.third_order_insert({
        pay_type = "wxpay",
        channel_code = YUN_WECHAT_DIANYUAN_LZ,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        buyer_id = "",
        buyer_name = "",
        third_order_id = thirdOrderId,
        third_account = plugin._third_account(options),
        amount = amount,
        remark = remark,
        trans_time = timeToTimestamp(plugin._bill_pay_time(item)),
        type = "店员助手收款",
        out_order_id = outOrderId
    })

    if insertId <= 0 then
        log.warning(string.format("[%s] 店员助手账单录入失败，交易号:%s,金额:%s", PLUGIN, thirdOrderId, amount))
        return
    end

    local errCode, errMessage = orderPayHelper.third_order_report(insertId)
    if errCode == 200 then
        log.info(string.format("[%s] 店员助手订单上报成功:%s,交易号:%s,金额:%s", PLUGIN, errMessage, thirdOrderId, amount))
    else
        log.warning(string.format("[%s] 店员助手订单上报失败:%s,交易号:%s,金额:%s", PLUGIN, errMessage, thirdOrderId, amount))
    end
end

function plugin.cron(ctx)
    local accountInfo = ctx.account_info
    local options = mergeOptions(ctx)

    local success, errMessage = plugin._verify_and_init_account(accountInfo, options)
    if not success then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end
        return { code = 500, message = errMessage, data = {} }
    end

    if accountInfo.online ~= 1 then
        helper.channel_account_online(accountInfo.id)
    end

    local items, billErr = plugin._get_clerk_bills(options)
    if billErr then
        return { code = 500, message = billErr, data = {} }
    end

    if not items or #items == 0 then
        return { code = 200, message = "暂无店员助手账单", data = {} }
    end

    for _, item in ipairs(items) do
        if type(item) == "table" then
            plugin._insert_and_report_bill(item, options, accountInfo)
        end
    end

    return { code = 200, message = "店员助手账单处理完成", data = {} }
end

return plugin
